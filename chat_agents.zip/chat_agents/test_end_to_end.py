#!/usr/bin/env python3
"""
End-to-End Test Suite for Enterprise Multi-Tenant Chat Agent

Tests all components from server startup to complete workflow.
"""

import asyncio
import httpx
import json
import time
import sys
from pathlib import Path
from typing import Optional, Dict, Any
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich import print as rprint

console = Console()

# Test configuration
API_BASE_URL = "http://localhost:8000"
TEST_TIMEOUT = 30.0


class EndToEndTester:
    """Complete end-to-end test suite"""

    def __init__(self):
        self.client: Optional[httpx.AsyncClient] = None
        self.test_client_api_key: Optional[str] = None
        self.test_client_id: Optional[str] = None
        self.tests_passed = 0
        self.tests_failed = 0
        self.test_results = []

    async def __aenter__(self):
        self.client = httpx.AsyncClient(timeout=TEST_TIMEOUT)
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.client:
            await self.client.aclose()

    def log_test(self, test_name: str, passed: bool, message: str = ""):
        """Log test result"""
        if passed:
            self.tests_passed += 1
            console.print(f"[green]✓[/green] {test_name}")
        else:
            self.tests_failed += 1
            console.print(f"[red]✗[/red] {test_name}")
            if message:
                console.print(f"  [dim]{message}[/dim]")

        self.test_results.append({
            "test": test_name,
            "passed": passed,
            "message": message
        })

    async def test_01_server_running(self) -> bool:
        """Test 1: Check if server is running"""
        console.print("\n[bold cyan]Test 1: Server Health Check[/bold cyan]")

        try:
            response = await self.client.get(f"{API_BASE_URL}/health")

            if response.status_code == 200:
                data = response.json()
                self.log_test("Server is running", True)
                self.log_test(f"Chat agent initialized: {data.get('chat_agent', False)}",
                            data.get('chat_agent', False))
                self.log_test(f"SQL enabled: {data.get('sql_enabled', False)}",
                            data.get('sql_enabled', False))
                return True
            else:
                self.log_test("Server health check", False, f"Status: {response.status_code}")
                return False

        except httpx.ConnectError:
            self.log_test("Server health check", False,
                         f"Cannot connect to {API_BASE_URL}. Is the server running?")
            console.print("\n[yellow]To start server: python run.py[/yellow]")
            return False

        except Exception as e:
            self.log_test("Server health check", False, str(e))
            return False

    async def test_02_api_info(self) -> bool:
        """Test 2: Get API info"""
        console.print("\n[bold cyan]Test 2: API Information[/bold cyan]")

        try:
            response = await self.client.get(f"{API_BASE_URL}/")

            if response.status_code == 200:
                data = response.json()
                self.log_test("API info endpoint", True)
                console.print(f"  Service: {data.get('service', 'N/A')}")
                console.print(f"  Status: {data.get('status', 'N/A')}")
                return True
            else:
                self.log_test("API info endpoint", False, f"Status: {response.status_code}")
                return False

        except Exception as e:
            self.log_test("API info endpoint", False, str(e))
            return False

    async def test_03_create_client(self) -> bool:
        """Test 3: Create a test client"""
        console.print("\n[bold cyan]Test 3: Client Creation[/bold cyan]")

        try:
            client_data = {
                "name": f"E2E Test Client {int(time.time())}",
                "contact_email": "test@e2etest.com",
                "industry": "testing"
            }

            response = await self.client.post(
                f"{API_BASE_URL}/clients",
                json=client_data
            )

            if response.status_code == 200:
                data = response.json()
                self.test_client_api_key = data.get("api_key")
                self.test_client_id = data.get("id")

                self.log_test("Client creation", True)
                console.print(f"  Client ID: {self.test_client_id}")
                console.print(f"  API Key: {self.test_client_api_key[:20]}...")
                console.print(f"  Schema: {data.get('schema_name', 'N/A')}")
                return True
            else:
                self.log_test("Client creation", False,
                            f"Status: {response.status_code}, Body: {response.text}")
                return False

        except Exception as e:
            self.log_test("Client creation", False, str(e))
            return False

    async def test_04_list_clients(self) -> bool:
        """Test 4: List all clients"""
        console.print("\n[bold cyan]Test 4: List Clients[/bold cyan]")

        try:
            response = await self.client.get(f"{API_BASE_URL}/clients")

            if response.status_code == 200:
                clients = response.json()
                self.log_test("List clients", True)
                console.print(f"  Total clients: {len(clients)}")
                return True
            else:
                self.log_test("List clients", False, f"Status: {response.status_code}")
                return False

        except Exception as e:
            self.log_test("List clients", False, str(e))
            return False

    async def test_05_get_client(self) -> bool:
        """Test 5: Get specific client"""
        console.print("\n[bold cyan]Test 5: Get Client Details[/bold cyan]")

        if not self.test_client_id:
            self.log_test("Get client details", False, "No test client ID available")
            return False

        try:
            response = await self.client.get(f"{API_BASE_URL}/clients/{self.test_client_id}")

            if response.status_code == 200:
                data = response.json()
                self.log_test("Get client details", True)
                console.print(f"  Name: {data.get('name', 'N/A')}")
                console.print(f"  Industry: {data.get('industry', 'N/A')}")
                console.print(f"  Active: {data.get('is_active', False)}")
                return True
            else:
                self.log_test("Get client details", False, f"Status: {response.status_code}")
                return False

        except Exception as e:
            self.log_test("Get client details", False, str(e))
            return False

    async def test_06_auth_required(self) -> bool:
        """Test 6: Verify authentication is required"""
        console.print("\n[bold cyan]Test 6: Authentication Validation[/bold cyan]")

        try:
            # Try without API key
            response = await self.client.post(
                f"{API_BASE_URL}/chat",
                json={"message": "test", "check_sql": False}
            )

            if response.status_code == 401:
                self.log_test("Authentication required", True)
                return True
            else:
                self.log_test("Authentication required", False,
                            f"Expected 401, got {response.status_code}")
                return False

        except Exception as e:
            self.log_test("Authentication required", False, str(e))
            return False

    async def test_07_chat_with_auth(self) -> bool:
        """Test 7: Chat endpoint with authentication"""
        console.print("\n[bold cyan]Test 7: Authenticated Chat Request[/bold cyan]")

        if not self.test_client_api_key:
            self.log_test("Chat with auth", False, "No test client API key available")
            return False

        try:
            response = await self.client.post(
                f"{API_BASE_URL}/chat",
                headers={"X-API-Key": self.test_client_api_key},
                json={
                    "message": "SELECT 1 as test",
                    "check_sql": False
                }
            )

            if response.status_code == 200:
                data = response.json()
                self.log_test("Chat with authentication", True)
                console.print(f"  Response: {data.get('response', 'N/A')[:100]}...")
                return True
            else:
                self.log_test("Chat with authentication", False,
                            f"Status: {response.status_code}, Body: {response.text[:200]}")
                return False

        except Exception as e:
            self.log_test("Chat with authentication", False, str(e))
            return False

    async def test_08_refresh_schema(self) -> bool:
        """Test 8: Refresh database schema"""
        console.print("\n[bold cyan]Test 8: Schema Refresh[/bold cyan]")

        if not self.test_client_api_key:
            self.log_test("Schema refresh", False, "No test client API key available")
            return False

        try:
            response = await self.client.post(
                f"{API_BASE_URL}/refresh-schema",
                headers={"X-API-Key": self.test_client_api_key}
            )

            if response.status_code == 200:
                data = response.json()
                self.log_test("Schema refresh", True)
                console.print(f"  Tables found: {data.get('table_count', 0)}")
                return True
            else:
                self.log_test("Schema refresh", False,
                            f"Status: {response.status_code}, Body: {response.text[:200]}")
                return False

        except Exception as e:
            self.log_test("Schema refresh", False, str(e))
            return False

    async def test_09_training(self) -> bool:
        """Test 9: Train the agent with examples"""
        console.print("\n[bold cyan]Test 9: Training with Examples[/bold cyan]")

        if not self.test_client_api_key:
            self.log_test("Training", False, "No test client API key available")
            return False

        try:
            training_data = {
                "examples": [
                    {
                        "question": "How many test records?",
                        "sql": "SELECT COUNT(*) FROM test_table"
                    },
                    {
                        "question": "Show me test data",
                        "sql": "SELECT * FROM test_table LIMIT 10"
                    }
                ]
            }

            response = await self.client.post(
                f"{API_BASE_URL}/train",
                headers={"X-API-Key": self.test_client_api_key},
                json=training_data
            )

            if response.status_code == 200:
                data = response.json()
                self.log_test("Training with examples", True)
                console.print(f"  Examples trained: {data.get('examples_trained', 0)}")
                return True
            else:
                self.log_test("Training with examples", False,
                            f"Status: {response.status_code}, Body: {response.text[:200]}")
                return False

        except Exception as e:
            self.log_test("Training with examples", False, str(e))
            return False

    async def test_10_training_status(self) -> bool:
        """Test 10: Check training status"""
        console.print("\n[bold cyan]Test 10: Training Status[/bold cyan]")

        if not self.test_client_api_key:
            self.log_test("Training status", False, "No test client API key available")
            return False

        try:
            response = await self.client.get(
                f"{API_BASE_URL}/training/status",
                headers={"X-API-Key": self.test_client_api_key}
            )

            if response.status_code == 200:
                data = response.json()
                self.log_test("Training status", True)
                console.print(f"  Examples: {data.get('total_examples', 0)}")
                return True
            else:
                self.log_test("Training status", False,
                            f"Status: {response.status_code}")
                return False

        except Exception as e:
            self.log_test("Training status", False, str(e))
            return False

    async def test_11_rag_stats(self) -> bool:
        """Test 11: Get RAG pipeline statistics"""
        console.print("\n[bold cyan]Test 11: RAG Statistics[/bold cyan]")

        if not self.test_client_api_key:
            self.log_test("RAG statistics", False, "No test client API key available")
            return False

        try:
            response = await self.client.get(
                f"{API_BASE_URL}/rag/stats",
                headers={"X-API-Key": self.test_client_api_key}
            )

            if response.status_code == 200:
                data = response.json()
                self.log_test("RAG statistics", True)
                console.print(f"  Namespace: {data.get('namespace', 'N/A')}")
                return True
            else:
                self.log_test("RAG statistics", False,
                            f"Status: {response.status_code}")
                return False

        except Exception as e:
            self.log_test("RAG statistics", False, str(e))
            return False

    def print_summary(self):
        """Print test summary"""
        console.print("\n" + "="*60)
        console.print(Panel.fit(
            f"[bold]End-to-End Test Results[/bold]\n\n"
            f"[green]Passed: {self.tests_passed}[/green]\n"
            f"[red]Failed: {self.tests_failed}[/red]\n"
            f"[cyan]Total: {self.tests_passed + self.tests_failed}[/cyan]\n\n"
            f"Success Rate: {(self.tests_passed/(self.tests_passed + self.tests_failed)*100):.1f}%",
            border_style="cyan" if self.tests_failed == 0 else "yellow"
        ))

        # Detailed results table
        if self.test_results:
            table = Table(title="Detailed Test Results", show_header=True)
            table.add_column("Test", style="cyan")
            table.add_column("Status", style="white")
            table.add_column("Message", style="dim")

            for result in self.test_results:
                status = "[green]PASS[/green]" if result['passed'] else "[red]FAIL[/red]"
                table.add_row(
                    result['test'],
                    status,
                    result['message'][:50] if result['message'] else ""
                )

            console.print("\n")
            console.print(table)

        return self.tests_failed == 0


async def run_all_tests():
    """Run all end-to-end tests"""

    console.print(Panel.fit(
        "[bold cyan]Enterprise Multi-Tenant Chat Agent[/bold cyan]\n"
        "[white]End-to-End Test Suite[/white]",
        border_style="cyan"
    ))

    async with EndToEndTester() as tester:
        # Run all tests in sequence
        await tester.test_01_server_running()
        await tester.test_02_api_info()
        await tester.test_03_create_client()
        await tester.test_04_list_clients()
        await tester.test_05_get_client()
        await tester.test_06_auth_required()
        await tester.test_07_chat_with_auth()
        await tester.test_08_refresh_schema()
        await tester.test_09_training()
        await tester.test_10_training_status()
        await tester.test_11_rag_stats()

        # Print summary
        all_passed = tester.print_summary()

        if all_passed:
            console.print("\n[bold green]🎉 All tests passed! System is fully operational.[/bold green]")
            return 0
        else:
            console.print("\n[bold yellow]⚠️  Some tests failed. Check details above.[/bold yellow]")
            return 1


if __name__ == "__main__":
    try:
        exit_code = asyncio.run(run_all_tests())
        sys.exit(exit_code)
    except KeyboardInterrupt:
        console.print("\n\n[yellow]Tests cancelled by user[/yellow]")
        sys.exit(130)
    except Exception as e:
        console.print(f"\n[red]Fatal error: {e}[/red]")
        sys.exit(1)
