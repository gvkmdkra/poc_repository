# Simple test script for Enterprise Multi-Tenant Chat Agent
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host "Testing Enterprise Multi-Tenant Chat Agent" -ForegroundColor Cyan
Write-Host "======================================================================`n" -ForegroundColor Cyan

$baseUrl = "http://localhost:8000"
$apiKey = "sk_live_5eba7c2f74be13485739063a59015bb5c6aa8021d22da4528a491b9a07f7d3a3"

# Test 1: Health Check
Write-Host "Test 1: Health Check" -ForegroundColor Yellow
$health = Invoke-RestMethod -Uri "$baseUrl/health"
Write-Host "Status: $($health.status)" -ForegroundColor Green
Write-Host "Multi-Tenant: $($health.architecture.multi_tenant)`n" -ForegroundColor Green

# Test 2: Get Demo Client
Write-Host "Test 2: Get Demo Client Details" -ForegroundColor Yellow
$headers = @{ "X-API-Key" = $apiKey }
$client = Invoke-RestMethod -Uri "$baseUrl/clients/358c1b8d-8b30-4218-8c88-d70c5a1fb788" -Headers $headers
Write-Host "Client: $($client.name)" -ForegroundColor Green
Write-Host "Industry: $($client.industry)" -ForegroundColor Green
Write-Host "Active: $($client.is_active)`n" -ForegroundColor Green

# Test 3: Get RAG Stats
Write-Host "Test 3: RAG Statistics" -ForegroundColor Yellow
$stats = Invoke-RestMethod -Uri "$baseUrl/rag/stats" -Headers $headers
Write-Host "Total Vectors: $($stats.vector_store.total_vectors)" -ForegroundColor Green
Write-Host "Dimension: $($stats.vector_store.dimension)" -ForegroundColor Green
Write-Host "Model: $($stats.embedding_model)`n" -ForegroundColor Green

Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host "All tests passed! System is operational." -ForegroundColor Green
Write-Host "Visit http://localhost:8000/docs for more testing" -ForegroundColor Cyan
Write-Host "======================================================================" -ForegroundColor Cyan
