# ============================================================================
# Enterprise Multi-Tenant Chat Agent - Local Testing Script
# ============================================================================

Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host "Testing Enterprise Multi-Tenant Chat Agent" -ForegroundColor Cyan
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host ""

$baseUrl = "http://localhost:8000"
$apiKey = "sk_live_5eba7c2f74be13485739063a59015bb5c6aa8021d22da4528a491b9a07f7d3a3"
$clientId = "358c1b8d-8b30-4218-8c88-d70c5a1fb788"

$headers = @{
    "X-API-Key" = $apiKey
    "Content-Type" = "application/json"
}

$testsPassed = 0
$testsFailed = 0

# Test 1: Health Check
Write-Host "Test 1: Health Check" -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$baseUrl/health" -Method Get
    Write-Host "✓ PASSED" -ForegroundColor Green
    Write-Host "  Status: $($response.status)" -ForegroundColor Cyan
    Write-Host "  Multi-Tenant: $($response.architecture.multi_tenant)" -ForegroundColor Cyan
    Write-Host "  RAG Enabled: $($response.architecture.rag_enabled)" -ForegroundColor Cyan
    $testsPassed++
} catch {
    Write-Host "✗ FAILED: $_" -ForegroundColor Red
    $testsFailed++
}
Write-Host ""

# Test 2: Get Client Details
Write-Host "Test 2: Get Client Details (Authenticated)" -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$baseUrl/clients/$clientId" -Method Get -Headers $headers
    Write-Host "✓ PASSED" -ForegroundColor Green
    Write-Host "  Client Name: $($response.name)" -ForegroundColor Cyan
    Write-Host "  Industry: $($response.industry)" -ForegroundColor Cyan
    Write-Host "  Status: $(if($response.is_active){'Active'}else{'Inactive'})" -ForegroundColor Cyan
    Write-Host "  Total Queries: $($response.total_queries)" -ForegroundColor Cyan
    Write-Host "  Total Embeddings: $($response.total_embeddings)" -ForegroundColor Cyan
    $testsPassed++
} catch {
    Write-Host "✗ FAILED: $_" -ForegroundColor Red
    $testsFailed++
}
Write-Host ""

# Test 3: Refresh Schema
Write-Host "Test 3: Refresh Database Schema" -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$baseUrl/refresh-schema" -Method Post -Headers $headers
    Write-Host "✓ PASSED" -ForegroundColor Green
    Write-Host "  Schema Name: $($response.schema_name)" -ForegroundColor Cyan
    Write-Host "  Table Count: $($response.table_count)" -ForegroundColor Cyan
    if ($response.tables.Count -gt 0) {
        Write-Host "  Tables:" -ForegroundColor Cyan
        foreach ($table in $response.tables) {
            Write-Host "    - $table" -ForegroundColor Cyan
        }
    } else {
        Write-Host "  Tables: None (new client - create tables in Turso first)" -ForegroundColor Yellow
    }
    $testsPassed++
} catch {
    Write-Host "✗ FAILED: $_" -ForegroundColor Red
    $testsFailed++
}
Write-Host ""

# Test 4: Train with Examples
Write-Host "Test 4: Train with Examples" -ForegroundColor Yellow
try {
    $trainBody = @{
        examples = @(
            @{
                question = "How many total customers?"
                sql = "SELECT COUNT(*) as total_customers FROM customers"
            },
            @{
                question = "Show recent orders"
                sql = "SELECT * FROM orders ORDER BY created_at DESC LIMIT 5"
            },
            @{
                question = "What is the total revenue?"
                sql = "SELECT SUM(amount) as total_revenue FROM orders WHERE status = ''completed''"
            }
        )
    } | ConvertTo-Json -Depth 10

    $response = Invoke-RestMethod -Uri "$baseUrl/train" -Method Post -Headers $headers -Body $trainBody
    Write-Host "✓ PASSED" -ForegroundColor Green
    Write-Host "  Success: $($response.success)" -ForegroundColor Cyan
    Write-Host "  Examples Trained: $($response.examples_trained)" -ForegroundColor Cyan
    Write-Host "  Total Vectors: $($response.total_vectors)" -ForegroundColor Cyan
    Write-Host "  Message: $($response.message)" -ForegroundColor Cyan
    $testsPassed++
} catch {
    Write-Host "✗ FAILED: $_" -ForegroundColor Red
    $testsFailed++
}
Write-Host ""

# Test 5: Check Training Status
Write-Host "Test 5: Check Training Status" -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$baseUrl/training/status" -Method Get -Headers $headers
    Write-Host "✓ PASSED" -ForegroundColor Green
    Write-Host "  Client Name: $($response.client_name)" -ForegroundColor Cyan
    Write-Host "  Is Trained: $($response.is_trained)" -ForegroundColor Cyan
    Write-Host "  Total Vectors: $($response.total_vectors)" -ForegroundColor Cyan
    Write-Host "  Namespace: $($response.namespace)" -ForegroundColor Cyan
    $testsPassed++
} catch {
    Write-Host "✗ FAILED: $_" -ForegroundColor Red
    $testsFailed++
}
Write-Host ""

# Test 6: Get RAG Statistics
Write-Host "Test 6: Get RAG Statistics" -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$baseUrl/rag/stats" -Method Get -Headers $headers
    Write-Host "✓ PASSED" -ForegroundColor Green
    Write-Host "  Index Name: $($response.vector_store.index_name)" -ForegroundColor Cyan
    Write-Host "  Total Vectors: $($response.vector_store.total_vectors)" -ForegroundColor Cyan
    Write-Host "  Dimension: $($response.vector_store.dimension)" -ForegroundColor Cyan
    Write-Host "  Embedding Model: $($response.embedding_model)" -ForegroundColor Cyan
    Write-Host "  Top K Results: $($response.default_top_k)" -ForegroundColor Cyan
    Write-Host "  Similarity Threshold: $($response.similarity_threshold)" -ForegroundColor Cyan
    $testsPassed++
} catch {
    Write-Host "✗ FAILED: $_" -ForegroundColor Red
    $testsFailed++
}
Write-Host ""

# Test 7: List All Clients
Write-Host "Test 7: List All Clients" -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$baseUrl/clients" -Method Get -Headers $headers
    Write-Host "✓ PASSED" -ForegroundColor Green
    Write-Host "  Total Clients: $($response.Count)" -ForegroundColor Cyan
    foreach ($client in $response) {
        if ($client.is_active) {
            Write-Host "    - $($client.name) [$($client.industry)] - Status: Active" -ForegroundColor Green
        } else {
            Write-Host "    - $($client.name) [$($client.industry)] - Status: Inactive" -ForegroundColor Red
        }
    }
    $testsPassed++
} catch {
    Write-Host "✗ FAILED: $_" -ForegroundColor Red
    $testsFailed++
}
Write-Host ""

# Test 8: Create New Client
Write-Host "Test 8: Create New Client" -ForegroundColor Yellow
try {
    $randomNum = Get-Random -Maximum 1000
    $newClientBody = @{
        name = "Test Company $randomNum"
        contact_email = "test$randomNum@testcompany.com"
        industry = "technology"
    } | ConvertTo-Json

    $response = Invoke-RestMethod -Uri "$baseUrl/clients" -Method Post -Headers @{"Content-Type" = "application/json"} -Body $newClientBody
    Write-Host "✓ PASSED" -ForegroundColor Green
    Write-Host "  New Client ID: $($response.id)" -ForegroundColor Cyan
    Write-Host "  Name: $($response.name)" -ForegroundColor Cyan
    Write-Host "  API Key: $($response.api_key)" -ForegroundColor Cyan
    Write-Host "  Schema Name: $($response.schema_name)" -ForegroundColor Cyan
    Write-Host "  Namespace: $($response.embedding_namespace)" -ForegroundColor Cyan
    $testsPassed++
} catch {
    Write-Host "✗ FAILED: $_" -ForegroundColor Red
    $testsFailed++
}
Write-Host ""

# Test 9: Test Authentication (Should Fail)
Write-Host "Test 9: Test Authentication Failure (Invalid API Key)" -ForegroundColor Yellow
try {
    $invalidHeaders = @{
        "X-API-Key" = "invalid_key_12345"
    }
    $response = Invoke-RestMethod -Uri "$baseUrl/clients/$clientId" -Method Get -Headers $invalidHeaders
    Write-Host "✗ FAILED: Should have returned 401 Unauthorized" -ForegroundColor Red
    $testsFailed++
} catch {
    if ($_.Exception.Response.StatusCode -eq 401) {
        Write-Host "✓ PASSED (Correctly rejected invalid API key)" -ForegroundColor Green
        $testsPassed++
    } else {
        Write-Host "✗ FAILED: Wrong error code" -ForegroundColor Red
        $testsFailed++
    }
}
Write-Host ""

# Test 10: Test Public Endpoint (No Auth)
Write-Host "Test 10: Test Public Endpoint (No Authentication)" -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$baseUrl/" -Method Get
    Write-Host "✓ PASSED" -ForegroundColor Green
    Write-Host "  Service: $($response.service)" -ForegroundColor Cyan
    Write-Host "  Version: $($response.version)" -ForegroundColor Cyan
    $testsPassed++
} catch {
    Write-Host "✗ FAILED: $_" -ForegroundColor Red
    $testsFailed++
}
Write-Host ""

# Summary
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host "Test Summary" -ForegroundColor Cyan
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host "Total Tests: $($testsPassed + $testsFailed)" -ForegroundColor White
Write-Host "Tests Passed: $testsPassed" -ForegroundColor Green
Write-Host "Tests Failed: $testsFailed" -ForegroundColor Red

if ($testsFailed -eq 0) {
    Write-Host ""
    Write-Host "🎉 All tests passed! Your system is working perfectly!" -ForegroundColor Green
    Write-Host ""
    Write-Host "Next Steps:" -ForegroundColor Yellow
    Write-Host "  1. Open browser: http://localhost:8000/docs" -ForegroundColor Cyan
    Write-Host "  2. Create tables in Turso database" -ForegroundColor Cyan
    Write-Host "  3. Train with more examples" -ForegroundColor Cyan
    Write-Host "  4. Test SQL generation with real queries" -ForegroundColor Cyan
} else {
    Write-Host ""
    Write-Host "⚠️ Some tests failed. Check the errors above." -ForegroundColor Red
}

Write-Host "======================================================================" -ForegroundColor Cyan
