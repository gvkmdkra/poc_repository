import libsql_client
from typing import List, Dict, Any, Optional
from .config import settings


class TursoDBConnector:
    def __init__(self, url: Optional[str] = None, auth_token: Optional[str] = None):
        self.url = url or settings.TURSO_DB_URL
        self.auth_token = auth_token or settings.TURSO_DB_AUTH_TOKEN
        self.client = None

    async def connect(self):
        self.client = libsql_client.create_client(
            url=self.url,
            auth_token=self.auth_token
        )
        return self

    async def execute(self, query: str, params: Optional[List[Any]] = None) -> Dict[str, Any]:
        if not self.client:
            await self.connect()

        result = await self.client.execute(query, params or [])
        return result

    async def execute_batch(self, queries: List[str]) -> List[Dict[str, Any]]:
        if not self.client:
            await self.connect()

        results = []
        for query in queries:
            result = await self.client.execute(query)
            results.append(result)
        return results

    async def fetch_all(self, query: str, params: Optional[List[Any]] = None) -> List[Dict[str, Any]]:
        result = await self.execute(query, params)
        if hasattr(result, 'rows'):
            # Convert Row objects to dictionaries
            rows = []
            for row in result.rows:
                if hasattr(row, 'as_dict'):
                    rows.append(row.as_dict())
                elif hasattr(row, '_asdict'):
                    rows.append(row._asdict())
                elif isinstance(row, dict):
                    rows.append(row)
                else:
                    # Try to convert using column names
                    try:
                        row_dict = {col: row[col] for col in row.keys()}
                        rows.append(row_dict)
                    except:
                        rows.append(dict(row))
            return rows
        return result.get('rows', [])

    async def fetch_one(self, query: str, params: Optional[List[Any]] = None) -> Optional[Dict[str, Any]]:
        result = await self.execute(query, params)
        if hasattr(result, 'rows'):
            rows = result.rows
        else:
            rows = result.get('rows', [])
        if rows:
            row = rows[0]
            # Convert Row object to dictionary
            if hasattr(row, 'as_dict'):
                return row.as_dict()
            elif hasattr(row, '_asdict'):
                return row._asdict()
            elif isinstance(row, dict):
                return row
            else:
                try:
                    return {col: row[col] for col in row.keys()}
                except:
                    return dict(row)
        return None

    async def close(self):
        if self.client:
            await self.client.close()
            self.client = None

    async def __aenter__(self):
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()
