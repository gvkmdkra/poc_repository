"""Client data model for multi-tenant architecture."""

from pydantic import BaseModel, Field, field_validator
from datetime import datetime
from typing import Optional, Dict, Any
from uuid import UUID, uuid4
import secrets


class ClientConfig(BaseModel):
    """Client-specific configuration settings."""

    max_queries_per_minute: int = Field(default=100, description="Rate limit for API calls")
    max_embeddings_per_day: int = Field(default=10000, description="Daily embedding quota")
    enable_voice_calls: bool = Field(default=True, description="Enable Twilio voice features")
    enable_sms: bool = Field(default=True, description="Enable SMS notifications")
    enable_whatsapp: bool = Field(default=False, description="Enable WhatsApp integration")
    auto_visualize: bool = Field(default=True, description="Auto-generate charts for SQL results")
    default_chart_type: str = Field(default="bar", description="Default visualization type")
    custom_greeting: Optional[str] = Field(default=None, description="Custom AI greeting message")

    class Config:
        json_schema_extra = {
            "example": {
                "max_queries_per_minute": 100,
                "max_embeddings_per_day": 10000,
                "enable_voice_calls": True,
                "enable_sms": True,
                "enable_whatsapp": False,
                "auto_visualize": True,
                "default_chart_type": "bar",
                "custom_greeting": "Welcome to Jewelry Store AI Assistant!"
            }
        }


class Client(BaseModel):
    """Client entity representing a tenant in the multi-tenant system.

    Each client gets:
    - Unique schema in Turso DB (client_{id})
    - Unique namespace in Pinecone vector DB
    - Unique API key for authentication
    - Isolated data and configuration
    """

    id: UUID = Field(default_factory=uuid4, description="Unique client identifier")
    name: str = Field(..., min_length=1, max_length=255, description="Client business name")
    schema_name: str = Field(..., description="Database schema name (client_{id})")
    api_key: str = Field(..., description="API key for authentication")
    embedding_namespace: str = Field(..., description="Pinecone namespace for vector embeddings")

    # Database connection (same Turso instance, different schema)
    db_url: str = Field(..., description="Turso database URL")
    db_auth_token: str = Field(..., description="Turso database auth token")

    # Configuration
    configuration: ClientConfig = Field(default_factory=ClientConfig)

    # Business metadata
    industry: Optional[str] = Field(default=None, description="Industry vertical (e.g., jewelry, legal)")
    contact_email: str = Field(..., description="Primary contact email")
    contact_phone: Optional[str] = Field(default=None, description="Primary contact phone")

    # Status and timestamps
    is_active: bool = Field(default=True, description="Whether client account is active")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    last_query_at: Optional[datetime] = Field(default=None, description="Last API query timestamp")

    # Usage tracking
    total_queries: int = Field(default=0, description="Total queries made")
    total_embeddings: int = Field(default=0, description="Total embeddings created")

    @field_validator('schema_name')
    @classmethod
    def validate_schema_name(cls, v: str) -> str:
        """Ensure schema name follows naming convention."""
        if not v.startswith('client_'):
            raise ValueError("Schema name must start with 'client_'")
        if not v.replace('client_', '').replace('_', '').isalnum():
            raise ValueError("Schema name must be alphanumeric after 'client_' prefix")
        return v.lower()

    @field_validator('embedding_namespace')
    @classmethod
    def validate_namespace(cls, v: str) -> str:
        """Ensure namespace is valid for Pinecone."""
        if not v.replace('-', '').replace('_', '').isalnum():
            raise ValueError("Namespace must be alphanumeric with hyphens/underscores")
        return v.lower()

    class Config:
        json_schema_extra = {
            "example": {
                "id": "123e4567-e89b-12d3-a456-426614174000",
                "name": "Luxury Jewelry Store",
                "schema_name": "client_abc123",
                "api_key": "sk_live_abc123xyz456",
                "embedding_namespace": "client-abc123",
                "db_url": "libsql://your-db.turso.io",
                "db_auth_token": "eyJhbGci...",
                "industry": "jewelry",
                "contact_email": "owner@jewelrystore.com",
                "contact_phone": "+1234567890",
                "is_active": True
            }
        }


class ClientCreate(BaseModel):
    """Request model for creating a new client."""

    name: str = Field(..., min_length=1, max_length=255, description="Client business name")
    industry: Optional[str] = Field(default=None, description="Industry vertical")
    contact_email: str = Field(..., description="Primary contact email")
    contact_phone: Optional[str] = Field(default=None, description="Primary contact phone")
    configuration: Optional[ClientConfig] = Field(default=None, description="Custom configuration")

    # Optional: Allow custom DB credentials (defaults to system DB)
    db_url: Optional[str] = Field(default=None, description="Custom Turso DB URL")
    db_auth_token: Optional[str] = Field(default=None, description="Custom Turso auth token")

    class Config:
        json_schema_extra = {
            "example": {
                "name": "Luxury Jewelry Store",
                "industry": "jewelry",
                "contact_email": "owner@jewelrystore.com",
                "contact_phone": "+1234567890",
                "configuration": {
                    "max_queries_per_minute": 100,
                    "enable_voice_calls": True,
                    "custom_greeting": "Welcome to Luxury Jewelry Store!"
                }
            }
        }


class ClientUpdate(BaseModel):
    """Request model for updating an existing client."""

    name: Optional[str] = Field(default=None, min_length=1, max_length=255)
    industry: Optional[str] = Field(default=None)
    contact_email: Optional[str] = Field(default=None)
    contact_phone: Optional[str] = Field(default=None)
    configuration: Optional[ClientConfig] = Field(default=None)
    is_active: Optional[bool] = Field(default=None)

    class Config:
        json_schema_extra = {
            "example": {
                "name": "Updated Jewelry Store Name",
                "configuration": {
                    "max_queries_per_minute": 150,
                    "enable_whatsapp": True
                }
            }
        }


def generate_api_key() -> str:
    """Generate a secure API key for client authentication.

    Format: sk_live_{32_random_hex_chars}
    """
    return f"sk_live_{secrets.token_hex(32)}"


def generate_schema_name(client_id: UUID) -> str:
    """Generate schema name from client ID.

    Format: client_{uuid_without_hyphens}
    """
    return f"client_{str(client_id).replace('-', '')}"


def generate_embedding_namespace(client_id: UUID) -> str:
    """Generate Pinecone namespace from client ID.

    Format: client-{first_8_chars_of_uuid}
    """
    return f"client-{str(client_id)[:8]}"
