"""RAG Pipeline orchestrator.

Coordinates the end-to-end retrieval-augmented generation workflow.
"""

from typing import Dict, Any, List, Optional
import logging
import time

from ..models.client import Client
from ..vector.embedding_service import EmbeddingService
from ..vector.vector_store import VectorStore
from ..rag.context_builder import ContextBuilder
from ..db.multi_tenant_connector import MultiTenantDBConnector
from ..config import settings

logger = logging.getLogger(__name__)


class RAGPipeline:
    """End-to-end RAG pipeline for SQL generation.

    Workflow:
    1. Embed user question
    2. Retrieve similar examples (vector search)
    3. Build rich context
    4. Generate SQL with GPT-4
    5. Validate and execute
    """

    def __init__(self):
        """Initialize RAG pipeline with all components."""
        self.embedding_service = EmbeddingService()
        self.vector_store = VectorStore()
        self.context_builder = ContextBuilder()

        logger.info("Initialized RAG Pipeline")

    async def process_query(
        self,
        client: Client,
        question: str,
        db_connector: MultiTenantDBConnector,
        sql_agent
    ) -> Dict[str, Any]:
        """Process a natural language query through the RAG pipeline.

        Args:
            client: Client object
            question: User's natural language question
            db_connector: Database connector
            sql_agent: SQL generation agent (OpenAIRAGAgent)

        Returns:
            Dict with SQL, results, metadata
        """
        start_time = time.time()
        pipeline_metadata = {
            'steps': [],
            'timings': {}
        }

        try:
            # Step 1: Embed the question
            step_start = time.time()
            question_embedding = await self.embedding_service.embed_text(question)
            pipeline_metadata['timings']['embedding'] = time.time() - step_start
            pipeline_metadata['steps'].append('embedding')

            # Step 2: Retrieve similar examples
            step_start = time.time()
            similar_questions, relevant_schemas = await self.vector_store.hybrid_search(
                client=client,
                query_embedding=question_embedding,
                top_k_questions=settings.RAG_TOP_K_RESULTS,
                top_k_schemas=3,
                similarity_threshold=settings.RAG_SIMILARITY_THRESHOLD
            )
            pipeline_metadata['timings']['retrieval'] = time.time() - step_start
            pipeline_metadata['steps'].append('retrieval')
            pipeline_metadata['retrieved_examples'] = len(similar_questions)
            pipeline_metadata['relevant_schemas'] = len(relevant_schemas)

            # Step 3: Get schema information
            step_start = time.time()
            schema_info = await db_connector.get_schema_info(client)
            pipeline_metadata['timings']['schema_fetch'] = time.time() - step_start
            pipeline_metadata['steps'].append('schema_fetch')

            # Step 4: Build context
            step_start = time.time()
            context = self.context_builder.build_sql_generation_context(
                client=client,
                user_question=question,
                similar_questions=similar_questions,
                relevant_schemas=relevant_schemas,
                full_schema_info=schema_info
            )
            pipeline_metadata['timings']['context_building'] = time.time() - step_start
            pipeline_metadata['steps'].append('context_building')

            # Step 5: Generate SQL
            step_start = time.time()
            sql_result = await sql_agent.generate_sql(
                client=client,
                question=question,
                db_connector=db_connector
            )
            pipeline_metadata['timings']['sql_generation'] = time.time() - step_start
            pipeline_metadata['steps'].append('sql_generation')

            # Step 6: Execute SQL
            step_start = time.time()
            query_results = []
            execution_error = None

            if sql_result.get('sql'):
                try:
                    query_results = await db_connector.fetch_all(
                        client=client,
                        query=sql_result['sql']
                    )
                except Exception as e:
                    execution_error = str(e)
                    logger.error(f"SQL execution failed: {execution_error}")

            pipeline_metadata['timings']['sql_execution'] = time.time() - step_start
            pipeline_metadata['steps'].append('sql_execution')

            # Calculate total time
            total_time = time.time() - start_time
            pipeline_metadata['timings']['total'] = total_time

            # Build response
            return {
                'success': True,
                'sql': sql_result.get('sql'),
                'results': query_results,
                'result_count': len(query_results),
                'execution_error': execution_error,
                'confidence': sql_result.get('confidence', 0.0),
                'similar_examples': similar_questions,
                'pipeline_metadata': pipeline_metadata,
                'total_time': total_time
            }

        except Exception as e:
            logger.error(f"RAG pipeline failed: {str(e)}")
            return {
                'success': False,
                'error': str(e),
                'pipeline_metadata': pipeline_metadata,
                'total_time': time.time() - start_time
            }

    async def train_client(
        self,
        client: Client,
        training_examples: List[Dict[str, str]],
        db_connector: MultiTenantDBConnector,
        sql_agent
    ) -> Dict[str, Any]:
        """Train the RAG pipeline for a new client.

        Args:
            client: Client object
            training_examples: List of {'question', 'sql'} pairs
            db_connector: Database connector
            sql_agent: SQL generation agent

        Returns:
            Training status dict
        """
        try:
            logger.info(f"Starting training for client: {client.name}")

            # Step 1: Train with examples
            await sql_agent.train_with_examples(
                client=client,
                training_examples=training_examples
            )

            # Step 2: Train with schema
            schema_info = await db_connector.get_schema_info(client)
            await sql_agent.train_with_schema(
                client=client,
                schema_info=schema_info
            )

            # Step 3: Verify training
            training_status = await sql_agent.get_training_status(client)

            logger.info(f"Training completed for {client.name}: {training_status['total_vectors']} vectors")

            return {
                'success': True,
                'client_name': client.name,
                'training_examples_count': len(training_examples),
                'total_vectors': training_status.get('total_vectors', 0),
                'is_trained': training_status.get('is_trained', False)
            }

        except Exception as e:
            logger.error(f"Training failed for {client.name}: {str(e)}")
            return {
                'success': False,
                'client_name': client.name,
                'error': str(e)
            }

    async def explain_query(
        self,
        client: Client,
        sql_query: str,
        question: str
    ) -> str:
        """Generate natural language explanation of a SQL query.

        Args:
            client: Client object
            sql_query: SQL query to explain
            question: Original question

        Returns:
            Natural language explanation
        """
        # Build explanation context
        explanation_prompt = f"""
You are explaining a SQL query to a non-technical user.

Original Question: {question}

SQL Query:
```sql
{sql_query}
```

Provide a clear, simple explanation of what this query does and what results it returns.
Use business language, avoid technical jargon.
"""

        # This would call OpenAI for explanation
        # For now, return a simple explanation
        return f"This query answers your question: '{question}' by searching the database."

    async def get_pipeline_stats(self) -> Dict[str, Any]:
        """Get statistics about the RAG pipeline.

        Returns:
            Dict with pipeline statistics
        """
        try:
            index_stats = self.vector_store.get_index_stats()

            return {
                'vector_store': {
                    'index_name': index_stats.get('index_name'),
                    'total_vectors': index_stats.get('total_vector_count', 0),
                    'total_namespaces': index_stats.get('namespaces', 0),
                    'dimension': index_stats.get('dimension')
                },
                'embedding_model': self.embedding_service.model,
                'embedding_dimension': self.embedding_service.get_embedding_dimension(),
                'default_top_k': settings.RAG_TOP_K_RESULTS,
                'similarity_threshold': settings.RAG_SIMILARITY_THRESHOLD
            }

        except Exception as e:
            logger.error(f"Failed to get pipeline stats: {str(e)}")
            return {'error': str(e)}

    async def close(self):
        """Close all pipeline components."""
        await self.embedding_service.close()
        logger.info("Closed RAG Pipeline")
