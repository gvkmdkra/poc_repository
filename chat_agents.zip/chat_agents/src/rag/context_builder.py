"""Context builder for RAG pipeline.

Assembles rich context from vector search results and schema information.
"""

from typing import List, Dict, Any, Optional
import logging

from ..models.client import Client

logger = logging.getLogger(__name__)


class ContextBuilder:
    """Builds rich context for SQL generation from retrieved examples and schemas.

    Combines:
    - Similar question-SQL pairs from vector search
    - Relevant database schemas
    - Client-specific business context
    - SQL best practices and constraints
    """

    def __init__(self):
        """Initialize context builder."""
        logger.info("Initialized context builder")

    def build_sql_generation_context(
        self,
        client: Client,
        user_question: str,
        similar_questions: List[Dict[str, Any]],
        relevant_schemas: List[Dict[str, Any]],
        full_schema_info: Dict[str, Any]
    ) -> str:
        """Build comprehensive context for SQL generation.

        Args:
            client: Client object with business context
            user_question: User's natural language question
            similar_questions: Similar Q&A pairs from vector search
            relevant_schemas: Relevant table schemas from vector search
            full_schema_info: Complete database schema information

        Returns:
            Formatted context string for GPT-4
        """
        context_parts = []

        # 1. System role and database information
        context_parts.append("# ROLE")
        context_parts.append("You are an expert SQL query generator for SQLite databases.")
        context_parts.append(f"You are helping {client.name}, a {client.industry or 'business'} company.")
        context_parts.append("")

        # 2. Database schema (complete)
        context_parts.append("# DATABASE SCHEMA")
        context_parts.append(self._format_schema_info(full_schema_info, client.schema_name))
        context_parts.append("")

        # 3. Similar examples (few-shot learning)
        if similar_questions:
            context_parts.append("# SIMILAR EXAMPLES")
            context_parts.append("Here are similar questions and their SQL queries:")
            context_parts.append("")

            for i, example in enumerate(similar_questions[:5], 1):
                similarity = example.get('similarity', 0) * 100
                context_parts.append(f"Example {i} (Similarity: {similarity:.1f}%):")
                context_parts.append(f"Question: {example['question']}")
                context_parts.append(f"SQL: {example['sql']}")
                context_parts.append("")

        # 4. Relevant schemas (focused)
        if relevant_schemas:
            context_parts.append("# MOST RELEVANT TABLES FOR THIS QUERY")
            for schema in relevant_schemas:
                context_parts.append(f"- {schema['table_name']}")
            context_parts.append("")

        # 5. SQL generation rules
        context_parts.append("# SQL GENERATION RULES")
        context_parts.append(self._get_sql_rules(client.schema_name))
        context_parts.append("")

        # 6. Business context (if available)
        if client.configuration.custom_greeting or client.industry:
            context_parts.append("# BUSINESS CONTEXT")
            if client.industry:
                context_parts.append(f"Industry: {client.industry}")
            if client.configuration.custom_greeting:
                context_parts.append(f"Note: {client.configuration.custom_greeting}")
            context_parts.append("")

        # 7. User question
        context_parts.append("# USER QUESTION")
        context_parts.append(user_question)
        context_parts.append("")

        # 8. Output format
        context_parts.append("# OUTPUT")
        context_parts.append("Generate ONLY the SQL query. No explanation, no markdown, just the query.")

        return "\n".join(context_parts)

    def _format_schema_info(self, schema_info: Dict[str, Any], schema_prefix: str) -> str:
        """Format database schema information into readable text.

        Args:
            schema_info: Schema metadata from database
            schema_prefix: Schema name prefix for tables

        Returns:
            Formatted schema description
        """
        lines = []

        if not schema_info or 'tables' not in schema_info:
            return "No schema information available."

        lines.append(f"Database contains {schema_info['table_count']} tables:")
        lines.append("")

        for table in schema_info['tables']:
            # Use clean table name (without prefix) for readability
            table_name = table.get('name', table.get('full_name', 'unknown'))
            full_name = table.get('full_name', f"{schema_prefix}_{table_name}")

            lines.append(f"Table: {full_name}")

            columns = table.get('columns', [])
            if columns:
                lines.append("Columns:")
                for col in columns:
                    col_line = f"  - {col['name']}: {col['type']}"

                    # Add constraints
                    constraints = []
                    if col.get('primary_key'):
                        constraints.append("PRIMARY KEY")
                    if not col.get('nullable', True):
                        constraints.append("NOT NULL")

                    if constraints:
                        col_line += f" ({', '.join(constraints)})"

                    lines.append(col_line)
            else:
                lines.append("  (No column information available)")

            lines.append("")

        return "\n".join(lines)

    def _get_sql_rules(self, schema_prefix: str) -> str:
        """Get SQL generation rules and constraints.

        Args:
            schema_prefix: Schema name prefix for tables

        Returns:
            Formatted rules string
        """
        rules = [
            "1. ALWAYS use full table names with prefix: {schema_prefix}_tablename",
            "2. Use SQLite syntax (NOT PostgreSQL, MySQL, or other variants)",
            "3. Always use explicit column names (avoid SELECT *)",
            "4. Include LIMIT clause for queries that might return many rows (default: LIMIT 100)",
            "5. Use proper JOIN syntax when combining tables",
            "6. Handle NULL values appropriately",
            "7. Use CASE WHEN for conditional logic",
            "8. For aggregations, always include GROUP BY clause",
            "9. Use single quotes for string literals",
            "10. Return only valid, executable SQL - no placeholders or comments"
        ]

        return "\n".join(rules).format(schema_prefix=schema_prefix)

    def build_chat_context(
        self,
        client: Client,
        conversation_history: List[Dict[str, str]],
        similar_questions: Optional[List[Dict[str, Any]]] = None
    ) -> str:
        """Build context for general chat (non-SQL) responses.

        Args:
            client: Client object
            conversation_history: Previous messages in conversation
            similar_questions: Optional similar questions for reference

        Returns:
            Formatted context for chat response
        """
        context_parts = []

        # System role
        context_parts.append("# ROLE")
        context_parts.append(f"You are an AI assistant for {client.name}.")

        if client.industry:
            context_parts.append(f"Industry: {client.industry}")

        if client.configuration.custom_greeting:
            context_parts.append(f"Greeting: {client.configuration.custom_greeting}")

        context_parts.append("")

        # Conversation history
        if conversation_history:
            context_parts.append("# CONVERSATION HISTORY")
            for msg in conversation_history[-5:]:  # Last 5 messages
                role = msg.get('role', 'user')
                content = msg.get('content', '')
                context_parts.append(f"{role.upper()}: {content}")
            context_parts.append("")

        # Similar examples (if provided)
        if similar_questions:
            context_parts.append("# RELATED QUESTIONS")
            for example in similar_questions[:3]:
                context_parts.append(f"- {example['question']}")
            context_parts.append("")

        context_parts.append("# INSTRUCTIONS")
        context_parts.append("Provide a helpful, accurate, and friendly response.")
        context_parts.append("Stay in character as the company's AI assistant.")
        context_parts.append("")

        return "\n".join(context_parts)

    def build_error_recovery_context(
        self,
        client: Client,
        original_question: str,
        failed_sql: str,
        error_message: str,
        schema_info: Dict[str, Any]
    ) -> str:
        """Build context for error recovery and SQL correction.

        Args:
            client: Client object
            original_question: User's original question
            failed_sql: SQL query that failed
            error_message: Error message from database
            schema_info: Database schema information

        Returns:
            Context for SQL correction
        """
        context_parts = []

        context_parts.append("# SQL ERROR RECOVERY")
        context_parts.append("")

        context_parts.append("## Original Question")
        context_parts.append(original_question)
        context_parts.append("")

        context_parts.append("## Failed SQL Query")
        context_parts.append(f"```sql\n{failed_sql}\n```")
        context_parts.append("")

        context_parts.append("## Error Message")
        context_parts.append(error_message)
        context_parts.append("")

        context_parts.append("## Database Schema")
        context_parts.append(self._format_schema_info(schema_info, client.schema_name))
        context_parts.append("")

        context_parts.append("## Task")
        context_parts.append("Analyze the error and generate a corrected SQL query that will execute successfully.")
        context_parts.append("Common issues to check:")
        context_parts.append("- Table names must include schema prefix")
        context_parts.append("- Column names must match schema exactly")
        context_parts.append("- Syntax must be valid SQLite")
        context_parts.append("- JOIN conditions must be valid")
        context_parts.append("")

        context_parts.append("## Output")
        context_parts.append("Provide ONLY the corrected SQL query.")
        context_parts.append("")

        return "\n".join(context_parts)

    def extract_key_terms(self, question: str) -> List[str]:
        """Extract key terms from question for enhanced retrieval.

        Args:
            question: User's question

        Returns:
            List of key terms
        """
        # Simple keyword extraction (can be enhanced with NLP)
        stopwords = {
            'a', 'an', 'the', 'is', 'are', 'was', 'were', 'be', 'been',
            'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would',
            'could', 'should', 'may', 'might', 'can', 'of', 'at', 'by',
            'for', 'with', 'about', 'against', 'between', 'into', 'through',
            'during', 'before', 'after', 'above', 'below', 'to', 'from',
            'up', 'down', 'in', 'out', 'on', 'off', 'over', 'under', 'me',
            'my', 'show', 'get', 'find', 'tell'
        }

        # Tokenize and filter
        words = question.lower().split()
        key_terms = [w.strip('?.,!') for w in words if w not in stopwords and len(w) > 2]

        return key_terms

    def format_sql_result_context(
        self,
        sql_query: str,
        results: List[Dict[str, Any]],
        execution_time: float
    ) -> str:
        """Format SQL execution results into readable context.

        Args:
            sql_query: Executed SQL query
            results: Query results
            execution_time: Query execution time in seconds

        Returns:
            Formatted result summary
        """
        context_parts = []

        context_parts.append("# SQL QUERY")
        context_parts.append(f"```sql\n{sql_query}\n```")
        context_parts.append("")

        context_parts.append("# RESULTS")
        context_parts.append(f"Returned {len(results)} row(s) in {execution_time:.3f} seconds")
        context_parts.append("")

        if results:
            # Show first few rows
            context_parts.append("Sample data:")
            for i, row in enumerate(results[:5], 1):
                context_parts.append(f"Row {i}: {row}")

            if len(results) > 5:
                context_parts.append(f"... and {len(results) - 5} more rows")

        else:
            context_parts.append("(No results returned)")

        return "\n".join(context_parts)
