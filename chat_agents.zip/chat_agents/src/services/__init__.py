"""Service layer for business logic."""

from .client_service import ClientService

__all__ = ["ClientService"]
