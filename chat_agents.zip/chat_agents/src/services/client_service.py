"""Client service for managing multi-tenant clients.

Provides CRUD operations and business logic for client management.
"""

import libsql_client
from typing import Optional, List, Dict, Any
from uuid import UUID, uuid4
from datetime import datetime
import logging

from ..models.client import (
    Client,
    ClientCreate,
    ClientUpdate,
    ClientConfig,
    generate_api_key,
    generate_schema_name,
    generate_embedding_namespace
)
from ..config import settings

logger = logging.getLogger(__name__)


class ClientService:
    """Service for managing client accounts and configurations.

    Handles:
    - Client CRUD operations
    - API key management
    - Schema provisioning
    - Client validation
    """

    def __init__(self, db_url: Optional[str] = None, db_auth_token: Optional[str] = None):
        """Initialize client service.

        Args:
            db_url: Master database URL (defaults to settings)
            db_auth_token: Master database auth token (defaults to settings)
        """
        self.db_url = db_url or settings.TURSO_DB_URL
        self.db_auth_token = db_auth_token or settings.TURSO_DB_AUTH_TOKEN
        self.client = None
        self._initialize_db()

    def _initialize_db(self):
        """Initialize database connection and create clients table if needed."""
        try:
            self.client = libsql_client.create_client_sync(
                url=self.db_url,
                auth_token=self.db_auth_token
            )

            # Create clients table for storing client metadata
            create_table_sql = """
                CREATE TABLE IF NOT EXISTS system_clients (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    schema_name TEXT UNIQUE NOT NULL,
                    api_key TEXT UNIQUE NOT NULL,
                    embedding_namespace TEXT NOT NULL,
                    db_url TEXT NOT NULL,
                    db_auth_token TEXT NOT NULL,

                    -- Configuration (stored as JSON)
                    config_max_queries_per_minute INTEGER DEFAULT 100,
                    config_max_embeddings_per_day INTEGER DEFAULT 10000,
                    config_enable_voice_calls INTEGER DEFAULT 1,
                    config_enable_sms INTEGER DEFAULT 1,
                    config_enable_whatsapp INTEGER DEFAULT 0,
                    config_auto_visualize INTEGER DEFAULT 1,
                    config_default_chart_type TEXT DEFAULT 'bar',
                    config_custom_greeting TEXT,

                    -- Business metadata
                    industry TEXT,
                    contact_email TEXT NOT NULL,
                    contact_phone TEXT,

                    -- Status and tracking
                    is_active INTEGER DEFAULT 1,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    last_query_at TEXT,
                    total_queries INTEGER DEFAULT 0,
                    total_embeddings INTEGER DEFAULT 0
                )
            """

            self.client.execute(create_table_sql)
            logger.info("Client service initialized, system_clients table ready")

        except Exception as e:
            logger.error(f"Failed to initialize client service: {str(e)}")
            raise

    async def create_client(self, client_create: ClientCreate) -> Client:
        """Create a new client account.

        Args:
            client_create: Client creation request

        Returns:
            Created client object

        Raises:
            ValueError: If client name already exists
        """
        # Generate unique identifiers
        client_id = uuid4()
        api_key = generate_api_key()
        schema_name = generate_schema_name(client_id)
        embedding_namespace = generate_embedding_namespace(client_id)

        # Use provided DB credentials or default to system DB
        db_url = client_create.db_url or self.db_url
        db_auth_token = client_create.db_auth_token or self.db_auth_token

        # Use provided config or defaults
        config = client_create.configuration or ClientConfig()

        # Create client object
        client = Client(
            id=client_id,
            name=client_create.name,
            schema_name=schema_name,
            api_key=api_key,
            embedding_namespace=embedding_namespace,
            db_url=db_url,
            db_auth_token=db_auth_token,
            configuration=config,
            industry=client_create.industry,
            contact_email=client_create.contact_email,
            contact_phone=client_create.contact_phone,
            is_active=True,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow()
        )

        # Insert into database
        try:
            insert_sql = """
                INSERT INTO system_clients (
                    id, name, schema_name, api_key, embedding_namespace,
                    db_url, db_auth_token,
                    config_max_queries_per_minute, config_max_embeddings_per_day,
                    config_enable_voice_calls, config_enable_sms, config_enable_whatsapp,
                    config_auto_visualize, config_default_chart_type, config_custom_greeting,
                    industry, contact_email, contact_phone,
                    is_active, created_at, updated_at,
                    total_queries, total_embeddings
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """

            self.client.execute(insert_sql, [
                str(client.id),
                client.name,
                client.schema_name,
                client.api_key,
                client.embedding_namespace,
                client.db_url,
                client.db_auth_token,
                config.max_queries_per_minute,
                config.max_embeddings_per_day,
                1 if config.enable_voice_calls else 0,
                1 if config.enable_sms else 0,
                1 if config.enable_whatsapp else 0,
                1 if config.auto_visualize else 0,
                config.default_chart_type,
                config.custom_greeting,
                client.industry,
                client.contact_email,
                client.contact_phone,
                1 if client.is_active else 0,
                client.created_at.isoformat(),
                client.updated_at.isoformat(),
                0,
                0
            ])

            logger.info(f"Created new client: {client.name} (ID: {client.id}, Schema: {schema_name})")
            return client

        except Exception as e:
            logger.error(f"Failed to create client {client_create.name}: {str(e)}")
            raise ValueError(f"Failed to create client: {str(e)}")

    async def get_by_id(self, client_id: UUID) -> Optional[Client]:
        """Get client by ID.

        Args:
            client_id: Client UUID

        Returns:
            Client object or None if not found
        """
        try:
            result = self.client.execute(
                "SELECT * FROM system_clients WHERE id = ?",
                [str(client_id)]
            )

            if hasattr(result, 'rows') and result.rows:
                return self._row_to_client(result.rows[0])

            return None

        except Exception as e:
            logger.error(f"Failed to get client by ID {client_id}: {str(e)}")
            return None

    async def get_by_api_key(self, api_key: str) -> Optional[Client]:
        """Get client by API key.

        Args:
            api_key: Client API key

        Returns:
            Client object or None if not found
        """
        try:
            result = self.client.execute(
                "SELECT * FROM system_clients WHERE api_key = ?",
                [api_key]
            )

            if hasattr(result, 'rows') and result.rows:
                return self._row_to_client(result.rows[0])

            return None

        except Exception as e:
            logger.error(f"Failed to get client by API key: {str(e)}")
            return None

    async def get_by_schema_name(self, schema_name: str) -> Optional[Client]:
        """Get client by schema name.

        Args:
            schema_name: Database schema name

        Returns:
            Client object or None if not found
        """
        try:
            result = self.client.execute(
                "SELECT * FROM system_clients WHERE schema_name = ?",
                [schema_name]
            )

            if hasattr(result, 'rows') and result.rows:
                return self._row_to_client(result.rows[0])

            return None

        except Exception as e:
            logger.error(f"Failed to get client by schema {schema_name}: {str(e)}")
            return None

    async def list_clients(
        self,
        is_active: Optional[bool] = None,
        industry: Optional[str] = None,
        limit: int = 100,
        offset: int = 0
    ) -> List[Client]:
        """List clients with optional filtering.

        Args:
            is_active: Filter by active status (optional)
            industry: Filter by industry (optional)
            limit: Maximum number of results
            offset: Results offset for pagination

        Returns:
            List of client objects
        """
        try:
            query = "SELECT * FROM system_clients WHERE 1=1"
            params = []

            if is_active is not None:
                query += " AND is_active = ?"
                params.append(1 if is_active else 0)

            if industry:
                query += " AND industry = ?"
                params.append(industry)

            query += " ORDER BY created_at DESC LIMIT ? OFFSET ?"
            params.extend([limit, offset])

            result = self.client.execute(query, params)

            clients = []
            if hasattr(result, 'rows'):
                for row in result.rows:
                    clients.append(self._row_to_client(row))

            return clients

        except Exception as e:
            logger.error(f"Failed to list clients: {str(e)}")
            return []

    async def update_client(self, client_id: UUID, client_update: ClientUpdate) -> Optional[Client]:
        """Update client information.

        Args:
            client_id: Client UUID
            client_update: Fields to update

        Returns:
            Updated client object or None if not found
        """
        try:
            # Get existing client
            existing = await self.get_by_id(client_id)
            if not existing:
                return None

            # Build update query dynamically based on provided fields
            update_fields = []
            params = []

            if client_update.name is not None:
                update_fields.append("name = ?")
                params.append(client_update.name)

            if client_update.industry is not None:
                update_fields.append("industry = ?")
                params.append(client_update.industry)

            if client_update.contact_email is not None:
                update_fields.append("contact_email = ?")
                params.append(client_update.contact_email)

            if client_update.contact_phone is not None:
                update_fields.append("contact_phone = ?")
                params.append(client_update.contact_phone)

            if client_update.is_active is not None:
                update_fields.append("is_active = ?")
                params.append(1 if client_update.is_active else 0)

            if client_update.configuration is not None:
                config = client_update.configuration
                update_fields.extend([
                    "config_max_queries_per_minute = ?",
                    "config_max_embeddings_per_day = ?",
                    "config_enable_voice_calls = ?",
                    "config_enable_sms = ?",
                    "config_enable_whatsapp = ?",
                    "config_auto_visualize = ?",
                    "config_default_chart_type = ?",
                    "config_custom_greeting = ?"
                ])
                params.extend([
                    config.max_queries_per_minute,
                    config.max_embeddings_per_day,
                    1 if config.enable_voice_calls else 0,
                    1 if config.enable_sms else 0,
                    1 if config.enable_whatsapp else 0,
                    1 if config.auto_visualize else 0,
                    config.default_chart_type,
                    config.custom_greeting
                ])

            if not update_fields:
                return existing  # No updates

            # Always update updated_at timestamp
            update_fields.append("updated_at = ?")
            params.append(datetime.utcnow().isoformat())

            # Add client_id for WHERE clause
            params.append(str(client_id))

            update_sql = f"""
                UPDATE system_clients
                SET {', '.join(update_fields)}
                WHERE id = ?
            """

            self.client.execute(update_sql, params)

            logger.info(f"Updated client: {client_id}")

            # Return updated client
            return await self.get_by_id(client_id)

        except Exception as e:
            logger.error(f"Failed to update client {client_id}: {str(e)}")
            return None

    async def delete_client(self, client_id: UUID) -> bool:
        """Delete a client (soft delete by setting is_active=False).

        Args:
            client_id: Client UUID

        Returns:
            True if deleted, False if not found
        """
        try:
            result = self.client.execute(
                "UPDATE system_clients SET is_active = 0, updated_at = ? WHERE id = ?",
                [datetime.utcnow().isoformat(), str(client_id)]
            )

            logger.info(f"Soft-deleted client: {client_id}")
            return True

        except Exception as e:
            logger.error(f"Failed to delete client {client_id}: {str(e)}")
            return False

    async def update_last_query(self, client_id: UUID):
        """Update last query timestamp and increment query counter.

        Args:
            client_id: Client UUID
        """
        try:
            self.client.execute(
                """
                UPDATE system_clients
                SET last_query_at = ?,
                    total_queries = total_queries + 1,
                    updated_at = ?
                WHERE id = ?
                """,
                [datetime.utcnow().isoformat(), datetime.utcnow().isoformat(), str(client_id)]
            )

        except Exception as e:
            logger.warning(f"Failed to update last query for {client_id}: {str(e)}")

    async def increment_embeddings(self, client_id: UUID, count: int = 1):
        """Increment embedding counter for client.

        Args:
            client_id: Client UUID
            count: Number of embeddings to add
        """
        try:
            self.client.execute(
                """
                UPDATE system_clients
                SET total_embeddings = total_embeddings + ?,
                    updated_at = ?
                WHERE id = ?
                """,
                [count, datetime.utcnow().isoformat(), str(client_id)]
            )

        except Exception as e:
            logger.warning(f"Failed to increment embeddings for {client_id}: {str(e)}")

    def _row_to_client(self, row) -> Client:
        """Convert database row to Client object.

        Args:
            row: Database row

        Returns:
            Client object
        """
        # Handle different row formats
        if isinstance(row, dict):
            data = row
        elif hasattr(row, 'as_dict'):
            data = row.as_dict()
        elif hasattr(row, '_asdict'):
            data = row._asdict()
        else:
            # Assume it's a tuple/list with fixed column order
            data = {
                'id': row[0], 'name': row[1], 'schema_name': row[2],
                'api_key': row[3], 'embedding_namespace': row[4],
                'db_url': row[5], 'db_auth_token': row[6],
                'config_max_queries_per_minute': row[7],
                'config_max_embeddings_per_day': row[8],
                'config_enable_voice_calls': row[9],
                'config_enable_sms': row[10],
                'config_enable_whatsapp': row[11],
                'config_auto_visualize': row[12],
                'config_default_chart_type': row[13],
                'config_custom_greeting': row[14],
                'industry': row[15],
                'contact_email': row[16],
                'contact_phone': row[17],
                'is_active': row[18],
                'created_at': row[19],
                'updated_at': row[20],
                'last_query_at': row[21],
                'total_queries': row[22],
                'total_embeddings': row[23]
            }

        # Build ClientConfig
        config = ClientConfig(
            max_queries_per_minute=data.get('config_max_queries_per_minute', 100),
            max_embeddings_per_day=data.get('config_max_embeddings_per_day', 10000),
            enable_voice_calls=bool(data.get('config_enable_voice_calls', 1)),
            enable_sms=bool(data.get('config_enable_sms', 1)),
            enable_whatsapp=bool(data.get('config_enable_whatsapp', 0)),
            auto_visualize=bool(data.get('config_auto_visualize', 1)),
            default_chart_type=data.get('config_default_chart_type', 'bar'),
            custom_greeting=data.get('config_custom_greeting')
        )

        # Build Client object
        return Client(
            id=UUID(data['id']),
            name=data['name'],
            schema_name=data['schema_name'],
            api_key=data['api_key'],
            embedding_namespace=data['embedding_namespace'],
            db_url=data['db_url'],
            db_auth_token=data['db_auth_token'],
            configuration=config,
            industry=data.get('industry'),
            contact_email=data['contact_email'],
            contact_phone=data.get('contact_phone'),
            is_active=bool(data.get('is_active', 1)),
            created_at=datetime.fromisoformat(data['created_at']),
            updated_at=datetime.fromisoformat(data['updated_at']),
            last_query_at=datetime.fromisoformat(data['last_query_at']) if data.get('last_query_at') else None,
            total_queries=data.get('total_queries', 0),
            total_embeddings=data.get('total_embeddings', 0)
        )
