"""Enterprise Multi-Tenant API with OpenAI RAG Integration.

This is the updated API that replaces Gemini with OpenAI GPT-4 and adds
multi-tenant support with authentication.
"""

from fastapi import FastAPI, HTTPException, Request, Form, Header, Depends
from fastapi.responses import Response
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, Dict, Any, List
from uuid import UUID
import logging
from contextlib import asynccontextmanager

from .config import settings
from .models.client import Client, ClientCreate, ClientUpdate
from .services.client_service import ClientService
from .middleware.auth import ClientAuthMiddleware, get_current_client
from .db.multi_tenant_connector import MultiTenantDBConnector
from .sql.openai_rag_agent import OpenAIRAGAgent
from .rag.rag_pipeline import RAGPipeline
from .twilio_handler import TwilioHandler

logging.basicConfig(level=settings.LOG_LEVEL)
logger = logging.getLogger(__name__)

# Global services
client_service: Optional[ClientService] = None
db_connector: Optional[MultiTenantDBConnector] = None
sql_agent: Optional[OpenAIRAGAgent] = None
rag_pipeline: Optional[RAGPipeline] = None
twilio_handler: Optional[TwilioHandler] = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialize and cleanup services on app startup/shutdown."""
    global client_service, db_connector, sql_agent, rag_pipeline, twilio_handler

    logger.info("Initializing enterprise multi-tenant services...")

    # Initialize services
    client_service = ClientService()
    db_connector = MultiTenantDBConnector()
    sql_agent = OpenAIRAGAgent()
    rag_pipeline = RAGPipeline()
    twilio_handler = TwilioHandler()

    logger.info("All services initialized successfully")

    yield

    # Cleanup
    logger.info("Shutting down services...")
    await db_connector.close_all_connections()
    await sql_agent.close()
    await rag_pipeline.close()
    logger.info("All services closed")


app = FastAPI(
    title="Enterprise Multi-Tenant Chat Agent API",
    description="AI-powered chat agent with OpenAI GPT-4, RAG, and multi-tenant support",
    version="2.0.0",
    lifespan=lifespan
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Add authentication middleware with callable to get client_service
# This allows the middleware to access client_service after it's initialized in lifespan
def get_client_service():
    """Get the global client_service instance."""
    return client_service

app.add_middleware(ClientAuthMiddleware, get_client_service=get_client_service)


# ============================================================================
# REQUEST/RESPONSE MODELS
# ============================================================================

class ChatMessage(BaseModel):
    message: str
    context: Optional[Dict[str, Any]] = None
    check_sql: bool = True


class TrainingExample(BaseModel):
    question: str
    sql: str


class TrainingRequest(BaseModel):
    examples: List[TrainingExample]


class VoiceCallRequest(BaseModel):
    to: str
    message: Optional[str] = "Hello! This is your AI assistant calling."


class SMSMessage(BaseModel):
    to: str
    message: str


# ============================================================================
# PUBLIC ENDPOINTS (No Authentication Required)
# ============================================================================

@app.get("/")
async def root():
    """API information and available endpoints."""
    return {
        "service": "Enterprise Multi-Tenant Chat Agent API",
        "version": "2.0.0",
        "status": "running",
        "architecture": "OpenAI GPT-4 + RAG + Multi-Tenant",
        "endpoints": {
            "public": {
                "health": "/health",
                "docs": "/docs"
            },
            "client_management": {
                "create_client": "POST /clients",
                "list_clients": "GET /clients",
                "get_client": "GET /clients/{client_id}",
                "update_client": "PUT /clients/{client_id}"
            },
            "chat": {
                "chat": "POST /chat",
                "history": "GET /history",
                "clear_history": "DELETE /history"
            },
            "training": {
                "train": "POST /train",
                "training_status": "GET /training/status"
            },
            "database": {
                "refresh_schema": "POST /refresh-schema",
                "get_schema": "GET /schema"
            },
            "voice": {
                "make_call": "POST /call/make",
                "voice_webhook": "POST /webhook/voice",
                "voice_response": "POST /webhook/voice/response"
            },
            "messaging": {
                "send_sms": "POST /sms/send",
                "send_whatsapp": "POST /whatsapp/send",
                "twilio_webhook": "POST /webhook/twilio"
            }
        },
        "authentication": "Required: X-API-Key header (except public endpoints)"
    }


@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "services": {
            "client_service": client_service is not None,
            "db_connector": db_connector is not None,
            "sql_agent": sql_agent is not None,
            "rag_pipeline": rag_pipeline is not None,
            "twilio": twilio_handler is not None
        },
        "architecture": {
            "multi_tenant": True,
            "rag_enabled": True,
            "llm": "OpenAI GPT-4",
            "vector_db": "Pinecone",
            "database": "Turso (LibSQL)"
        }
    }


# ============================================================================
# CLIENT MANAGEMENT ENDPOINTS (Admin Access)
# ============================================================================

@app.post("/clients", response_model=Client)
async def create_client(client_create: ClientCreate):
    """Create a new client account.

    This creates:
    - Unique API key
    - Database schema
    - Vector namespace
    - Client configuration
    """
    try:
        client = await client_service.create_client(client_create)

        # Initialize client's database schema
        await db_connector.get_connection(client)

        logger.info(f"Created new client: {client.name} (ID: {client.id})")

        return client

    except Exception as e:
        logger.error(f"Failed to create client: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to create client: {str(e)}")


@app.get("/clients")
async def list_clients(
    is_active: Optional[bool] = None,
    industry: Optional[str] = None,
    limit: int = 100,
    offset: int = 0
):
    """List all clients with optional filtering."""
    try:
        clients = await client_service.list_clients(
            is_active=is_active,
            industry=industry,
            limit=limit,
            offset=offset
        )

        return {
            "clients": clients,
            "count": len(clients),
            "limit": limit,
            "offset": offset
        }

    except Exception as e:
        logger.error(f"Failed to list clients: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/clients/{client_id}", response_model=Client)
async def get_client(client_id: UUID):
    """Get client details by ID."""
    try:
        client = await client_service.get_by_id(client_id)

        if not client:
            raise HTTPException(status_code=404, detail="Client not found")

        return client

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get client: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.put("/clients/{client_id}", response_model=Client)
async def update_client(client_id: UUID, client_update: ClientUpdate):
    """Update client information."""
    try:
        client = await client_service.update_client(client_id, client_update)

        if not client:
            raise HTTPException(status_code=404, detail="Client not found")

        return client

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to update client: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# CHAT ENDPOINTS (Requires Authentication)
# ============================================================================

@app.post("/chat")
async def chat(
    message: ChatMessage,
    client: Client = Depends(get_current_client)
):
    """Process chat message with RAG-powered SQL generation.

    Requires X-API-Key header for authentication.
    """
    try:
        if message.check_sql:
            # Use RAG pipeline for SQL generation
            result = await rag_pipeline.process_query(
                client=client,
                question=message.message,
                db_connector=db_connector,
                sql_agent=sql_agent
            )

            return {
                "response": f"Found {result['result_count']} results",
                "sql": result.get('sql'),
                "results": result.get('results', []),
                "confidence": result.get('confidence', 0.0),
                "similar_examples": result.get('similar_examples', []),
                "execution_time": result.get('total_time', 0.0),
                "metadata": result.get('pipeline_metadata', {})
            }

        else:
            # General chat (non-SQL)
            # For now, return simple response
            # TODO: Implement OpenAI chat completion for general queries
            return {
                "response": "General chat not yet implemented. Set check_sql=true for database queries."
            }

    except Exception as e:
        logger.error(f"Chat error for client {client.name}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/history")
async def get_history(client: Client = Depends(get_current_client)):
    """Get conversation history for client.

    TODO: Implement conversation history storage.
    """
    return {
        "client_id": str(client.id),
        "client_name": client.name,
        "history": [],
        "message": "Conversation history not yet implemented"
    }


@app.delete("/history")
async def clear_history(client: Client = Depends(get_current_client)):
    """Clear conversation history for client."""
    return {
        "client_id": str(client.id),
        "message": "History cleared (feature not yet implemented)"
    }


# ============================================================================
# TRAINING ENDPOINTS
# ============================================================================

@app.post("/train")
async def train_agent(
    training: TrainingRequest,
    client: Client = Depends(get_current_client)
):
    """Train the RAG agent with question-SQL examples.

    Examples are embedded and stored in Pinecone for semantic search.
    """
    try:
        training_examples = [
            {"question": ex.question, "sql": ex.sql}
            for ex in training.examples
        ]

        result = await rag_pipeline.train_client(
            client=client,
            training_examples=training_examples,
            db_connector=db_connector,
            sql_agent=sql_agent
        )

        return {
            "success": result.get('success', False),
            "client_name": client.name,
            "examples_trained": result.get('training_examples_count', 0),
            "total_vectors": result.get('total_vectors', 0),
            "message": f"Successfully trained {len(training_examples)} examples"
        }

    except Exception as e:
        logger.error(f"Training failed for client {client.name}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/training/status")
async def get_training_status(client: Client = Depends(get_current_client)):
    """Get training status and statistics for client."""
    try:
        status = await sql_agent.get_training_status(client)

        return {
            "client_name": client.name,
            "is_trained": status.get('is_trained', False),
            "total_vectors": status.get('total_vectors', 0),
            "namespace": status.get('namespace')
        }

    except Exception as e:
        logger.error(f"Failed to get training status: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# DATABASE SCHEMA ENDPOINTS
# ============================================================================

@app.post("/refresh-schema")
async def refresh_schema(client: Client = Depends(get_current_client)):
    """Refresh cached database schema for client."""
    try:
        await db_connector.refresh_schema_cache(client)
        schema_info = await db_connector.get_schema_info(client)

        return {
            "message": "Schema cache refreshed successfully",
            "client_name": client.name,
            "schema_name": client.schema_name,
            "table_count": schema_info.get('table_count', 0),
            "tables": [t['name'] for t in schema_info.get('tables', [])]
        }

    except Exception as e:
        logger.error(f"Schema refresh failed for {client.name}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/schema")
async def get_schema(client: Client = Depends(get_current_client)):
    """Get complete database schema for client."""
    try:
        schema_info = await db_connector.get_schema_info(client)
        return schema_info

    except Exception as e:
        logger.error(f"Failed to get schema for {client.name}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# VOICE CALLING ENDPOINTS
# ============================================================================

@app.post("/call/make")
async def make_call(
    call_request: VoiceCallRequest,
    client: Client = Depends(get_current_client)
):
    """Initiate an outbound voice call."""
    if not client.configuration.enable_voice_calls:
        raise HTTPException(
            status_code=403,
            detail="Voice calling not enabled for this client"
        )

    try:
        result = await twilio_handler.make_voice_call(
            to_number=call_request.to,
            message=call_request.message
        )

        if not result.get("success"):
            raise HTTPException(status_code=400, detail=result.get("error"))

        return {
            **result,
            "client_name": client.name
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Call failed for {client.name}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/webhook/voice")
async def voice_webhook(request: Request):
    """Handle incoming Twilio voice calls.

    Note: This endpoint doesn't require API key auth (Twilio uses signature validation)
    """
    try:
        form_data = await request.form()
        from_number = form_data.get("From", "")
        call_sid = form_data.get("CallSid", "")

        logger.info(f"Incoming call from {from_number}, SID: {call_sid}")

        twiml = """<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Say voice="alice">Hello! Thank you for calling the AI Agent. How can I help you today?</Say>
    <Gather input="speech" action="/webhook/voice/response" method="POST" timeout="3" speechTimeout="auto">
        <Say voice="alice">Please speak your question after the beep.</Say>
    </Gather>
    <Say voice="alice">I didn't receive any input. Goodbye!</Say>
</Response>"""

        return Response(content=twiml, media_type="application/xml")

    except Exception as e:
        logger.error(f"Voice webhook error: {str(e)}")
        error_twiml = """<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Say voice="alice">Sorry, there was an error. Please try again later.</Say>
</Response>"""
        return Response(content=error_twiml, media_type="application/xml")


@app.post("/webhook/voice/response")
async def voice_response_webhook(
    request: Request,
    SpeechResult: Optional[str] = Form(None),
    From: str = Form(...),
    CallSid: str = Form(...)
):
    """Process speech input and generate AI response.

    TODO: Identify client from phone number or add client context to call
    """
    try:
        if not SpeechResult:
            twiml = """<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Say voice="alice">I didn't catch that. Please try calling again.</Say>
</Response>"""
            return Response(content=twiml, media_type="application/xml")

        logger.info(f"Voice input from {From}: {SpeechResult}")

        # TODO: Implement client identification for voice calls
        # For now, return generic response
        ai_response = "Voice processing with multi-tenant support coming soon."

        twiml = f"""<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Say voice="alice">{ai_response}</Say>
    <Say voice="alice">Is there anything else I can help you with?</Say>
    <Gather input="speech" action="/webhook/voice/response" method="POST" timeout="3" speechTimeout="auto">
        <Say voice="alice">Please speak your next question, or hang up if you're done.</Say>
    </Gather>
    <Say voice="alice">Thank you for calling. Goodbye!</Say>
</Response>"""

        return Response(content=twiml, media_type="application/xml")

    except Exception as e:
        logger.error(f"Voice response error: {str(e)}")
        error_twiml = """<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Say voice="alice">Sorry, I encountered an error. Please try again.</Say>
</Response>"""
        return Response(content=error_twiml, media_type="application/xml")


# ============================================================================
# MESSAGING ENDPOINTS (SMS / WhatsApp)
# ============================================================================

@app.post("/sms/send")
async def send_sms(
    sms: SMSMessage,
    client: Client = Depends(get_current_client)
):
    """Send SMS message."""
    if not client.configuration.enable_sms:
        raise HTTPException(
            status_code=403,
            detail="SMS not enabled for this client"
        )

    try:
        result = await twilio_handler.send_sms(sms.to, sms.message)

        if not result.get("success"):
            raise HTTPException(status_code=400, detail=result.get("error"))

        return result

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"SMS failed for {client.name}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/whatsapp/send")
async def send_whatsapp(
    message: SMSMessage,
    client: Client = Depends(get_current_client)
):
    """Send WhatsApp message."""
    if not client.configuration.enable_whatsapp:
        raise HTTPException(
            status_code=403,
            detail="WhatsApp not enabled for this client"
        )

    try:
        result = await twilio_handler.send_whatsapp(message.to, message.message)

        if not result.get("success"):
            raise HTTPException(status_code=400, detail=result.get("error"))

        return result

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"WhatsApp failed for {client.name}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/webhook/twilio")
async def twilio_webhook(
    request: Request,
    From: str = Form(...),
    Body: str = Form(...),
    MessageSid: str = Form(...),
    x_twilio_signature: Optional[str] = Header(None)
):
    """Handle incoming SMS/WhatsApp messages from Twilio.

    TODO: Implement client identification and message processing
    """
    try:
        is_whatsapp = From.startswith("whatsapp:")
        message_type = "WhatsApp" if is_whatsapp else "SMS"

        logger.info(f"Incoming {message_type} from {From}: {Body}")

        # TODO: Identify client and process message
        response_text = "Message received. Multi-tenant processing coming soon."

        twiml_response = twilio_handler.create_twiml_response(response_text)
        return Response(content=twiml_response, media_type="application/xml")

    except Exception as e:
        logger.error(f"Twilio webhook error: {str(e)}")
        error_response = twilio_handler.create_twiml_response(
            "Sorry, there was an error processing your message."
        )
        return Response(content=error_response, media_type="application/xml")


# ============================================================================
# RAG PIPELINE STATUS
# ============================================================================

@app.get("/rag/stats")
async def get_rag_stats():
    """Get RAG pipeline statistics."""
    try:
        stats = await rag_pipeline.get_pipeline_stats()
        return stats

    except Exception as e:
        logger.error(f"Failed to get RAG stats: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
