from pydantic_settings import BaseSettings
from pydantic import Field
from typing import Optional


class Settings(BaseSettings):
    # OpenAI Configuration (Primary LLM - GPT-4)
    OPENAI_API_KEY: str = Field(..., description="OpenAI API key for GPT-4 and embeddings")
    OPENAI_MODEL: str = Field(default="gpt-4-turbo-preview", description="OpenAI model to use")
    OPENAI_EMBEDDING_MODEL: str = Field(default="text-embedding-3-large", description="OpenAI embedding model")

    # Vector Database (Pinecone)
    PINECONE_API_KEY: str = Field(..., description="Pinecone API key for vector storage")
    PINECONE_ENVIRONMENT: str = Field(..., description="Pinecone environment (e.g., us-west1-gcp)")
    PINECONE_INDEX_NAME: str = Field(default="chat-agent-embeddings", description="Pinecone index name")

    # Turso Database Configuration
    TURSO_DB_URL: str = Field(..., description="Turso database URL")
    TURSO_DB_AUTH_TOKEN: str = Field(..., description="Turso database auth token")

    # Twilio Integration (Voice, SMS, WhatsApp)
    TWILIO_ACCOUNT_SID: str = Field(..., description="Twilio account SID")
    TWILIO_AUTH_TOKEN: str = Field(..., description="Twilio auth token")
    TWILIO_PHONE_NUMBER: str = Field(..., description="Twilio phone number")

    # Email Configuration (Optional)
    EMAIL_HOST: str = Field(default="smtp.gmail.com", description="SMTP host")
    EMAIL_PORT: int = Field(default=465, description="SMTP port")
    EMAIL_HOST_USER: Optional[str] = Field(default=None, description="SMTP username")
    EMAIL_HOST_PASSWORD: Optional[str] = Field(default=None, description="SMTP password")

    # Redis Configuration (For Phase 5 - Caching & Rate Limiting)
    REDIS_URL: Optional[str] = Field(default=None, description="Redis connection URL (optional)")

    # Application Settings
    DEBUG: bool = Field(default=False, description="Debug mode")
    LOG_LEVEL: str = Field(default="INFO", description="Logging level")
    BASE_URL: Optional[str] = Field(default=None, description="Base URL for webhooks (e.g., ngrok URL)")

    # RAG Configuration
    RAG_TOP_K_RESULTS: int = Field(default=5, description="Number of similar examples to retrieve")
    RAG_SIMILARITY_THRESHOLD: float = Field(default=0.7, description="Minimum similarity score for retrieval")

    # Legacy (Backward Compatibility - Remove in Phase 2)
    GEMINI_API_KEY: Optional[str] = Field(default=None, description="DEPRECATED: Use OPENAI_API_KEY instead")

    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()
