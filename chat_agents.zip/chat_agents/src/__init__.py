"""
Reusable Chat Agent Module
===========================

A production-ready chat agent with AI, SQL, and multi-channel support.

Main Components:
- ChatAgent: Main orchestrator
- TursoDBConnector: Database integration
- VannaSQLAgent: Natural language to SQL
- TwilioHandler: SMS/WhatsApp integration
"""

__version__ = "1.0.0"
__author__ = "Your Team"

from .chat_agent import ChatAgent
from .db_connector import TursoDBConnector
from .vanna_integration import VannaSQLAgent
from .twilio_handler import TwilioHandler
from .config import settings

__all__ = [
    "ChatAgent",
    "TursoDBConnector",
    "VannaSQLAgent",
    "TwilioHandler",
    "settings",
]
