"""OpenAI-powered RAG SQL generation agent.

Replaces the Gemini-based vanna_integration.py with enterprise-grade
SQL generation using GPT-4 and semantic search.

Target Accuracy: 98%+ (vs 70-95% with Gemini)
"""

from openai import AsyncOpenAI
from typing import List, Dict, Any, Optional
import logging
import time

from ..config import settings
from ..models.client import Client
from ..vector.embedding_service import EmbeddingService
from ..vector.vector_store import VectorStore
from ..rag.context_builder import ContextBuilder
from ..db.multi_tenant_connector import MultiTenantDBConnector

logger = logging.getLogger(__name__)


class OpenAIRAGAgent:
    """SQL generation agent using OpenAI GPT-4 with RAG pipeline.

    Architecture:
    1. User Question → Embed with OpenAI
    2. Semantic Search → Pinecone (find similar Q&A pairs)
    3. Context Building → Assemble rich context
    4. GPT-4 Generation → Structured SQL output
    5. Validation → Execute and retry if needed
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: Optional[str] = None
    ):
        """Initialize OpenAI RAG agent.

        Args:
            api_key: OpenAI API key (defaults to settings)
            model: OpenAI model name (defaults to gpt-4-turbo-preview)
        """
        self.api_key = api_key or settings.OPENAI_API_KEY
        self.model = model or settings.OPENAI_MODEL

        # Initialize components
        self.client = AsyncOpenAI(api_key=self.api_key)
        self.embedding_service = EmbeddingService(api_key=self.api_key)
        self.vector_store = VectorStore()
        self.context_builder = ContextBuilder()

        # Configuration
        self.max_retries = 2
        self.temperature = 0.0  # Deterministic SQL generation

        logger.info(f"Initialized OpenAI RAG Agent with model: {self.model}")

    async def generate_sql(
        self,
        client: Client,
        question: str,
        db_connector: MultiTenantDBConnector
    ) -> Dict[str, Any]:
        """Generate SQL query from natural language question using RAG.

        Args:
            client: Client object for multi-tenant context
            question: Natural language question
            db_connector: Database connector for schema info

        Returns:
            Dict with 'sql', 'explanation', 'similar_examples', 'confidence'
        """
        start_time = time.time()

        try:
            # Step 1: Get database schema information
            schema_info = await db_connector.get_schema_info(client)

            # Step 2: Embed the question
            question_embedding = await self.embedding_service.embed_text(question)

            # Step 3: Retrieve similar examples and relevant schemas from vector DB
            similar_questions, relevant_schemas = await self.vector_store.hybrid_search(
                client=client,
                query_embedding=question_embedding,
                top_k_questions=settings.RAG_TOP_K_RESULTS,
                top_k_schemas=3,
                similarity_threshold=settings.RAG_SIMILARITY_THRESHOLD
            )

            # Step 4: Build rich context
            context = self.context_builder.build_sql_generation_context(
                client=client,
                user_question=question,
                similar_questions=similar_questions,
                relevant_schemas=relevant_schemas,
                full_schema_info=schema_info
            )

            # Step 5: Generate SQL using GPT-4
            sql_query = await self._generate_sql_with_gpt4(context)

            # Step 6: Validate and retry if needed
            sql_query, validation_result = await self._validate_and_retry(
                client=client,
                question=question,
                sql_query=sql_query,
                schema_info=schema_info,
                db_connector=db_connector
            )

            generation_time = time.time() - start_time

            # Calculate confidence based on similarity scores and validation
            confidence = self._calculate_confidence(
                similar_questions=similar_questions,
                validation_passed=validation_result['success']
            )

            logger.info(
                f"Generated SQL for {client.name} in {generation_time:.2f}s "
                f"(confidence: {confidence:.1%}, similar examples: {len(similar_questions)})"
            )

            return {
                'sql': sql_query,
                'similar_examples': similar_questions,
                'confidence': confidence,
                'generation_time': generation_time,
                'validation': validation_result,
                'retrieved_examples_count': len(similar_questions)
            }

        except Exception as e:
            logger.error(f"SQL generation failed for {client.name}: {str(e)}")
            return {
                'sql': None,
                'error': str(e),
                'confidence': 0.0
            }

    async def _generate_sql_with_gpt4(self, context: str) -> str:
        """Generate SQL using GPT-4 with function calling for structured output.

        Args:
            context: Rich context from RAG pipeline

        Returns:
            Generated SQL query
        """
        try:
            # Use GPT-4 with function calling for structured output
            response = await self.client.chat.completions.create(
                model=self.model,
                temperature=self.temperature,
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert SQL generator. Generate only valid, executable SQL queries."
                    },
                    {
                        "role": "user",
                        "content": context
                    }
                ],
                functions=[
                    {
                        "name": "generate_sql_query",
                        "description": "Generate a SQL query based on the user's question and database schema",
                        "parameters": {
                            "type": "object",
                            "properties": {
                                "sql_query": {
                                    "type": "string",
                                    "description": "The generated SQL query"
                                },
                                "reasoning": {
                                    "type": "string",
                                    "description": "Brief explanation of the query logic"
                                }
                            },
                            "required": ["sql_query"]
                        }
                    }
                ],
                function_call={"name": "generate_sql_query"}
            )

            # Extract SQL from function call
            function_call = response.choices[0].message.function_call
            if function_call:
                import json
                args = json.loads(function_call.arguments)
                sql_query = args.get('sql_query', '').strip()

                # Clean up the SQL
                sql_query = self._clean_sql(sql_query)

                return sql_query
            else:
                # Fallback: extract from message content
                content = response.choices[0].message.content
                return self._clean_sql(content)

        except Exception as e:
            logger.error(f"GPT-4 SQL generation error: {str(e)}")
            raise

    def _clean_sql(self, sql: str) -> str:
        """Clean and normalize SQL query.

        Args:
            sql: Raw SQL string

        Returns:
            Cleaned SQL query
        """
        # Remove markdown code blocks
        sql = sql.replace('```sql', '').replace('```', '')

        # Remove leading/trailing whitespace
        sql = sql.strip()

        # Remove comments (-- style)
        lines = sql.split('\n')
        lines = [line for line in lines if not line.strip().startswith('--')]
        sql = '\n'.join(lines)

        # Ensure it ends with semicolon (optional but clean)
        if not sql.endswith(';'):
            sql += ';'

        return sql

    async def _validate_and_retry(
        self,
        client: Client,
        question: str,
        sql_query: str,
        schema_info: Dict[str, Any],
        db_connector: MultiTenantDBConnector
    ) -> tuple[str, Dict[str, Any]]:
        """Validate SQL query and retry with error feedback if it fails.

        Args:
            client: Client object
            question: Original question
            sql_query: Generated SQL
            schema_info: Database schema
            db_connector: Database connector

        Returns:
            Tuple of (corrected_sql, validation_result)
        """
        for attempt in range(self.max_retries + 1):
            try:
                # Try to execute the query
                result = await db_connector.execute(client, sql_query)

                # Success
                return sql_query, {
                    'success': True,
                    'attempts': attempt + 1
                }

            except Exception as e:
                error_message = str(e)
                logger.warning(f"SQL validation failed (attempt {attempt + 1}): {error_message}")

                if attempt < self.max_retries:
                    # Build error recovery context
                    recovery_context = self.context_builder.build_error_recovery_context(
                        client=client,
                        original_question=question,
                        failed_sql=sql_query,
                        error_message=error_message,
                        schema_info=schema_info
                    )

                    # Try to generate corrected SQL
                    sql_query = await self._generate_sql_with_gpt4(recovery_context)
                else:
                    # Max retries reached
                    return sql_query, {
                        'success': False,
                        'error': error_message,
                        'attempts': attempt + 1
                    }

        return sql_query, {'success': False, 'error': 'Max retries exceeded'}

    def _calculate_confidence(
        self,
        similar_questions: List[Dict[str, Any]],
        validation_passed: bool
    ) -> float:
        """Calculate confidence score for generated SQL.

        Args:
            similar_questions: Retrieved similar examples
            validation_passed: Whether SQL validation passed

        Returns:
            Confidence score (0.0 - 1.0)
        """
        confidence = 0.0

        # Base confidence from similar examples
        if similar_questions:
            # Use highest similarity score
            max_similarity = max([q.get('similarity', 0) for q in similar_questions])
            confidence = max_similarity * 0.7  # 70% weight on similarity

        # Boost if validation passed
        if validation_passed:
            confidence = min(1.0, confidence + 0.3)  # Add up to 30%
        else:
            confidence *= 0.5  # Reduce by 50% if validation failed

        return confidence

    async def train_with_examples(
        self,
        client: Client,
        training_examples: List[Dict[str, str]]
    ):
        """Train the agent with question-SQL pairs for a client.

        Args:
            client: Client object
            training_examples: List of dicts with 'question' and 'sql'
        """
        try:
            questions = [ex['question'] for ex in training_examples]
            sql_queries = [ex['sql'] for ex in training_examples]

            # Generate embeddings
            embedded_data = await self.embedding_service.embed_training_data(
                questions=questions,
                sql_queries=sql_queries
            )

            # Store in vector database
            await self.vector_store.upsert_training_data(
                client=client,
                training_data=embedded_data
            )

            logger.info(f"Trained agent with {len(training_examples)} examples for client {client.name}")

        except Exception as e:
            logger.error(f"Training failed for {client.name}: {str(e)}")
            raise

    async def train_with_schema(
        self,
        client: Client,
        schema_info: Dict[str, Any]
    ):
        """Train the agent with database schema information.

        Args:
            client: Client object
            schema_info: Database schema metadata
        """
        try:
            schema_data = []

            for table in schema_info.get('tables', []):
                table_name = table['name']
                columns = table.get('columns', [])

                # Generate embedding for this table
                embedding = await self.embedding_service.embed_schema_metadata(
                    table_name=table_name,
                    columns=columns,
                    description=None  # Can add table descriptions later
                )

                schema_data.append({
                    'id': f"schema_{table_name}",
                    'table_name': table_name,
                    'columns': columns,
                    'embedding': embedding
                })

            # Store in vector database
            await self.vector_store.upsert_schema_metadata(
                client=client,
                schema_data=schema_data
            )

            logger.info(f"Trained agent with schema ({len(schema_data)} tables) for client {client.name}")

        except Exception as e:
            logger.error(f"Schema training failed for {client.name}: {str(e)}")
            raise

    async def get_training_status(self, client: Client) -> Dict[str, Any]:
        """Get training status for a client.

        Args:
            client: Client object

        Returns:
            Dict with training statistics
        """
        try:
            stats = await self.vector_store.get_namespace_stats(client)

            return {
                'client_name': client.name,
                'total_vectors': stats.get('vector_count', 0),
                'namespace': stats.get('namespace'),
                'is_trained': stats.get('vector_count', 0) > 0
            }

        except Exception as e:
            logger.error(f"Failed to get training status for {client.name}: {str(e)}")
            return {
                'client_name': client.name,
                'error': str(e),
                'is_trained': False
            }

    async def close(self):
        """Close all connections."""
        await self.client.close()
        await self.embedding_service.close()
        logger.info("Closed OpenAI RAG Agent")
