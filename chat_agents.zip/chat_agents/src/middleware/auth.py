"""Authentication middleware for multi-tenant API access.

Provides API key-based authentication and client identification.
"""

from fastapi import Request, HTTPException, status, Depends
from fastapi.security import APIKeyHeader
from starlette.middleware.base import BaseHTTPMiddleware
from typing import Optional
import logging

from ..models.client import Client

logger = logging.getLogger(__name__)

# API Key header scheme
api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)


class ClientAuthMiddleware(BaseHTTPMiddleware):
    """Middleware to authenticate and identify clients by API key.

    This middleware:
    1. Extracts API key from X-API-Key header
    2. Validates the API key against client database
    3. Attaches client object to request.state for downstream use
    4. Enforces rate limits per client
    """

    def __init__(self, app, client_service=None, get_client_service=None):
        """Initialize authentication middleware.

        Args:
            app: FastAPI application
            client_service: ClientService instance for client lookup (optional)
            get_client_service: Callable that returns ClientService (optional)
        """
        super().__init__(app)
        self._client_service = client_service
        self._get_client_service = get_client_service

        # Paths that don't require authentication
        self.public_paths = [
            "/",
            "/health",
            "/docs",
            "/openapi.json",
            "/redoc",
            "/webhook/voice",  # Twilio webhooks use different auth
            "/webhook/sms",
            "/webhook/whatsapp"
        ]

        # Paths that allow POST without auth (for client creation)
        self.public_post_paths = [
            "/clients"
        ]

    @property
    def client_service(self):
        """Get client service, either from instance or callable."""
        if self._client_service is not None:
            return self._client_service
        elif self._get_client_service is not None:
            return self._get_client_service()
        else:
            raise RuntimeError("ClientService not available")

    async def dispatch(self, request: Request, call_next):
        """Process request and authenticate client.

        Args:
            request: Incoming HTTP request
            call_next: Next middleware/route handler

        Returns:
            HTTP response
        """
        # Skip authentication for public paths
        if request.url.path in self.public_paths:
            return await call_next(request)

        # Skip authentication for POST to public POST paths (e.g., client creation)
        if request.method == "POST" and request.url.path in self.public_post_paths:
            return await call_next(request)

        # Skip authentication for static files
        if request.url.path.startswith("/static") or request.url.path.endswith(".html"):
            return await call_next(request)

        # Extract API key from header
        api_key = request.headers.get("X-API-Key")

        if not api_key:
            logger.warning(f"Request to {request.url.path} missing API key")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="API key required. Include X-API-Key header.",
                headers={"WWW-Authenticate": "ApiKey"}
            )

        # Validate API key and get client
        try:
            client = await self.client_service.get_by_api_key(api_key)

            if not client:
                logger.warning(f"Invalid API key attempted: {api_key[:10]}...")
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid API key",
                    headers={"WWW-Authenticate": "ApiKey"}
                )

            if not client.is_active:
                logger.warning(f"Inactive client attempted access: {client.name}")
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Client account is inactive. Please contact support."
                )

            # Attach client to request state for downstream handlers
            request.state.client = client

            logger.debug(f"Authenticated client: {client.name} (ID: {client.id})")

            # Check rate limits
            if not await self._check_rate_limit(client, request):
                raise HTTPException(
                    status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                    detail=f"Rate limit exceeded. Max {client.configuration.max_queries_per_minute} requests per minute."
                )

            # Process request
            response = await call_next(request)

            # Update client last query timestamp
            await self.client_service.update_last_query(client.id)

            return response

        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Authentication error: {str(e)}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Authentication service error"
            )

    async def _check_rate_limit(self, client: Client, request: Request) -> bool:
        """Check if client has exceeded rate limit.

        Args:
            client: Client object
            request: HTTP request

        Returns:
            True if within limits, False if exceeded
        """
        # TODO: Implement Redis-based rate limiting in Phase 5
        # For now, always allow (will be implemented with Redis)
        return True


async def get_current_client(
    request: Request,
    api_key: Optional[str] = Depends(api_key_header)
) -> Client:
    """Dependency to get current authenticated client.

    Use this in route handlers to access the authenticated client:

    ```python
    @app.get("/my-endpoint")
    async def my_endpoint(client: Client = Depends(get_current_client)):
        # Use client object here
        return {"client_name": client.name}
    ```

    Args:
        request: HTTP request (contains client in state)
        api_key: API key from header (for OpenAPI docs)

    Returns:
        Authenticated client object

    Raises:
        HTTPException: If not authenticated
    """
    if not hasattr(request.state, 'client'):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required. Client not found in request context."
        )

    return request.state.client


class RateLimiter:
    """Rate limiter using Redis for distributed rate limiting.

    This will be implemented in Phase 5 with Redis integration.
    """

    def __init__(self, redis_client=None):
        """Initialize rate limiter.

        Args:
            redis_client: Redis client instance (optional, for Phase 5)
        """
        self.redis_client = redis_client

    async def check_limit(
        self,
        client_id: str,
        max_requests: int,
        window_seconds: int = 60
    ) -> bool:
        """Check if client is within rate limit.

        Args:
            client_id: Client identifier
            max_requests: Maximum requests allowed in window
            window_seconds: Time window in seconds (default 60)

        Returns:
            True if within limit, False if exceeded
        """
        if not self.redis_client:
            # No Redis, always allow (Phase 1-4)
            return True

        # TODO: Implement Redis-based rate limiting
        # Use sliding window counter algorithm
        # Key: f"rate_limit:{client_id}:{window}"
        # Value: request count
        # TTL: window_seconds

        return True

    async def increment(self, client_id: str, window_seconds: int = 60):
        """Increment request counter for client.

        Args:
            client_id: Client identifier
            window_seconds: Time window in seconds
        """
        if not self.redis_client:
            return

        # TODO: Implement request counter increment
        pass
