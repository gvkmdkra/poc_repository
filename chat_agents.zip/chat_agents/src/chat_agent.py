import google.generativeai as genai
from typing import Optional, Dict, Any, List, Callable
from .config import settings
from .vanna_integration import VannaSQLAgent
from .twilio_handler import TwilioHandler
from .db_connector import TursoDBConnector
import logging
import json

logger = logging.getLogger(__name__)


class ChatAgent:
    def __init__(
        self,
        api_key: Optional[str] = None,
        model_name: str = "gemini-2.0-flash-exp",
        enable_sql: bool = True,
        enable_twilio: bool = True
    ):
        self.api_key = api_key or settings.GEMINI_API_KEY
        self.model_name = model_name
        self.enable_sql = enable_sql
        self.enable_twilio = enable_twilio

        genai.configure(api_key=self.api_key)
        self.model = genai.GenerativeModel(self.model_name)
        self.chat_session = None
        self.conversation_history = []

        self.vanna_agent = VannaSQLAgent(api_key=self.api_key, model_name=self.model_name) if enable_sql else None
        self.twilio_handler = TwilioHandler() if enable_twilio else None
        self.db_connector = None

        self.message_callbacks = []

    async def initialize(self, train_db: bool = False):
        if self.enable_sql:
            self.db_connector = TursoDBConnector()
            await self.db_connector.connect()
            await self.vanna_agent.setup_db(self.db_connector)

            if train_db:
                await self.vanna_agent.train_from_database()

        self.chat_session = self.model.start_chat(history=[])
        logger.info("Chat agent initialized successfully")

    def add_message_callback(self, callback: Callable[[Dict[str, Any]], None]):
        self.message_callbacks.append(callback)

    async def _execute_callbacks(self, message_data: Dict[str, Any]):
        for callback in self.message_callbacks:
            try:
                if callable(callback):
                    await callback(message_data) if hasattr(callback, '__await__') else callback(message_data)
            except Exception as e:
                logger.error(f"Error executing callback: {e}")

    async def process_message(
        self,
        message: str,
        context: Optional[Dict[str, Any]] = None,
        check_sql: bool = True
    ) -> Dict[str, Any]:
        try:
            response_data = {
                "user_message": message,
                "context": context,
                "sql_result": None,
                "ai_response": None,
                "success": True
            }

            if check_sql and self.enable_sql and self._is_sql_query(message):
                sql_result = await self.vanna_agent.ask(message)
                response_data["sql_result"] = sql_result

                if sql_result.get("success"):
                    prompt = f"""User asked: {message}

SQL Query generated: {sql_result.get('sql')}

Results: {json.dumps(sql_result.get('results', []), indent=2)}

Please provide a natural language response explaining these results to the user."""

                    ai_response = self.chat_session.send_message(prompt)
                    response_data["ai_response"] = ai_response.text
                else:
                    ai_response = self.chat_session.send_message(
                        f"The SQL query failed with error: {sql_result.get('error')}. "
                        f"Please respond to the user's question: {message}"
                    )
                    response_data["ai_response"] = ai_response.text
            else:
                ai_response = self.chat_session.send_message(message)
                response_data["ai_response"] = ai_response.text

            self.conversation_history.append(response_data)

            await self._execute_callbacks(response_data)

            return response_data

        except Exception as e:
            logger.error(f"Error processing message: {e}")
            return {
                "user_message": message,
                "context": context,
                "sql_result": None,
                "ai_response": f"Error: {str(e)}",
                "success": False,
                "error": str(e)
            }

    def _is_sql_query(self, message: str) -> bool:
        sql_keywords = [
            "how many", "count", "total", "sum", "average",
            "show me", "list", "find", "get", "what is",
            "filter", "where", "group by", "order by"
        ]
        message_lower = message.lower()
        return any(keyword in message_lower for keyword in sql_keywords)

    async def send_sms_response(self, to: str, message: str) -> Dict[str, Any]:
        if not self.enable_twilio:
            return {"success": False, "error": "Twilio not enabled"}
        return self.twilio_handler.send_sms(to, message)

    async def send_whatsapp_response(self, to: str, message: str) -> Dict[str, Any]:
        if not self.enable_twilio:
            return {"success": False, "error": "Twilio not enabled"}
        return self.twilio_handler.send_whatsapp(to, message)

    async def handle_incoming_sms(
        self,
        from_number: str,
        message: str,
        auto_reply: bool = True
    ) -> Dict[str, Any]:
        response = await self.process_message(message, context={"from": from_number, "type": "sms"})

        if auto_reply and response.get("success") and response.get("ai_response"):
            sms_result = await self.send_sms_response(from_number, response["ai_response"])
            response["sms_sent"] = sms_result

        return response

    async def handle_incoming_whatsapp(
        self,
        from_number: str,
        message: str,
        auto_reply: bool = True
    ) -> Dict[str, Any]:
        response = await self.process_message(message, context={"from": from_number, "type": "whatsapp"})

        if auto_reply and response.get("success") and response.get("ai_response"):
            whatsapp_result = await self.send_whatsapp_response(from_number, response["ai_response"])
            response["whatsapp_sent"] = whatsapp_result

        return response

    def get_conversation_history(self) -> List[Dict[str, Any]]:
        return self.conversation_history

    def clear_history(self):
        self.conversation_history = []
        self.chat_session = self.model.start_chat(history=[])

    async def close(self):
        if self.db_connector:
            await self.db_connector.close()
        if self.vanna_agent:
            await self.vanna_agent.close()
        logger.info("Chat agent closed")
