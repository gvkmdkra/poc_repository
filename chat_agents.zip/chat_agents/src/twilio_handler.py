from twilio.rest import Client
from twilio.twiml.messaging_response import MessagingResponse
from typing import Optional, Dict, Any, Callable
from .config import settings
import logging

logger = logging.getLogger(__name__)


class TwilioHandler:
    def __init__(
        self,
        account_sid: Optional[str] = None,
        auth_token: Optional[str] = None,
        phone_number: Optional[str] = None
    ):
        self.account_sid = account_sid or settings.TWILIO_ACCOUNT_SID
        self.auth_token = auth_token or settings.TWILIO_AUTH_TOKEN
        self.phone_number = phone_number or settings.TWILIO_PHONE_NUMBER
        self.client = Client(self.account_sid, self.auth_token)

    def send_sms(self, to: str, message: str) -> Dict[str, Any]:
        try:
            message_obj = self.client.messages.create(
                body=message,
                from_=self.phone_number,
                to=to
            )
            return {
                "success": True,
                "sid": message_obj.sid,
                "status": message_obj.status,
                "to": to
            }
        except Exception as e:
            logger.error(f"Error sending SMS: {e}")
            return {
                "success": False,
                "error": str(e),
                "to": to
            }

    def send_whatsapp(self, to: str, message: str) -> Dict[str, Any]:
        try:
            whatsapp_to = f"whatsapp:{to}" if not to.startswith("whatsapp:") else to
            whatsapp_from = f"whatsapp:{self.phone_number}" if not self.phone_number.startswith("whatsapp:") else self.phone_number

            message_obj = self.client.messages.create(
                body=message,
                from_=whatsapp_from,
                to=whatsapp_to
            )
            return {
                "success": True,
                "sid": message_obj.sid,
                "status": message_obj.status,
                "to": to
            }
        except Exception as e:
            logger.error(f"Error sending WhatsApp: {e}")
            return {
                "success": False,
                "error": str(e),
                "to": to
            }

    def create_twiml_response(self, message: str) -> str:
        response = MessagingResponse()
        response.message(message)
        return str(response)

    async def make_voice_call(self, to_number: str, message: str, webhook_url: Optional[str] = None) -> Dict[str, Any]:
        """Make an outbound voice call using Twilio"""
        try:
            # Use ngrok or deployed webhook URL - for local testing, use a placeholder
            if not webhook_url:
                webhook_url = settings.BASE_URL + "/webhook/voice" if hasattr(settings, 'BASE_URL') else "http://localhost:8000/webhook/voice"

            call = self.client.calls.create(
                twiml=f'<Response><Say voice="alice">{message}</Say></Response>',
                to=to_number,
                from_=self.phone_number
            )

            logger.info(f"Voice call initiated to {to_number}, SID: {call.sid}")

            return {
                "success": True,
                "call_sid": call.sid,
                "status": call.status,
                "to": to_number,
                "from": self.phone_number
            }
        except Exception as e:
            logger.error(f"Error making voice call: {e}")
            return {
                "success": False,
                "error": str(e),
                "to": to_number
            }

    def validate_webhook(self, url: str, params: Dict[str, str], signature: str) -> bool:
        from twilio.request_validator import RequestValidator
        validator = RequestValidator(self.auth_token)
        return validator.validate(url, params, signature)
