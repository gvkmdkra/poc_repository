from fastapi import FastAPI, HTTPException, Request, Form, Header
from fastapi.responses import Response
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, Dict, Any, List
from .chat_agent import ChatAgent
from .config import settings
import logging
from contextlib import asynccontextmanager

logging.basicConfig(level=settings.LOG_LEVEL)
logger = logging.getLogger(__name__)

chat_agent: Optional[ChatAgent] = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global chat_agent
    chat_agent = ChatAgent(
        enable_sql=True,
        enable_twilio=True
    )
    await chat_agent.initialize(train_db=True)
    logger.info("Chat agent initialized")
    yield
    await chat_agent.close()
    logger.info("Chat agent closed")


app = FastAPI(
    title="Reusable Chat Agent API",
    description="End-to-end chat module with Twilio, Vanna AI, and Turso DB",
    version="1.0.0",
    lifespan=lifespan
)

# Add CORS middleware to allow browser access
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins for local development
    allow_credentials=True,
    allow_methods=["*"],  # Allow all methods
    allow_headers=["*"],  # Allow all headers
)


class ChatMessage(BaseModel):
    message: str
    context: Optional[Dict[str, Any]] = None
    check_sql: bool = True


class SMSMessage(BaseModel):
    to: str
    message: str


class TrainingData(BaseModel):
    ddl: Optional[str] = None
    documentation: Optional[str] = None
    question: Optional[str] = None
    sql: Optional[str] = None


class VoiceCallRequest(BaseModel):
    to: str
    message: Optional[str] = "Hello! This is your AI agent calling."


@app.get("/")
async def root():
    return {
        "service": "Reusable Chat Agent API",
        "status": "running",
        "endpoints": {
            "chat": "/chat",
            "sms": "/sms/send",
            "whatsapp": "/whatsapp/send",
            "voice_call": "/call/make",
            "twilio_webhook": "/webhook/twilio",
            "voice_webhook": "/webhook/voice",
            "voice_response": "/webhook/voice/response",
            "history": "/history",
            "train": "/train",
            "refresh_schema": "/refresh-schema",
            "get_schema": "/schema/{table_name}"
        }
    }


@app.post("/chat")
async def chat(message: ChatMessage):
    if not chat_agent:
        raise HTTPException(status_code=503, detail="Chat agent not initialized")

    try:
        response = await chat_agent.process_message(
            message=message.message,
            context=message.context,
            check_sql=message.check_sql
        )
        return response
    except Exception as e:
        logger.error(f"Error in chat endpoint: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/sms/send")
async def send_sms(sms: SMSMessage):
    if not chat_agent:
        raise HTTPException(status_code=503, detail="Chat agent not initialized")

    try:
        result = await chat_agent.send_sms_response(sms.to, sms.message)
        if not result.get("success"):
            raise HTTPException(status_code=400, detail=result.get("error"))
        return result
    except Exception as e:
        logger.error(f"Error sending SMS: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/whatsapp/send")
async def send_whatsapp(message: SMSMessage):
    if not chat_agent:
        raise HTTPException(status_code=503, detail="Chat agent not initialized")

    try:
        result = await chat_agent.send_whatsapp_response(message.to, message.message)
        if not result.get("success"):
            raise HTTPException(status_code=400, detail=result.get("error"))
        return result
    except Exception as e:
        logger.error(f"Error sending WhatsApp: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/webhook/twilio")
async def twilio_webhook(
    request: Request,
    From: str = Form(...),
    Body: str = Form(...),
    MessageSid: str = Form(...),
    x_twilio_signature: Optional[str] = Header(None)
):
    if not chat_agent:
        raise HTTPException(status_code=503, detail="Chat agent not initialized")

    try:
        is_whatsapp = From.startswith("whatsapp:")

        if is_whatsapp:
            response = await chat_agent.handle_incoming_whatsapp(
                from_number=From.replace("whatsapp:", ""),
                message=Body,
                auto_reply=True
            )
        else:
            response = await chat_agent.handle_incoming_sms(
                from_number=From,
                message=Body,
                auto_reply=True
            )

        twiml_response = chat_agent.twilio_handler.create_twiml_response(
            response.get("ai_response", "Thank you for your message!")
        )

        return Response(content=twiml_response, media_type="application/xml")

    except Exception as e:
        logger.error(f"Error in Twilio webhook: {e}")
        error_response = chat_agent.twilio_handler.create_twiml_response(
            "Sorry, there was an error processing your message."
        )
        return Response(content=error_response, media_type="application/xml")


@app.get("/history")
async def get_history():
    if not chat_agent:
        raise HTTPException(status_code=503, detail="Chat agent not initialized")

    return {
        "history": chat_agent.get_conversation_history(),
        "count": len(chat_agent.get_conversation_history())
    }


@app.delete("/history")
async def clear_history():
    if not chat_agent:
        raise HTTPException(status_code=503, detail="Chat agent not initialized")

    chat_agent.clear_history()
    return {"message": "History cleared successfully"}


@app.post("/train")
async def train_vanna(training: TrainingData):
    if not chat_agent:
        raise HTTPException(status_code=503, detail="Chat agent not initialized")

    if not chat_agent.vanna_agent:
        raise HTTPException(status_code=400, detail="SQL agent not enabled")

    try:
        if training.ddl:
            chat_agent.vanna_agent.train_ddl(training.ddl)

        if training.documentation:
            chat_agent.vanna_agent.train_documentation(training.documentation)

        if training.question and training.sql:
            chat_agent.vanna_agent.train_question_sql(training.question, training.sql)

        return {"message": "Training completed successfully"}

    except Exception as e:
        logger.error(f"Error training Vanna: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/training-data")
async def get_training_data():
    if not chat_agent:
        raise HTTPException(status_code=503, detail="Chat agent not initialized")

    if not chat_agent.vanna_agent:
        raise HTTPException(status_code=400, detail="SQL agent not enabled")

    try:
        training_data = chat_agent.vanna_agent.get_training_data()
        return {"training_data": training_data}
    except Exception as e:
        logger.error(f"Error getting training data: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/refresh-schema")
async def refresh_schema():
    if not chat_agent:
        raise HTTPException(status_code=503, detail="Chat agent not initialized")

    if not chat_agent.vanna_agent:
        raise HTTPException(status_code=400, detail="SQL agent not enabled")

    try:
        await chat_agent.vanna_agent.refresh_schema()
        schemas = chat_agent.vanna_agent.schema_cache
        return {
            "message": "Schema cache refreshed successfully",
            "tables": list(schemas.keys()),
            "table_count": len(schemas)
        }
    except Exception as e:
        logger.error(f"Error refreshing schema: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/schema/{table_name}")
async def get_table_schema(table_name: str):
    if not chat_agent:
        raise HTTPException(status_code=503, detail="Chat agent not initialized")

    if not chat_agent.vanna_agent:
        raise HTTPException(status_code=400, detail="SQL agent not enabled")

    try:
        schema = await chat_agent.vanna_agent.get_table_schema(table_name)
        return schema
    except Exception as e:
        logger.error(f"Error getting schema for {table_name}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/call/make")
async def make_call(call_request: VoiceCallRequest):
    """Initiate an outbound voice call using Twilio"""
    if not chat_agent:
        raise HTTPException(status_code=503, detail="Chat agent not initialized")

    if not chat_agent.twilio_handler:
        raise HTTPException(status_code=400, detail="Twilio not enabled")

    try:
        # Make the call using Twilio
        result = await chat_agent.twilio_handler.make_voice_call(
            to_number=call_request.to,
            message=call_request.message
        )

        if not result.get("success"):
            raise HTTPException(status_code=400, detail=result.get("error"))

        return result
    except Exception as e:
        logger.error(f"Error making call: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/webhook/voice")
async def voice_webhook(request: Request):
    """Handle incoming Twilio voice calls"""
    if not chat_agent:
        raise HTTPException(status_code=503, detail="Chat agent not initialized")

    try:
        # Get form data from Twilio
        form_data = await request.form()
        from_number = form_data.get("From", "")
        call_sid = form_data.get("CallSid", "")

        logger.info(f"Incoming call from {from_number}, SID: {call_sid}")

        # Generate TwiML response with voice
        twiml = """<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Say voice="alice">Hello! Thank you for calling the AI Agent. How can I help you today?</Say>
    <Gather input="speech" action="/webhook/voice/response" method="POST" timeout="3" speechTimeout="auto">
        <Say voice="alice">Please speak your question after the beep.</Say>
    </Gather>
    <Say voice="alice">I didn't receive any input. Goodbye!</Say>
</Response>"""

        return Response(content=twiml, media_type="application/xml")

    except Exception as e:
        logger.error(f"Error in voice webhook: {e}")
        error_twiml = """<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Say voice="alice">Sorry, there was an error processing your call. Please try again later.</Say>
</Response>"""
        return Response(content=error_twiml, media_type="application/xml")


@app.post("/webhook/voice/response")
async def voice_response_webhook(
    request: Request,
    SpeechResult: Optional[str] = Form(None),
    From: str = Form(...),
    CallSid: str = Form(...)
):
    """Process speech input and generate AI response"""
    if not chat_agent:
        raise HTTPException(status_code=503, detail="Chat agent not initialized")

    try:
        if not SpeechResult:
            twiml = """<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Say voice="alice">I didn't catch that. Please try calling again.</Say>
</Response>"""
            return Response(content=twiml, media_type="application/xml")

        logger.info(f"Voice input from {From}: {SpeechResult}")

        # Process the message through the chat agent
        response = await chat_agent.process_message(
            message=SpeechResult,
            context={"source": "voice", "call_sid": CallSid, "from": From},
            check_sql=True
        )

        ai_response = response.get("response", "I'm sorry, I couldn't process that request.")

        # Create TwiML with AI response
        twiml = f"""<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Say voice="alice">{ai_response}</Say>
    <Say voice="alice">Is there anything else I can help you with?</Say>
    <Gather input="speech" action="/webhook/voice/response" method="POST" timeout="3" speechTimeout="auto">
        <Say voice="alice">Please speak your next question, or hang up if you're done.</Say>
    </Gather>
    <Say voice="alice">Thank you for calling. Goodbye!</Say>
</Response>"""

        return Response(content=twiml, media_type="application/xml")

    except Exception as e:
        logger.error(f"Error processing voice response: {e}")
        error_twiml = """<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Say voice="alice">Sorry, I encountered an error. Please try again.</Say>
</Response>"""
        return Response(content=error_twiml, media_type="application/xml")


@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "chat_agent": chat_agent is not None,
        "sql_enabled": chat_agent.enable_sql if chat_agent else False,
        "twilio_enabled": chat_agent.enable_twilio if chat_agent else False
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
