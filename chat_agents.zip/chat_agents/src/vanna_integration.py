from typing import Optional, List, Dict, Any
from .config import settings
from .db_connector import TursoDBConnector
import google.generativeai as genai
import logging

logger = logging.getLogger(__name__)


class VannaSQLAgent:
    def __init__(self, api_key: Optional[str] = None, model_name: str = "gemini-2.0-flash-exp"):
        self.api_key = api_key or settings.GEMINI_API_KEY
        self.model_name = model_name
        genai.configure(api_key=self.api_key)
        self.model = genai.GenerativeModel(self.model_name)
        self.db_connector = None
        self.training_data = {"ddl": [], "documentation": [], "questions": []}
        self.schema_cache = {}  # Cache table schemas for better performance
        self.table_info_cache = {}  # Cache PRAGMA table_info results

    async def setup_db(self, db_connector: Optional[TursoDBConnector] = None):
        if db_connector:
            self.db_connector = db_connector
        else:
            self.db_connector = TursoDBConnector()
            await self.db_connector.connect()

    def train_ddl(self, ddl: str):
        if ddl not in self.training_data["ddl"]:
            self.training_data["ddl"].append(ddl)

    def train_documentation(self, documentation: str):
        if documentation not in self.training_data["documentation"]:
            self.training_data["documentation"].append(documentation)

    def train_question_sql(self, question: str, sql: str):
        self.training_data["questions"].append({"question": question, "sql": sql})

    async def get_table_schema(self, table_name: str) -> Dict[str, Any]:
        """Get detailed schema information for a specific table"""
        try:
            # Check cache first
            if table_name in self.table_info_cache:
                return self.table_info_cache[table_name]

            # Get column information using PRAGMA
            pragma_query = f"PRAGMA table_info('{table_name}')"
            columns = await self.db_connector.fetch_all(pragma_query)

            schema_info = {
                "table_name": table_name,
                "columns": [],
                "column_names": [],
                "primary_keys": []
            }

            for col in columns:
                col_info = {
                    "name": col.get('name'),
                    "type": col.get('type'),
                    "not_null": bool(col.get('notnull')),
                    "default": col.get('dflt_value'),
                    "pk": bool(col.get('pk'))
                }
                schema_info["columns"].append(col_info)
                schema_info["column_names"].append(col.get('name'))
                if col.get('pk'):
                    schema_info["primary_keys"].append(col.get('name'))

            # Cache the result
            self.table_info_cache[table_name] = schema_info
            return schema_info

        except Exception as e:
            logger.error(f"Error getting schema for table {table_name}: {e}")
            return {"table_name": table_name, "error": str(e), "columns": []}

    async def get_all_table_schemas(self) -> Dict[str, Dict[str, Any]]:
        """Get schemas for all tables in the database"""
        try:
            # Get all table names
            tables_query = "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
            tables = await self.db_connector.fetch_all(tables_query)

            schemas = {}
            for table in tables:
                table_name = table.get('name')
                if table_name:
                    schema = await self.get_table_schema(table_name)
                    schemas[table_name] = schema

            self.schema_cache = schemas
            return schemas

        except Exception as e:
            logger.error(f"Error getting all table schemas: {e}")
            return {}

    async def train_from_database(self):
        """Train the agent with comprehensive database schema information"""
        if not self.db_connector:
            await self.setup_db()

        try:
            # Get all table schemas
            schemas = await self.get_all_table_schemas()

            # Train with DDL from sqlite_master
            schema_query = "SELECT sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
            tables = await self.db_connector.fetch_all(schema_query)
            for table in tables:
                sql_content = table.get('sql')
                if sql_content:
                    self.train_ddl(sql_content)

            # Add detailed schema documentation
            for table_name, schema_info in schemas.items():
                if schema_info.get('columns'):
                    doc = f"Table '{table_name}' has columns: {', '.join(schema_info['column_names'])}"
                    self.train_documentation(doc)

            logger.info(f"Successfully trained from database with {len(schemas)} tables")

        except Exception as e:
            logger.error(f"Error training from database: {e}")

    def generate_sql(self, question: str) -> str:
        """Generate SQL with enhanced context and error handling"""
        context = self._build_enhanced_context()

        # Enhanced prompt with safety instructions
        prompt = f"""You are an expert SQL generator for SQLite databases.

{context}

IMPORTANT RULES:
1. Return ONLY valid SQLite SQL queries
2. Use ONLY tables and columns that exist in the schema
3. For PRAGMA queries, use exact syntax: PRAGMA table_info('table_name')
4. Always use single quotes for string literals in SQLite
5. Do NOT include markdown code blocks or explanations
6. If asking about table structure, use: PRAGMA table_info('table_name')
7. If asking about tables, use: SELECT name FROM sqlite_master WHERE type='table'

User Question: {question}

SQL Query (ONLY the query, no explanation):"""

        try:
            response = self.model.generate_content(prompt)
            sql = response.text.strip()

            # Clean up the SQL
            sql = sql.replace("```sql", "").replace("```", "").strip()

            # Remove common prefixes
            if sql.lower().startswith("sql:"):
                sql = sql[4:].strip()
            if sql.lower().startswith("query:"):
                sql = sql[6:].strip()

            # Validate it's not empty
            if not sql:
                raise Exception("Generated SQL is empty")

            logger.info(f"Generated SQL: {sql}")
            return sql

        except Exception as e:
            logger.error(f"Error generating SQL: {e}")
            raise Exception(f"Error generating SQL: {str(e)}")

    def _build_enhanced_context(self) -> str:
        """Build comprehensive context from training data and cached schemas"""
        parts = []

        # Add DDL information
        if self.training_data["ddl"]:
            parts.append("DATABASE SCHEMA:")
            for ddl in self.training_data["ddl"]:
                parts.append(f"  {ddl}")

        # Add cached schema information
        if self.schema_cache:
            parts.append("\nTABLE DETAILS:")
            for table_name, schema_info in self.schema_cache.items():
                if schema_info.get('columns'):
                    cols = [f"{c['name']} ({c['type']})" for c in schema_info['columns']]
                    parts.append(f"  Table '{table_name}': {', '.join(cols)}")

        # Add documentation
        if self.training_data["documentation"]:
            parts.append("\nADDITIONAL INFO:")
            for doc in self.training_data["documentation"]:
                parts.append(f"  {doc}")

        # Add example questions
        if self.training_data["questions"]:
            parts.append("\nEXAMPLE QUERIES:")
            for q in self.training_data["questions"]:
                parts.append(f"  Q: {q['question']}")
                parts.append(f"  SQL: {q['sql']}")

        context = "\n".join(parts) if parts else "No schema information available."
        return context

    def _build_context(self) -> str:
        """Legacy method for backward compatibility"""
        return self._build_enhanced_context()

    async def ask(self, question: str, retry_count: int = 0, max_retries: int = 2) -> Dict[str, Any]:
        """Execute a question with enhanced error handling and retry logic"""
        sql_var = None
        try:
            # Ensure DB is connected
            if not self.db_connector:
                await self.setup_db()

            # Generate SQL
            sql_var = self.generate_sql(question)

            # Execute query with timeout and error handling
            try:
                results = await self.db_connector.fetch_all(sql_var)

                # Ensure results are JSON serializable
                if isinstance(results, list):
                    serializable_results = []
                    for row in results:
                        if isinstance(row, dict):
                            serializable_results.append(row)
                        else:
                            # Convert to dict if it's not already
                            serializable_results.append(dict(row) if hasattr(row, 'keys') else {"value": str(row)})
                    results = serializable_results

                return {
                    "success": True,
                    "question": question,
                    "sql": sql_var,
                    "results": results,
                    "row_count": len(results) if results else 0
                }

            except Exception as db_error:
                error_msg = str(db_error)
                logger.error(f"Database execution error: {error_msg}")

                # If it's a syntax error and we haven't exceeded retries, try again with error feedback
                if retry_count < max_retries and ("syntax" in error_msg.lower() or "no such" in error_msg.lower()):
                    logger.info(f"Retrying query generation (attempt {retry_count + 1}/{max_retries})")
                    # Add error feedback to documentation for next attempt
                    self.train_documentation(f"Previous error: {error_msg} for query: {sql_var}")
                    return await self.ask(question, retry_count + 1, max_retries)

                return {
                    "success": False,
                    "question": question,
                    "error": f"Database error: {error_msg}",
                    "sql": sql_var
                }

        except Exception as e:
            error_msg = str(e)
            logger.error(f"Error in ask(): {error_msg}")
            return {
                "success": False,
                "question": question,
                "error": error_msg,
                "sql": sql_var
            }

    def generate_plotly_code(self, question: str, sql: str, df_name: str = "df") -> str:
        prompt = f"Generate Plotly code for SQL: {sql}, Question: {question}, DataFrame: {df_name}"
        try:
            response = self.model.generate_content(prompt)
            return response.text.strip()
        except Exception as e:
            return f"# Error: {str(e)}"

    def get_training_data(self) -> List[Dict[str, Any]]:
        all_data = []
        for ddl in self.training_data["ddl"]:
            all_data.append({"type": "ddl", "content": ddl})
        for doc in self.training_data["documentation"]:
            all_data.append({"type": "documentation", "content": doc})
        for qa in self.training_data["questions"]:
            all_data.append({"type": "question_sql", "question": qa["question"], "sql": qa["sql"]})
        return all_data

    def clear_cache(self):
        """Clear all cached schema information"""
        self.schema_cache = {}
        self.table_info_cache = {}

    async def refresh_schema(self):
        """Refresh cached schema information from database"""
        self.clear_cache()
        await self.get_all_table_schemas()

    async def close(self):
        if self.db_connector:
            await self.db_connector.close()
