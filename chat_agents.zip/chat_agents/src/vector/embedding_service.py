"""OpenAI embedding service for semantic search.

Provides text embedding using OpenAI's text-embedding-3-large model.
"""

from openai import AsyncOpenAI
from typing import List, Dict, Any, Optional
import logging
import asyncio

from ..config import settings

logger = logging.getLogger(__name__)


class EmbeddingService:
    """Service for generating text embeddings using OpenAI.

    Uses text-embedding-3-large model (3072 dimensions) for high-quality
    semantic representations.
    """

    def __init__(self, api_key: Optional[str] = None, model: Optional[str] = None):
        """Initialize embedding service.

        Args:
            api_key: OpenAI API key (defaults to settings)
            model: Embedding model name (defaults to text-embedding-3-large)
        """
        self.api_key = api_key or settings.OPENAI_API_KEY
        self.model = model or settings.OPENAI_EMBEDDING_MODEL
        self.client = AsyncOpenAI(api_key=self.api_key)

        logger.info(f"Initialized embedding service with model: {self.model}")

    async def embed_text(self, text: str) -> List[float]:
        """Generate embedding for a single text.

        Args:
            text: Text to embed

        Returns:
            Embedding vector (3072 dimensions for text-embedding-3-large)

        Raises:
            Exception: If embedding fails
        """
        try:
            response = await self.client.embeddings.create(
                model=self.model,
                input=text
            )

            embedding = response.data[0].embedding

            logger.debug(f"Generated embedding for text (length: {len(text)})")
            return embedding

        except Exception as e:
            logger.error(f"Failed to generate embedding: {str(e)}")
            raise

    async def embed_batch(self, texts: List[str], batch_size: int = 100) -> List[List[float]]:
        """Generate embeddings for multiple texts in batches.

        Args:
            texts: List of texts to embed
            batch_size: Number of texts per API call (max 2048 for OpenAI)

        Returns:
            List of embedding vectors

        Raises:
            Exception: If embedding fails
        """
        all_embeddings = []

        # Process in batches
        for i in range(0, len(texts), batch_size):
            batch = texts[i:i + batch_size]

            try:
                response = await self.client.embeddings.create(
                    model=self.model,
                    input=batch
                )

                batch_embeddings = [item.embedding for item in response.data]
                all_embeddings.extend(batch_embeddings)

                logger.debug(f"Generated embeddings for batch {i // batch_size + 1} ({len(batch)} texts)")

            except Exception as e:
                logger.error(f"Failed to generate batch embeddings: {str(e)}")
                raise

        return all_embeddings

    async def embed_training_data(
        self,
        questions: List[str],
        sql_queries: List[str]
    ) -> List[Dict[str, Any]]:
        """Embed training data (question-SQL pairs) for RAG.

        Args:
            questions: List of natural language questions
            sql_queries: List of corresponding SQL queries

        Returns:
            List of dicts with question, SQL, and embedding
        """
        if len(questions) != len(sql_queries):
            raise ValueError("Questions and SQL queries must have same length")

        # Create combined texts for embedding (question + SQL)
        combined_texts = [
            f"Question: {q}\nSQL: {sql}"
            for q, sql in zip(questions, sql_queries)
        ]

        try:
            embeddings = await self.embed_batch(combined_texts)

            training_data = []
            for i, (question, sql, embedding) in enumerate(zip(questions, sql_queries, embeddings)):
                training_data.append({
                    'id': f"train_{i}",
                    'question': question,
                    'sql': sql,
                    'embedding': embedding,
                    'combined_text': combined_texts[i]
                })

            logger.info(f"Embedded {len(training_data)} training examples")
            return training_data

        except Exception as e:
            logger.error(f"Failed to embed training data: {str(e)}")
            raise

    async def embed_schema_metadata(
        self,
        table_name: str,
        columns: List[Dict[str, str]],
        description: Optional[str] = None
    ) -> List[float]:
        """Generate embedding for table schema metadata.

        Args:
            table_name: Name of the table
            columns: List of column definitions with 'name' and 'type'
            description: Optional table description

        Returns:
            Embedding vector for the schema
        """
        # Create rich text representation of schema
        schema_text = f"Table: {table_name}\n"

        if description:
            schema_text += f"Description: {description}\n"

        schema_text += "Columns:\n"
        for col in columns:
            col_text = f"- {col['name']} ({col['type']})"
            if col.get('nullable'):
                col_text += " NULL"
            if col.get('primary_key'):
                col_text += " PRIMARY KEY"
            schema_text += col_text + "\n"

        embedding = await self.embed_text(schema_text)

        logger.debug(f"Generated schema embedding for table: {table_name}")
        return embedding

    async def embed_documentation(
        self,
        documentation: List[Dict[str, str]]
    ) -> List[Dict[str, Any]]:
        """Embed documentation strings for RAG context.

        Args:
            documentation: List of dicts with 'title' and 'content'

        Returns:
            List of dicts with documentation and embeddings
        """
        texts = [
            f"{doc['title']}\n{doc['content']}"
            for doc in documentation
        ]

        embeddings = await self.embed_batch(texts)

        embedded_docs = []
        for i, (doc, embedding) in enumerate(zip(documentation, embeddings)):
            embedded_docs.append({
                'id': f"doc_{i}",
                'title': doc['title'],
                'content': doc['content'],
                'embedding': embedding
            })

        logger.info(f"Embedded {len(embedded_docs)} documentation entries")
        return embedded_docs

    def get_embedding_dimension(self) -> int:
        """Get the dimension of embeddings produced by current model.

        Returns:
            Embedding dimension size
        """
        # text-embedding-3-large produces 3072-dimensional vectors
        # text-embedding-3-small produces 1536-dimensional vectors
        # text-embedding-ada-002 produces 1536-dimensional vectors

        if "3-large" in self.model:
            return 3072
        elif "3-small" in self.model or "ada-002" in self.model:
            return 1536
        else:
            # Default to 3072 for text-embedding-3-large
            return 3072

    async def close(self):
        """Close the OpenAI client."""
        await self.client.close()
        logger.info("Closed embedding service")
