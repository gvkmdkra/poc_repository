"""Pinecone vector store for semantic search and RAG.

Provides multi-tenant vector storage with namespace-based isolation.
"""

from pinecone import Pinecone, ServerlessSpec
from typing import List, Dict, Any, Optional, Tuple
import logging
from uuid import UUID

from ..config import settings
from ..models.client import Client

logger = logging.getLogger(__name__)


class VectorStore:
    """Pinecone vector store with multi-tenant support.

    Each client gets a unique namespace in the Pinecone index for data isolation.
    Uses namespace pattern: client-{client_id}
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        environment: Optional[str] = None,
        index_name: Optional[str] = None
    ):
        """Initialize Pinecone vector store.

        Args:
            api_key: Pinecone API key (defaults to settings)
            environment: Pinecone environment (defaults to settings)
            index_name: Index name (defaults to settings)
        """
        self.api_key = api_key or settings.PINECONE_API_KEY
        self.environment = environment or settings.PINECONE_ENVIRONMENT
        self.index_name = index_name or settings.PINECONE_INDEX_NAME

        # Initialize Pinecone
        self.pc = Pinecone(api_key=self.api_key)

        # Get or create index
        self.index = self._get_or_create_index()

        logger.info(f"Initialized Pinecone vector store: {self.index_name}")

    def _get_or_create_index(self):
        """Get existing index or create new one if it doesn't exist.

        Returns:
            Pinecone index object
        """
        try:
            # Check if index exists
            existing_indexes = self.pc.list_indexes()

            if self.index_name not in [idx['name'] for idx in existing_indexes]:
                logger.info(f"Creating new Pinecone index: {self.index_name}")

                # Create index with appropriate dimension (3072 for text-embedding-3-large)
                self.pc.create_index(
                    name=self.index_name,
                    dimension=3072,  # text-embedding-3-large dimension
                    metric='cosine',  # Cosine similarity for semantic search
                    spec=ServerlessSpec(
                        cloud='aws',
                        region='us-east-1'
                    )
                )

                logger.info(f"Created Pinecone index: {self.index_name}")

            return self.pc.Index(self.index_name)

        except Exception as e:
            logger.error(f"Failed to initialize Pinecone index: {str(e)}")
            raise

    async def upsert_training_data(
        self,
        client: Client,
        training_data: List[Dict[str, Any]]
    ):
        """Upsert training data (question-SQL pairs) for a client.

        Args:
            client: Client object for namespace identification
            training_data: List of dicts with 'id', 'question', 'sql', 'embedding'
        """
        namespace = client.embedding_namespace

        try:
            # Prepare vectors for upsert
            vectors = []
            for item in training_data:
                vectors.append({
                    'id': item['id'],
                    'values': item['embedding'],
                    'metadata': {
                        'question': item['question'],
                        'sql': item['sql'],
                        'type': 'training',
                        'client_id': str(client.id),
                        'client_name': client.name
                    }
                })

            # Upsert in batches of 100
            batch_size = 100
            for i in range(0, len(vectors), batch_size):
                batch = vectors[i:i + batch_size]
                self.index.upsert(vectors=batch, namespace=namespace)

            logger.info(f"Upserted {len(vectors)} training examples for client {client.name} in namespace {namespace}")

        except Exception as e:
            logger.error(f"Failed to upsert training data for {client.name}: {str(e)}")
            raise

    async def upsert_schema_metadata(
        self,
        client: Client,
        schema_data: List[Dict[str, Any]]
    ):
        """Upsert database schema metadata for a client.

        Args:
            client: Client object
            schema_data: List of dicts with 'id', 'table_name', 'embedding', 'columns'
        """
        namespace = client.embedding_namespace

        try:
            vectors = []
            for item in schema_data:
                vectors.append({
                    'id': item['id'],
                    'values': item['embedding'],
                    'metadata': {
                        'table_name': item['table_name'],
                        'columns': str(item['columns']),  # Stringify for metadata
                        'type': 'schema',
                        'client_id': str(client.id)
                    }
                })

            # Upsert in batches
            batch_size = 100
            for i in range(0, len(vectors), batch_size):
                batch = vectors[i:i + batch_size]
                self.index.upsert(vectors=batch, namespace=namespace)

            logger.info(f"Upserted {len(vectors)} schema entries for client {client.name}")

        except Exception as e:
            logger.error(f"Failed to upsert schema metadata for {client.name}: {str(e)}")
            raise

    async def search_similar_questions(
        self,
        client: Client,
        query_embedding: List[float],
        top_k: int = 5,
        similarity_threshold: float = 0.7
    ) -> List[Dict[str, Any]]:
        """Search for similar questions in the client's namespace.

        Args:
            client: Client object
            query_embedding: Query vector (3072 dimensions)
            top_k: Number of results to return
            similarity_threshold: Minimum similarity score (0-1)

        Returns:
            List of similar questions with SQL and similarity scores
        """
        namespace = client.embedding_namespace

        try:
            # Query Pinecone
            results = self.index.query(
                vector=query_embedding,
                namespace=namespace,
                top_k=top_k,
                include_metadata=True,
                filter={'type': 'training'}  # Only search training examples
            )

            # Filter by similarity threshold and format results
            similar_questions = []
            for match in results.matches:
                if match.score >= similarity_threshold:
                    similar_questions.append({
                        'question': match.metadata.get('question'),
                        'sql': match.metadata.get('sql'),
                        'similarity': match.score,
                        'id': match.id
                    })

            logger.debug(f"Found {len(similar_questions)} similar questions for client {client.name} (threshold: {similarity_threshold})")
            return similar_questions

        except Exception as e:
            logger.error(f"Failed to search similar questions for {client.name}: {str(e)}")
            return []

    async def search_relevant_schemas(
        self,
        client: Client,
        query_embedding: List[float],
        top_k: int = 3
    ) -> List[Dict[str, Any]]:
        """Search for relevant database schemas based on query.

        Args:
            client: Client object
            query_embedding: Query vector
            top_k: Number of schemas to return

        Returns:
            List of relevant schemas with metadata
        """
        namespace = client.embedding_namespace

        try:
            results = self.index.query(
                vector=query_embedding,
                namespace=namespace,
                top_k=top_k,
                include_metadata=True,
                filter={'type': 'schema'}
            )

            relevant_schemas = []
            for match in results.matches:
                relevant_schemas.append({
                    'table_name': match.metadata.get('table_name'),
                    'columns': match.metadata.get('columns'),
                    'similarity': match.score,
                    'id': match.id
                })

            logger.debug(f"Found {len(relevant_schemas)} relevant schemas for client {client.name}")
            return relevant_schemas

        except Exception as e:
            logger.error(f"Failed to search relevant schemas for {client.name}: {str(e)}")
            return []

    async def hybrid_search(
        self,
        client: Client,
        query_embedding: List[float],
        top_k_questions: int = 5,
        top_k_schemas: int = 3,
        similarity_threshold: float = 0.7
    ) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
        """Perform hybrid search for both similar questions and relevant schemas.

        Args:
            client: Client object
            query_embedding: Query vector
            top_k_questions: Number of similar questions to retrieve
            top_k_schemas: Number of relevant schemas to retrieve
            similarity_threshold: Minimum similarity for questions

        Returns:
            Tuple of (similar_questions, relevant_schemas)
        """
        # Search both in parallel
        similar_questions = await self.search_similar_questions(
            client, query_embedding, top_k_questions, similarity_threshold
        )

        relevant_schemas = await self.search_relevant_schemas(
            client, query_embedding, top_k_schemas
        )

        return similar_questions, relevant_schemas

    async def delete_client_data(self, client: Client):
        """Delete all vectors for a client (when client is removed).

        Args:
            client: Client object
        """
        namespace = client.embedding_namespace

        try:
            # Delete entire namespace
            self.index.delete(delete_all=True, namespace=namespace)

            logger.info(f"Deleted all vectors for client {client.name} in namespace {namespace}")

        except Exception as e:
            logger.error(f"Failed to delete client data for {client.name}: {str(e)}")
            raise

    async def get_namespace_stats(self, client: Client) -> Dict[str, Any]:
        """Get statistics for a client's namespace.

        Args:
            client: Client object

        Returns:
            Dict with vector count and other stats
        """
        namespace = client.embedding_namespace

        try:
            stats = self.index.describe_index_stats()

            namespace_stats = stats.namespaces.get(namespace, {})

            return {
                'namespace': namespace,
                'vector_count': namespace_stats.get('vector_count', 0),
                'client_name': client.name,
                'client_id': str(client.id)
            }

        except Exception as e:
            logger.error(f"Failed to get namespace stats for {client.name}: {str(e)}")
            return {
                'namespace': namespace,
                'vector_count': 0,
                'error': str(e)
            }

    def get_index_stats(self) -> Dict[str, Any]:
        """Get overall index statistics.

        Returns:
            Dict with total vectors, dimensions, etc.
        """
        try:
            stats = self.index.describe_index_stats()

            return {
                'index_name': self.index_name,
                'dimension': stats.dimension,
                'total_vector_count': stats.total_vector_count,
                'namespaces': len(stats.namespaces),
                'namespace_details': {
                    ns: {'vector_count': data.get('vector_count', 0)}
                    for ns, data in stats.namespaces.items()
                }
            }

        except Exception as e:
            logger.error(f"Failed to get index stats: {str(e)}")
            return {'error': str(e)}
