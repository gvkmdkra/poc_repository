import asyncio
import sys
import os

# Add the parent directory to the path so we can import from src
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from src.chat_agent import ChatAgent
from src.db_connector import TursoDBConnector
from src.vanna_integration import VannaSQLAgent
from src.twilio_handler import TwilioHandler


async def example_basic_chat():
    print("=== Example 1: Basic Chat ===")
    agent = ChatAgent(enable_sql=False, enable_twilio=False)
    await agent.initialize()

    response = await agent.process_message("Hello! What can you help me with?")
    print(f"User: {response['user_message']}")
    print(f"AI: {response['ai_response']}\n")

    await agent.close()


async def example_sql_chat():
    print("=== Example 2: SQL-Enabled Chat ===")
    agent = ChatAgent(enable_sql=True, enable_twilio=False)
    await agent.initialize(train_db=True)

    agent.vanna_agent.train_ddl("""
        CREATE TABLE users (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            email TEXT UNIQUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    agent.vanna_agent.train_question_sql(
        "How many users do we have?",
        "SELECT COUNT(*) as total_users FROM users"
    )

    response = await agent.process_message("How many users are in the system?")
    print(f"User: {response['user_message']}")
    if response.get('sql_result'):
        print(f"SQL: {response['sql_result'].get('sql')}")
        print(f"Results: {response['sql_result'].get('results')}")
    print(f"AI: {response['ai_response']}\n")

    await agent.close()


async def example_twilio_integration():
    print("=== Example 3: Twilio Integration ===")
    agent = ChatAgent(enable_sql=True, enable_twilio=True)
    await agent.initialize()

    response = await agent.process_message("What's the weather like?")

    result = await agent.send_sms_response(
        to="+1234567890",
        message=response['ai_response']
    )
    print(f"SMS Send Result: {result}\n")

    await agent.close()


async def example_incoming_message_handler():
    print("=== Example 4: Handle Incoming SMS ===")
    agent = ChatAgent(enable_sql=True, enable_twilio=True)
    await agent.initialize()

    response = await agent.handle_incoming_sms(
        from_number="+1234567890",
        message="Hello, I need help with my account",
        auto_reply=True
    )

    print(f"Incoming from: {response['context']['from']}")
    print(f"Message: {response['user_message']}")
    print(f"AI Response: {response['ai_response']}")
    print(f"Auto-reply sent: {response.get('sms_sent', {}).get('success', False)}\n")

    await agent.close()


async def example_direct_db_usage():
    print("=== Example 5: Direct Database Usage ===")
    async with TursoDBConnector() as db:
        result = await db.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                content TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        print(f"Table created: {result}")

        await db.execute(
            "INSERT INTO messages (content) VALUES (?)",
            ["Hello from standalone usage!"]
        )

        messages = await db.fetch_all("SELECT * FROM messages")
        print(f"Messages: {messages}\n")


async def example_vanna_standalone():
    print("=== Example 6: Vanna AI Standalone ===")
    vanna = VannaSQLAgent()
    await vanna.setup_db()

    vanna.train_ddl("""
        CREATE TABLE products (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            price REAL NOT NULL,
            category TEXT
        )
    """)

    vanna.train_question_sql(
        "What are all the products?",
        "SELECT * FROM products"
    )

    result = await vanna.ask("Show me all products")
    print(f"Question: {result['question']}")
    print(f"Generated SQL: {result['sql']}")
    print(f"Success: {result['success']}\n")

    await vanna.close()


async def example_twilio_standalone():
    print("=== Example 7: Twilio Standalone ===")
    twilio = TwilioHandler()

    result = twilio.send_sms(
        to="+1234567890",
        message="Hello from the reusable chat agent!"
    )
    print(f"SMS Result: {result}")

    whatsapp_result = twilio.send_whatsapp(
        to="+1234567890",
        message="Hello via WhatsApp!"
    )
    print(f"WhatsApp Result: {whatsapp_result}\n")


async def example_custom_callbacks():
    print("=== Example 8: Custom Message Callbacks ===")
    agent = ChatAgent(enable_sql=True, enable_twilio=False)
    await agent.initialize()

    def log_callback(message_data):
        print(f"[CALLBACK] Message logged: {message_data['user_message']}")

    async def async_callback(message_data):
        print(f"[ASYNC CALLBACK] Processed: {message_data['user_message']}")

    agent.add_message_callback(log_callback)
    agent.add_message_callback(async_callback)

    response = await agent.process_message("Test message with callbacks")
    print(f"Response: {response['ai_response']}\n")

    await agent.close()


async def main():
    print("=" * 60)
    print("REUSABLE CHAT AGENT - STANDALONE USAGE EXAMPLES")
    print("=" * 60 + "\n")

    await example_basic_chat()

    print("\nNote: Other examples require proper database setup and Twilio credentials")
    print("Uncomment the following to run all examples:\n")

    print("# await example_sql_chat()")
    print("# await example_twilio_integration()")
    print("# await example_incoming_message_handler()")
    print("# await example_direct_db_usage()")
    print("# await example_vanna_standalone()")
    print("# await example_twilio_standalone()")
    print("# await example_custom_callbacks()")


if __name__ == "__main__":
    asyncio.run(main())
