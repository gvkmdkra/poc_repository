#!/usr/bin/env python3
"""
Client Onboarding Script for Enterprise Multi-Tenant Chat Agent

This script automates the process of:
1. Creating a new client
2. Setting up their database schema
3. Optionally training with example data
4. Testing the client's access

Usage:
    python onboard_client.py --name "Company Name" --email "contact@company.com" --industry "retail"
    python onboard_client.py --interactive
"""

import asyncio
import argparse
import json
import sys
from pathlib import Path
from typing import Optional, List, Dict, Any
import httpx
from rich.console import Console
from rich.table import Table
from rich.prompt import Prompt, Confirm
from rich.panel import Panel
from rich import print as rprint

console = Console()

# Default API base URL
DEFAULT_API_URL = "http://localhost:8000"


class ClientOnboarder:
    """Handles automated client onboarding process"""

    def __init__(self, api_url: str = DEFAULT_API_URL):
        self.api_url = api_url
        self.client: Optional[httpx.AsyncClient] = None
        self.created_client: Optional[Dict[str, Any]] = None

    async def __aenter__(self):
        self.client = httpx.AsyncClient(timeout=30.0)
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.client:
            await self.client.aclose()

    async def check_api_health(self) -> bool:
        """Check if API is running and healthy"""
        try:
            response = await self.client.get(f"{self.api_url}/health")
            response.raise_for_status()
            health_data = response.json()

            console.print("[green]✓[/green] API is healthy")
            console.print(f"  Chat agent: {health_data.get('chat_agent', False)}")
            console.print(f"  SQL enabled: {health_data.get('sql_enabled', False)}")
            console.print(f"  Twilio enabled: {health_data.get('twilio_enabled', False)}")
            return True

        except httpx.ConnectError:
            console.print("[red]✗[/red] Cannot connect to API")
            console.print(f"  Make sure server is running at {self.api_url}")
            console.print("  Run: python run.py")
            return False

        except Exception as e:
            console.print(f"[red]✗[/red] Health check failed: {e}")
            return False

    async def create_client(self, name: str, contact_email: str,
                          industry: Optional[str] = None,
                          db_url: Optional[str] = None,
                          db_auth_token: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Create a new client in the system"""

        console.print("\n[bold cyan]Creating new client...[/bold cyan]")

        client_data = {
            "name": name,
            "contact_email": contact_email,
            "industry": industry or "general"
        }

        # Add custom DB credentials if provided
        if db_url and db_auth_token:
            client_data["db_url"] = db_url
            client_data["db_auth_token"] = db_auth_token

        try:
            response = await self.client.post(
                f"{self.api_url}/clients",
                json=client_data
            )
            response.raise_for_status()

            self.created_client = response.json()

            # Display client info in a nice table
            table = Table(title="Client Created Successfully", show_header=True)
            table.add_column("Field", style="cyan")
            table.add_column("Value", style="green")

            table.add_row("Client ID", self.created_client["id"])
            table.add_row("Name", self.created_client["name"])
            table.add_row("Industry", self.created_client.get("industry", "N/A"))
            table.add_row("Contact Email", self.created_client["contact_email"])
            table.add_row("API Key", f"[bold]{self.created_client['api_key']}[/bold]")
            table.add_row("Schema Name", self.created_client["schema_name"])
            table.add_row("Embedding Namespace", self.created_client["embedding_namespace"])
            table.add_row("Status", "Active" if self.created_client["is_active"] else "Inactive")
            table.add_row("Created At", self.created_client["created_at"])

            console.print(table)

            # Save to file
            output_file = Path(f"client_{self.created_client['id']}_credentials.json")
            with open(output_file, "w") as f:
                json.dump(self.created_client, f, indent=2)

            console.print(f"\n[green]✓[/green] Client credentials saved to: {output_file}")
            console.print(f"[yellow]⚠[/yellow]  IMPORTANT: Save the API key securely!")

            return self.created_client

        except httpx.HTTPStatusError as e:
            console.print(f"[red]✗[/red] Failed to create client: {e.response.status_code}")
            console.print(f"  {e.response.text}")
            return None

        except Exception as e:
            console.print(f"[red]✗[/red] Error creating client: {e}")
            return None

    async def train_client(self, api_key: str, training_file: Optional[str] = None,
                          examples: Optional[List[Dict[str, str]]] = None) -> bool:
        """Train the client with example questions and SQL queries"""

        console.print("\n[bold cyan]Training client with examples...[/bold cyan]")

        training_data = []

        # Load from file if provided
        if training_file:
            try:
                with open(training_file, "r") as f:
                    training_data = json.load(f)
                console.print(f"[green]✓[/green] Loaded {len(training_data)} examples from {training_file}")
            except Exception as e:
                console.print(f"[red]✗[/red] Failed to load training file: {e}")
                return False

        # Use provided examples
        elif examples:
            training_data = examples

        # Default examples if none provided
        else:
            training_data = [
                {
                    "question": "How many records are in the database?",
                    "sql": "SELECT COUNT(*) as total FROM information_schema.tables"
                },
                {
                    "question": "Show me the latest 10 entries",
                    "sql": "SELECT * FROM main_table ORDER BY created_at DESC LIMIT 10"
                }
            ]
            console.print("[yellow]![/yellow] Using default training examples")

        try:
            response = await self.client.post(
                f"{self.api_url}/train",
                headers={"X-API-Key": api_key},
                json={"examples": training_data}
            )
            response.raise_for_status()

            result = response.json()
            console.print(f"[green]✓[/green] Training completed successfully")
            console.print(f"  Examples trained: {result.get('examples_trained', len(training_data))}")
            return True

        except httpx.HTTPStatusError as e:
            console.print(f"[red]✗[/red] Training failed: {e.response.status_code}")
            console.print(f"  {e.response.text}")
            return False

        except Exception as e:
            console.print(f"[red]✗[/red] Error during training: {e}")
            return False

    async def test_client_access(self, api_key: str) -> bool:
        """Test the client's API access with a simple query"""

        console.print("\n[bold cyan]Testing client access...[/bold cyan]")

        try:
            # Test health check with API key
            response = await self.client.post(
                f"{self.api_url}/chat",
                headers={"X-API-Key": api_key},
                json={
                    "message": "SELECT 1 as test",
                    "check_sql": True
                }
            )
            response.raise_for_status()

            result = response.json()
            console.print("[green]✓[/green] Client access verified")
            console.print(f"  Response received: {result.get('response', 'OK')}")
            return True

        except httpx.HTTPStatusError as e:
            if e.response.status_code == 401:
                console.print("[red]✗[/red] Authentication failed - Invalid API key")
            else:
                console.print(f"[red]✗[/red] Access test failed: {e.response.status_code}")
                console.print(f"  {e.response.text}")
            return False

        except Exception as e:
            console.print(f"[red]✗[/red] Error testing access: {e}")
            return False

    async def refresh_schema(self, api_key: str) -> bool:
        """Refresh the database schema cache for the client"""

        console.print("\n[bold cyan]Refreshing database schema...[/bold cyan]")

        try:
            response = await self.client.post(
                f"{self.api_url}/refresh-schema",
                headers={"X-API-Key": api_key}
            )
            response.raise_for_status()

            result = response.json()
            console.print(f"[green]✓[/green] Schema refreshed successfully")
            console.print(f"  Tables found: {result.get('table_count', 0)}")
            if result.get('tables'):
                console.print(f"  Tables: {', '.join(result['tables'][:5])}")
            return True

        except Exception as e:
            console.print(f"[yellow]![/yellow] Schema refresh skipped: {e}")
            return False


async def interactive_onboarding():
    """Interactive mode for client onboarding"""

    console.print(Panel.fit(
        "[bold cyan]Enterprise Multi-Tenant Chat Agent[/bold cyan]\n"
        "[white]Client Onboarding Wizard[/white]",
        border_style="cyan"
    ))

    # Get client details
    name = Prompt.ask("\n[cyan]Client Name[/cyan]")
    contact_email = Prompt.ask("[cyan]Contact Email[/cyan]")
    industry = Prompt.ask("[cyan]Industry[/cyan]", default="general")

    # Ask about custom database
    use_custom_db = Confirm.ask("\n[cyan]Use custom Turso database?[/cyan]", default=False)
    db_url = None
    db_auth_token = None

    if use_custom_db:
        db_url = Prompt.ask("[cyan]Database URL[/cyan]")
        db_auth_token = Prompt.ask("[cyan]Database Auth Token[/cyan]", password=True)

    # Ask about training
    should_train = Confirm.ask("\n[cyan]Train with examples now?[/cyan]", default=True)
    training_file = None

    if should_train:
        has_training_file = Confirm.ask("[cyan]Do you have a training file (JSON)?[/cyan]", default=False)
        if has_training_file:
            training_file = Prompt.ask("[cyan]Training file path[/cyan]")

    # Perform onboarding
    api_url = Prompt.ask("\n[cyan]API URL[/cyan]", default=DEFAULT_API_URL)

    async with ClientOnboarder(api_url=api_url) as onboarder:
        # Check API health
        console.print("\n" + "="*60)
        if not await onboarder.check_api_health():
            console.print("\n[red]✗ Onboarding aborted - API not available[/red]")
            return

        # Create client
        console.print("\n" + "="*60)
        client = await onboarder.create_client(
            name=name,
            contact_email=contact_email,
            industry=industry,
            db_url=db_url,
            db_auth_token=db_auth_token
        )

        if not client:
            console.print("\n[red]✗ Onboarding failed - Could not create client[/red]")
            return

        api_key = client["api_key"]

        # Refresh schema
        console.print("\n" + "="*60)
        await onboarder.refresh_schema(api_key)

        # Train if requested
        if should_train:
            console.print("\n" + "="*60)
            await onboarder.train_client(api_key, training_file=training_file)

        # Test access
        console.print("\n" + "="*60)
        await onboarder.test_client_access(api_key)

        # Summary
        console.print("\n" + "="*60)
        console.print(Panel.fit(
            f"[bold green]✓ Onboarding Complete![/bold green]\n\n"
            f"[white]Client: {name}\n"
            f"API Key: [bold]{api_key}[/bold]\n"
            f"Credentials saved to: client_{client['id']}_credentials.json[/white]",
            border_style="green"
        ))


async def automated_onboarding(args):
    """Automated mode for client onboarding"""

    async with ClientOnboarder(api_url=args.api_url) as onboarder:
        # Check API health
        if not await onboarder.check_api_health():
            sys.exit(1)

        # Create client
        client = await onboarder.create_client(
            name=args.name,
            contact_email=args.email,
            industry=args.industry,
            db_url=args.db_url,
            db_auth_token=args.db_auth_token
        )

        if not client:
            sys.exit(1)

        api_key = client["api_key"]

        # Refresh schema
        await onboarder.refresh_schema(api_key)

        # Train if file provided
        if args.training_file:
            success = await onboarder.train_client(api_key, training_file=args.training_file)
            if not success and not args.skip_errors:
                sys.exit(1)

        # Test access unless skipped
        if not args.skip_test:
            success = await onboarder.test_client_access(api_key)
            if not success and not args.skip_errors:
                sys.exit(1)

        console.print(f"\n[bold green]✓ Client onboarded successfully![/bold green]")
        console.print(f"[white]API Key: {api_key}[/white]")


def main():
    parser = argparse.ArgumentParser(
        description="Onboard new clients to the Enterprise Multi-Tenant Chat Agent"
    )

    parser.add_argument("--interactive", "-i", action="store_true",
                       help="Run in interactive mode")
    parser.add_argument("--name", type=str, help="Client name")
    parser.add_argument("--email", type=str, help="Contact email")
    parser.add_argument("--industry", type=str, default="general",
                       help="Client industry (default: general)")
    parser.add_argument("--db-url", type=str, help="Custom Turso DB URL")
    parser.add_argument("--db-auth-token", type=str, help="Custom Turso DB auth token")
    parser.add_argument("--training-file", type=str,
                       help="JSON file with training examples")
    parser.add_argument("--api-url", type=str, default=DEFAULT_API_URL,
                       help=f"API base URL (default: {DEFAULT_API_URL})")
    parser.add_argument("--skip-test", action="store_true",
                       help="Skip access test")
    parser.add_argument("--skip-errors", action="store_true",
                       help="Continue on errors")

    args = parser.parse_args()

    try:
        if args.interactive or (not args.name or not args.email):
            asyncio.run(interactive_onboarding())
        else:
            asyncio.run(automated_onboarding(args))
    except KeyboardInterrupt:
        console.print("\n\n[yellow]Onboarding cancelled by user[/yellow]")
        sys.exit(130)
    except Exception as e:
        console.print(f"\n[red]✗ Fatal error: {e}[/red]")
        sys.exit(1)


if __name__ == "__main__":
    main()
