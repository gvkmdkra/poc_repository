# 🚀 Quick Start Guide - Run End to End

## Step-by-Step Instructions

### ✅ Step 1: Start the Server

1. Open PowerShell
2. Navigate to the project directory:
```powershell
cd c:\Users\Mani_Moon\reapdat\code_integration\reusable_agents\chat_agents
```

3. Start the server:
```powershell
python run.py
```

4. **Wait for this message:**
```
INFO:     Uvicorn running on http://0.0.0.0:8000 (Press CTRL+C to quit)
```

5. **⚠️ IMPORTANT: Keep this PowerShell window open!** Don't close it.

---

### ✅ Step 2: Test the Server

Open a **NEW** PowerShell window and test:

```powershell
# Test 1: Health check
curl http://localhost:8000/health

# Expected response:
# {"status":"healthy","chat_agent":true,"sql_enabled":true,"twilio_enabled":true}
```

```powershell
# Test 2: Simple chat
curl -X POST http://localhost:8000/chat -H "Content-Type: application/json" -d '{\"message\":\"Hello!\",\"check_sql\":false}'

# Expected: You'll get a JSON response with an AI greeting
```

```powershell
# Test 3: SQL query
curl -X POST http://localhost:8000/chat -H "Content-Type: application/json" -d '{\"message\":\"Show me all tables in the database\",\"check_sql\":true}'

# Expected: You'll see your database tables (kfc_churn_data_src_tbl, etc.)
```

---

### ✅ Step 3: Open the Chat Interface

**Option A - Using File Explorer (RECOMMENDED):**

1. Open File Explorer
2. Navigate to: `c:\Users\Mani_Moon\reapdat\code_integration\reusable_agents\chat_agents\web`
3. Double-click on `chat_interface.html`
4. It will open in your default browser

**Option B - Direct Browser Access:**

Open your browser and type in the address bar:
```
file:///c:/Users/Mani_Moon/reapdat/code_integration/reusable_agents/chat_agents/web/chat_interface.html
```

**⚠️ DO NOT use:** `http://0.0.0.0:8000` - this won't work!
**✅ USE:** `http://localhost:8000` or open the HTML file directly

---

### ✅ Step 4: Test the Chat Interface

Once the chat interface opens:

1. **Check Status** - Top right should show "Online" (green)
   - If it shows "Offline" (red), click "Check Health" button

2. **Test Basic Chat:**
   - Type: `Hello! How are you?`
   - Press Enter or click Send
   - You should get a response within 2-3 seconds

3. **Test SQL Features:**
   - Click the "Check SQL" toggle to enable it (turn it ON)
   - Type: `Show me all tables in my database`
   - Press Enter
   - You should see SQL query + results + explanation

4. **Test Your Data:**
   - Keep "Check SQL" enabled
   - Type: `How many records are in kfc_churn_data_src_tbl?`
   - You should see: 408 records

---

### ✅ Step 5: View API Documentation

Open your browser and go to:
```
http://localhost:8000/docs
```

This shows the interactive API documentation (Swagger UI) where you can:
- See all available endpoints
- Test each endpoint directly
- View request/response formats

---

## 🎯 Quick Test Checklist

- [ ] Server started successfully
- [ ] Health check returns healthy status
- [ ] curl commands work
- [ ] Chat interface opens
- [ ] Status shows "Online"
- [ ] Basic chat works
- [ ] SQL queries work
- [ ] Can see your database tables
- [ ] API docs accessible

---

## 🔧 Troubleshooting

### Problem: Server won't start (Port already in use)

**Error:**
```
ERROR: [Errno 10048] error while attempting to bind on address ('0.0.0.0', 8000)
```

**Solution:**
```powershell
# Find process using port 8000
netstat -ano | findstr :8000

# Kill the process (replace XXXXX with PID from above)
taskkill /F /PID XXXXX

# Try starting server again
python run.py
```

---

### Problem: Chat interface shows "Offline"

**Solution:**
1. Make sure server is running (check PowerShell window)
2. Click "Check Health" button in chat interface
3. Refresh the page (F5)
4. Make sure you're using `localhost:8000` not `0.0.0.0:8000`

---

### Problem: Browser shows "Can't reach this page"

**Common Mistakes:**
- ❌ Accessing `http://0.0.0.0:8000` - This won't work!
- ❌ Accessing `http://127.0.0.1:8000/web/chat_interface.html` - Wrong path!

**Correct Methods:**
- ✅ Open the HTML file directly from File Explorer
- ✅ Use `http://localhost:8000/docs` for API docs
- ✅ Chat interface should auto-connect to `localhost:8000`

---

### Problem: SQL queries not working

**Solution:**
1. Make sure "Check SQL" toggle is ON
2. Server logs should show: `sql_enabled: true`
3. Your .env file must have valid `TURSO_DB_URL` and `TURSO_DB_AUTH_TOKEN`
4. Test with: `curl http://localhost:8000/health` and verify `sql_enabled: true`

---

## 📊 What You Should See

### Server Terminal:
```
======================================================================
Starting Reusable Chat Agent Server
======================================================================

Server Information:
   URL:      http://localhost:8000
   API Docs: http://localhost:8000/docs
   Health:   http://localhost:8000/health

To test:
   1. Open: web/chat_interface.html in your browser
   2. Or visit: http://localhost:8000/docs

To stop: Press CTRL+C
======================================================================

INFO:     Started server process [XXXXX]
INFO:     Waiting for application startup.
INFO:src.chat_agent:Chat agent initialized successfully
INFO:src.api:Chat agent initialized
INFO:     Application startup complete.
INFO:     Uvicorn running on http://0.0.0.0:8000 (Press CTRL+C to quit)
```

### Chat Interface:
- Purple gradient background
- White chat window
- "Reusable Chat Agent" header
- Status: "Online" (green)
- Message input box at bottom
- Quick action buttons
- Check SQL toggle

---

## 🎬 Demo Script

### 1-Minute Quick Demo:

1. **Start:** `python run.py`
2. **Open:** `web/chat_interface.html`
3. **Chat:** Type "Hello!"
4. **SQL:** Enable toggle, type "Show me all tables"
5. **Done!** Everything working

### 5-Minute Full Demo:

1. Show server starting
2. Show health check: `curl http://localhost:8000/health`
3. Open chat interface
4. Basic conversation
5. Enable SQL, query database
6. Show API docs at `/docs`
7. Test API endpoint in Swagger UI
8. Show conversation history

---

## 🛑 How to Stop

To stop the server:
1. Go to the PowerShell window where server is running
2. Press `Ctrl + C`
3. Wait for graceful shutdown

---

## 📝 Next Steps

After successful testing:

1. **Read Documentation:**
   - `docs/ARCHITECTURE.md` - Technical architecture
   - `docs/CHAT_INTERFACE_TESTING.md` - Complete test cases
   - `docs/API_USAGE.md` - How to integrate into websites

2. **Try Examples:**
```powershell
python examples/standalone_usage.py
```

3. **Run Tests:**
```powershell
pytest tests/ -v
```

4. **Deploy:**
   - See `docs/DOCUMENTATION.md` for deployment options

---

## 💡 Tips

1. **Always use `localhost:8000`** - Never use `0.0.0.0:8000`
2. **Keep server terminal open** - Don't close it while testing
3. **Use new terminal for tests** - Don't run commands in server terminal
4. **Check logs** - Server terminal shows all activity
5. **Refresh browser** - If interface shows offline, press F5

---

## ✅ Success Indicators

You know it's working when:
- ✅ Server shows "Application startup complete"
- ✅ Health check returns `{"status":"healthy"}`
- ✅ Chat interface shows "Online" status
- ✅ Bot responds to messages
- ✅ SQL queries show your database tables
- ✅ No errors in server terminal

---

## 🎯 Your Database

Connected to: **churnguard** (Turso Database)

**Tables:**
- `kfc_churn_data_src_tbl` (408 records) - Customer churn data
- `kfc_churn_predict_tbl` - Churn predictions
- `kfc_review_sentiment_tbl` - Sentiment analysis
- `test_products` - Product information

**Test Queries:**
- "Show me all tables"
- "How many records are in kfc_churn_data_src_tbl?"
- "Show me 5 records from kfc_churn_data_src_tbl"
- "What's in the database?"

---

## 📞 Support

If you encounter issues:
1. Check this guide's Troubleshooting section
2. Check server logs for error messages
3. Verify .env file has all required credentials
4. Make sure all dependencies are installed: `pip install -r requirements.txt`

---

**That's it! You're ready to go! 🚀**

Start with Step 1 above and follow each step in order.
