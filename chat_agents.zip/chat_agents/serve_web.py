"""
Simple HTTP server to serve the web interface files.
Run this to test the chat widgets in a browser with proper CORS support.

Usage:
    python serve_web.py

Then open: http://localhost:8080/chat_widget.html
Or: http://localhost:8080/embed_advanced_example.html
"""

import http.server
import socketserver
import os
import sys

PORT = 8080
DIRECTORY = "web"

class CORSRequestHandler(http.server.SimpleHTTPRequestHandler):
    """HTTP request handler with CORS headers."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)

    def end_headers(self):
        """Add CORS headers to all responses."""
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, X-API-Key')
        super().end_headers()

    def do_OPTIONS(self):
        """Handle preflight requests."""
        self.send_response(200)
        self.end_headers()

def main():
    """Start the web server."""

    # Change to the script's directory
    os.chdir(os.path.dirname(os.path.abspath(__file__)))

    # Check if web directory exists
    if not os.path.exists(DIRECTORY):
        print(f"Error: {DIRECTORY} directory not found!")
        sys.exit(1)

    print("=" * 70)
    print("Starting Web Server for Chat Widgets")
    print("=" * 70)
    print()
    print(f"Server running on http://localhost:{PORT}")
    print()
    print("Available pages:")
    print(f"  • Chat Widget:           http://localhost:{PORT}/chat_widget.html")
    print(f"  • Advanced Interface:    http://localhost:{PORT}/chat_interface_advanced.html")
    print(f"  • Embed Example:         http://localhost:{PORT}/embed_example.html")
    print(f"  • Advanced Embed:        http://localhost:{PORT}/embed_advanced_example.html")
    print()
    print("With Authentication:")
    print(f"  • Advanced + Auth:       http://localhost:{PORT}/chat_interface_advanced.html?apiKey=sk_live_5eba7c2f74be13485739063a59015bb5c6aa8021d22da4528a491b9a07f7d3a3&clientId=358c1b8d-8b30-4218-8c88-d70c5a1fb788")
    print()
    print("To stop: Press CTRL+C")
    print("=" * 70)
    print()

    try:
        with socketserver.TCPServer(("", PORT), CORSRequestHandler) as httpd:
            httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n\nShutting down server...")
        sys.exit(0)
    except OSError as e:
        if e.errno == 10048:  # Port already in use
            print(f"\nError: Port {PORT} is already in use!")
            print(f"Please close the application using port {PORT} or change the PORT variable in this script.")
            sys.exit(1)
        else:
            raise

if __name__ == "__main__":
    main()
