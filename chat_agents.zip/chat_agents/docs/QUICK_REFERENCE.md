# Quick Reference Guide

## Testing the Chat Interface - 3 Easy Steps

### Step 1: Start Server
```bash
python run.py
```
Wait for: `Uvicorn running on http://0.0.0.0:8000`

### Step 2: Open Interface
- Navigate to: `c:\Users\Mani_Moon\reapdat\code_integration\reusable_agents\chat_agents\web`
- Double-click: `chat_interface.html`

### Step 3: Test
- Status shows "Online" (green) = ✅ Working
- Type message and hit Enter = ✅ Working
- Bot responds = ✅ All systems go!

---

## Technical Components Summary

| Component | Technology | Purpose |
|-----------|-----------|---------|
| **API Layer** | FastAPI | HTTP endpoints, request handling |
| **AI Engine** | Google Gemini | Chat responses, natural language |
| **SQL Agent** | Custom Gemini | Natural language → SQL conversion |
| **Database** | Turso DB (LibSQL) | Serverless SQLite storage |
| **Messaging** | Twilio | SMS & WhatsApp integration |
| **Configuration** | Pydantic Settings | Environment management |
| **Web Interface** | HTML/CSS/JS | User-facing chat UI |

---

## Architecture at a Glance

```
User (Browser)
    ↓ HTTP
FastAPI Server (localhost:8000)
    ↓
ChatAgent (Orchestrator)
    ↓↓↓
    ├─→ Gemini AI (Chat responses)
    ├─→ VannaSQLAgent → Turso DB (SQL queries)
    └─→ TwilioHandler → Twilio API (SMS/WhatsApp)
```

---

## FastAPI vs MCP - Quick Answer

**Use FastAPI when:**
- ✅ Embedding in websites (React, Vue, WordPress)
- ✅ Mobile app backends
- ✅ Public APIs
- ✅ Any HTTP client (universal access)
- ✅ **This is what you have now - perfect for web use!**

**Add MCP when:**
- ✅ Claude Desktop integration needed
- ✅ VS Code extension wanted
- ✅ AI-native tool development
- ❌ **NOT needed for web/mobile** (FastAPI is better)

**Recommendation:** **Stick with FastAPI** for your use case. It's perfect for web integration and calling from websites. Only add MCP if you specifically need Claude Desktop integration.

---

## Common Test Commands

**Start server:**
```bash
python run.py
```

**Run tests:**
```bash
pytest tests/ -v
```

**Test chat (curl):**
```bash
curl -X POST http://localhost:8000/chat -H "Content-Type: application/json" -d "{\"message\":\"Hello!\",\"check_sql\":false}"
```

**Check health:**
```bash
curl http://localhost:8000/health
```

**View API docs:**
Open browser: `http://localhost:8000/docs`

---

## File Structure Quick Map

```
chat_agents/
├── src/                    ← All Python code here
│   ├── api.py             → FastAPI endpoints
│   ├── chat_agent.py      → Main orchestrator
│   ├── vanna_integration.py → SQL generation
│   ├── db_connector.py    → Database connection
│   └── twilio_handler.py  → SMS/WhatsApp
│
├── web/                    ← Front-end here
│   └── chat_interface.html → Open this in browser
│
├── tests/                  ← All tests here
│   ├── test_api.py
│   └── ... (8 test files)
│
├── docs/                   ← Documentation here
│   ├── ARCHITECTURE.md    → You are reading related docs
│   ├── CHAT_INTERFACE_TESTING.md
│   └── ... (9 doc files)
│
└── run.py                  ← START HERE! Quick launch
```

---

## Essential Documentation

| Document | Purpose | When to Read |
|----------|---------|--------------|
| `ARCHITECTURE.md` | Technical design, component details | Understanding system design |
| `CHAT_INTERFACE_TESTING.md` | 15 test cases for chat UI | Testing before demo |
| `DOCUMENTATION.md` | Complete API reference | Integration & development |
| `DEMO_GUIDE.md` | Client presentation script | Before client meetings |
| `API_USAGE.md` | Code examples for integration | When embedding in website |
| `TESTING.md` | pytest guide | Running automated tests |

---

## Environment Variables Required

Create `.env` file with:
```env
GEMINI_API_KEY=your_gemini_key
TURSO_DB_URL=libsql://your-db.turso.io
TURSO_DB_AUTH_TOKEN=your_turso_token
TWILIO_ACCOUNT_SID=your_twilio_sid
TWILIO_AUTH_TOKEN=your_twilio_token
TWILIO_PHONE_NUMBER=+1234567890
LOG_LEVEL=INFO
```

---

## Key Features

### Current Capabilities ✅
- ✅ Natural language chat (Google Gemini)
- ✅ SQL query generation from natural language
- ✅ Database integration (Turso DB)
- ✅ SMS sending (Twilio)
- ✅ WhatsApp messaging (Twilio)
- ✅ Web chat interface
- ✅ REST API with auto-documentation
- ✅ Conversation history
- ✅ Callback system for extensibility
- ✅ Async operations throughout
- ✅ Full test coverage

### Integration Options ✅
- ✅ Embed in any website (HTML/JS)
- ✅ React/Vue components
- ✅ Mobile apps (HTTP API)
- ✅ Third-party services (REST API)
- ✅ Webhook support (Twilio)
- ✅ Standalone usage (Python module)

---

## FastAPI Advantages for Your Use Case

1. **Universal Access** - Any HTTP client can use it
2. **Web Ready** - Easy to embed in websites
3. **Auto Documentation** - Built-in Swagger UI at `/docs`
4. **Language Agnostic** - Clients can be Python, JS, Java, etc.
5. **Mature Ecosystem** - Lots of tools and libraries
6. **Easy Deployment** - Works on any cloud platform
7. **Standard REST** - Everyone knows how to use it

**Why NOT MCP for your case:**
- MCP is Claude/Anthropic specific
- Can't be called from websites easily
- Designed for desktop tools, not web integration
- FastAPI does everything you need better

---

## Quick Troubleshooting

| Problem | Solution |
|---------|----------|
| Interface shows "Offline" | 1. Check server running<br>2. Click "Check Health"<br>3. Refresh (F5) |
| Server won't start | 1. Check port 8000 free<br>2. Verify .env file exists<br>3. Install dependencies |
| No bot responses | 1. Check GEMINI_API_KEY in .env<br>2. Check server logs<br>3. Test with curl |
| SQL not working | 1. Enable "Check SQL" toggle<br>2. Train schema first<br>3. Check Turso credentials |

---

## API Endpoints Quick Reference

| Method | Endpoint | Purpose |
|--------|----------|---------|
| GET | `/` | Service info |
| GET | `/health` | Health check |
| POST | `/chat` | Send chat message |
| POST | `/sms/send` | Send SMS |
| POST | `/whatsapp/send` | Send WhatsApp |
| POST | `/webhook/twilio` | Receive Twilio messages |
| GET | `/history` | Get conversation history |
| DELETE | `/history` | Clear history |
| POST | `/train` | Train SQL agent |
| GET | `/training-data` | Get training data |

---

## Performance Benchmarks

| Operation | Expected Time |
|-----------|--------------|
| Simple chat response | < 3 seconds |
| SQL query generation | < 5 seconds |
| Database query execution | < 2 seconds |
| Total (chat + SQL + DB) | < 10 seconds |
| Server startup | < 5 seconds |

---

## Next Steps After Testing

1. ✅ Test locally (you're here!)
2. → Deploy to staging server
3. → Client acceptance testing
4. → Security audit
5. → Production deployment
6. → Monitor and optimize

---

## Getting Help

**Issue?** Check these in order:
1. This guide (QUICK_REFERENCE.md)
2. Detailed docs (docs/ARCHITECTURE.md)
3. Test guides (docs/TESTING.md)
4. API docs (http://localhost:8000/docs)
5. Server logs (terminal where `python run.py` is running)

**Common Docs:**
- How to test? → `docs/CHAT_INTERFACE_TESTING.md`
- How does it work? → `docs/ARCHITECTURE.md`
- How to integrate? → `docs/API_USAGE.md`
- How to demo? → `docs/DEMO_GUIDE.md`

---

## One-Line Summary

**This is a FastAPI-based chat agent with Google Gemini AI, SQL generation, Turso database, and Twilio messaging - perfect for embedding in websites via REST API.**

Use `python run.py` to start, open `web/chat_interface.html` to test!
