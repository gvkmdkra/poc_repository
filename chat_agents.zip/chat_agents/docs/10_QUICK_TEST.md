# How to Test on Your Local Machine

Your Enterprise Multi-Tenant Chat Agent is running and ready to test!

---

## ✅ System Status

**Server**: ✅ Running on http://localhost:8000
**Demo Client**: ✅ Created and active
**All Services**: ✅ Operational

---

## 🚀 Quick Test (30 seconds)

### Option 1: Web Browser (Easiest!)

1. Open your web browser
2. Go to: **http://localhost:8000/docs**
3. You'll see interactive API documentation (Swagger UI)
4. Click any endpoint → "Try it out" → "Execute"

**For authenticated endpoints**:
- Click "Authorize" button (top right)
- Enter API Key: `sk_live_5eba7c2f74be13485739063a59015bb5c6aa8021d22da4528a491b9a07f7d3a3`
- Click "Authorize"
- Now test any endpoint!

### Option 2: PowerShell (Automated)

Open PowerShell and run:

```powershell
cd c:\Users\Mani_Moon\reapdat\code_integration\reusable_agents\chat_agents
.\test_simple.ps1
```

**You'll see**:
```
Testing Enterprise Multi-Tenant Chat Agent
Test 1: Health Check
Status: healthy
Multi-Tenant: True

Test 2: Get Demo Client Details
Client: Demo Company
Industry: retail
Active: True

Test 3: RAG Statistics
Total Vectors: 1
Dimension: 3072
Model: text-embedding-3-large

All tests passed! System is operational.
```

---

## 📝 Manual Testing

### Test 1: Health Check (No authentication)
```powershell
Invoke-RestMethod -Uri "http://localhost:8000/health" | ConvertTo-Json
```

### Test 2: Get Client Info (With authentication)
```powershell
$headers = @{"X-API-Key" = "sk_live_5eba7c2f74be13485739063a59015bb5c6aa8021d22da4528a491b9a07f7d3a3"}
Invoke-RestMethod -Uri "http://localhost:8000/clients/358c1b8d-8b30-4218-8c88-d70c5a1fb788" -Headers $headers | ConvertTo-Json
```

### Test 3: Train with Examples
```powershell
$headers = @{
    "X-API-Key" = "sk_live_5eba7c2f74be13485739063a59015bb5c6aa8021d22da4528a491b9a07f7d3a3"
    "Content-Type" = "application/json"
}
$body = @{
    examples = @(
        @{
            question = "How many customers?"
            sql = "SELECT COUNT(*) FROM customers"
        }
    )
} | ConvertTo-Json -Depth 10

Invoke-RestMethod -Uri "http://localhost:8000/train" -Method Post -Headers $headers -Body $body | ConvertTo-Json
```

### Test 4: Check Training Status
```powershell
$headers = @{"X-API-Key" = "sk_live_5eba7c2f74be13485739063a59015bb5c6aa8021d22da4528a491b9a07f7d3a3"}
Invoke-RestMethod -Uri "http://localhost:8000/training/status" -Headers $headers | ConvertTo-Json
```

---

## 🎯 Your Demo Client Credentials

```
Client ID:    358c1b8d-8b30-4218-8c88-d70c5a1fb788
API Key:      sk_live_5eba7c2f74be13485739063a59015bb5c6aa8021d22da4528a491b9a07f7d3a3
Schema:       client_358c1b8d8b3042188c88d70c5a1fb788
Namespace:    client-358c1b8d
```

---

## 📚 Complete Documentation

1. **[LOCAL_TESTING_GUIDE.md](LOCAL_TESTING_GUIDE.md)** - Comprehensive testing guide with all methods
2. **[DEMO_GUIDE.md](DEMO_GUIDE.md)** - Full demo client user guide
3. **[DEMO_TEST_RESULTS.md](DEMO_TEST_RESULTS.md)** - Complete test results
4. **[SYSTEM_READY.md](SYSTEM_READY.md)** - System status and quick reference

---

## 🌐 URLs

- **Server**: http://localhost:8000
- **API Docs** (Interactive): http://localhost:8000/docs
- **Health Check**: http://localhost:8000/health
- **API Info**: http://localhost:8000/

---

## ✅ What's Working

### All Services Initialized
- ✅ Client Service (Multi-Tenant)
- ✅ OpenAI GPT-4 Turbo
- ✅ OpenAI Embeddings (3072-dim)
- ✅ Pinecone Vector Store
- ✅ RAG Pipeline
- ✅ Turso Database
- ✅ Twilio Handler

### All Tests Passed
- ✅ Health check
- ✅ Client creation
- ✅ Get client details
- ✅ Refresh schema
- ✅ Train examples
- ✅ Training status
- ✅ RAG statistics
- ✅ Authentication

---

## 🎓 Next Steps

1. **Test Now**: Run `.\test_simple.ps1` or visit http://localhost:8000/docs
2. **Add Data**: Create tables in Turso database (see [LOCAL_TESTING_GUIDE.md](LOCAL_TESTING_GUIDE.md#step-1-create-tables-in-turso))
3. **Train More**: Add more training examples for better SQL generation
4. **Generate SQL**: Test SQL generation with your actual data

---

## 🐛 Troubleshooting

### Server Not Running?
```powershell
# Check if port 8000 is in use
netstat -ano | findstr :8000

# If nothing running, start server
cd c:\Users\Mani_Moon\reapdat\code_integration\reusable_agents\chat_agents
python run.py
```

### PowerShell Script Not Running?
```powershell
# Allow scripts to run
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

# Then run the test
.\test_simple.ps1
```

---

## 🎉 Success!

Your system is **100% operational** and ready for production use!

**Test it now**: `.\test_simple.ps1` or visit http://localhost:8000/docs
