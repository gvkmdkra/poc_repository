# Client Data Integration Guide

Complete guide for clients to integrate their data with your Chat Agent and make it queryable.

---

## 🎯 Overview

Your chat agent is **multi-tenant** and **reusable**. Each client:
1. Gets a unique API key
2. Has their own isolated database schema in Turso
3. Can pass their data to make it queryable
4. Can embed the chat widget on their website

---

## 📊 How Data Integration Works

### Architecture Flow

```
Client Website
    ↓
[API Key Authentication]
    ↓
Client's Isolated Schema (Turso)
    ↓
RAG Pipeline (Pinecone)
    ↓
OpenAI GPT-4 (SQL Generation)
    ↓
Query Results
```

---

## 🔑 Step 1: Create Client Account

### For You (Admin)

Create a new client using the API:

```powershell
curl -X POST http://localhost:8000/clients `
  -H "Content-Type: application/json" `
  -d '{
    "name": "Client Company Name",
    "contact_email": "client@company.com",
    "industry": "retail"
  }'
```

**Response**:
```json
{
  "id": "uuid-here",
  "name": "Client Company Name",
  "api_key": "sk_live_xxxxx",  // ← Give this to client
  "schema_name": "client_xxxxx", // ← Client's isolated schema
  "embedding_namespace": "client-xxxxx" // ← Client's vector namespace
}
```

### What Client Gets

```
API Key:     sk_live_xxxxx  // For authentication
Client ID:   uuid-here       // For reference
Schema:      client_xxxxx    // Their database schema
Namespace:   client-xxxxx    // Their vector space
```

---

## 📥 Step 2: Client Passes Their Data

There are **3 ways** clients can make their data queryable:

### Method 1: Direct Database Connection (Recommended)

Client creates tables in their Turso schema.

**Option A: Using Turso CLI**

```bash
# Client connects to their schema
turso db shell your-database-name

# Create tables in their schema
CREATE TABLE client_xxxxx.customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT,
    phone TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE client_xxxxx.orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER,
    amount REAL,
    status TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id)
);

# Insert data
INSERT INTO client_xxxxx.customers (name, email, phone)
VALUES ('John Doe', 'john@example.com', '+1234567890');
```

**Option B: Using API (Programmatic)**

```javascript
// Client's website/backend code
const createTable = async () => {
  const response = await fetch('https://api.turso.tech/v1/databases/your-db/execute', {
    method: 'POST',
    headers: {
      'Authorization': 'Bearer <turso-token>',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      statements: [
        `CREATE TABLE IF NOT EXISTS client_xxxxx.customers (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT,
          email TEXT
        )`,
        `INSERT INTO client_xxxxx.customers (name, email) VALUES ('John', 'john@example.com')`
      ]
    })
  });

  return response.json();
};
```

### Method 2: CSV/Excel Upload (Future Enhancement)

You can build an upload endpoint:

```python
# Add to src/api.py
@app.post("/upload-data")
async def upload_data(
    file: UploadFile,
    table_name: str,
    client: Client = Depends(get_current_client)
):
    # Read CSV/Excel
    df = pd.read_csv(file.file)  # or read_excel

    # Get client's database connection
    conn = await db_connector.get_connection(client)

    # Create table in client's schema
    table_name_full = f"{client.schema_name}.{table_name}"

    # Insert data
    # Convert DataFrame to SQL INSERT statements
    # ...

    return {"success": True, "rows_inserted": len(df)}
```

Then clients can upload:

```javascript
const formData = new FormData();
formData.append('file', csvFile);
formData.append('table_name', 'customers');

fetch('http://localhost:8000/upload-data', {
  method: 'POST',
  headers: {
    'X-API-Key': 'sk_live_xxxxx'
  },
  body: formData
});
```

### Method 3: API-Based Data Sync

Client syncs data from their system via API calls.

```python
# Add to src/api.py
@app.post("/sync-data")
async def sync_data(
    table_name: str,
    data: List[Dict[str, Any]],
    client: Client = Depends(get_current_client)
):
    conn = await db_connector.get_connection(client)

    # Create table if doesn't exist (infer schema from data)
    # Insert/update data
    # ...

    return {"success": True, "rows_synced": len(data)}
```

Client uses it:

```javascript
// From client's website/backend
fetch('http://localhost:8000/sync-data', {
  method: 'POST',
  headers: {
    'X-API-Key': 'sk_live_xxxxx',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    table_name: 'customers',
    data: [
      { name: 'John Doe', email: 'john@example.com' },
      { name: 'Jane Smith', email: 'jane@example.com' }
    ]
  })
});
```

---

## 🔄 Step 3: Refresh Schema

After client adds data, they must refresh the schema cache:

```powershell
curl -X POST http://localhost:8000/refresh-schema `
  -H "X-API-Key: sk_live_xxxxx"
```

This tells the AI about the new tables and columns.

---

## 🎓 Step 4: Train with Examples

Clients should provide example questions and SQL queries:

```powershell
curl -X POST http://localhost:8000/train `
  -H "X-API-Key: sk_live_xxxxx" `
  -H "Content-Type: application/json" `
  -d '{
    "examples": [
      {
        "question": "How many customers do we have?",
        "sql": "SELECT COUNT(*) FROM customers"
      },
      {
        "question": "Show me customers who joined this month",
        "sql": "SELECT * FROM customers WHERE created_at >= date('now', 'start of month')"
      },
      {
        "question": "What's our total revenue?",
        "sql": "SELECT SUM(amount) as total_revenue FROM orders WHERE status = 'completed'"
      },
      {
        "question": "Show top 10 customers by order amount",
        "sql": "SELECT c.name, SUM(o.amount) as total FROM customers c JOIN orders o ON c.id = o.customer_id GROUP BY c.id ORDER BY total DESC LIMIT 10"
      }
    ]
  }'
```

**Why train?**
- Better SQL accuracy
- Learns business terminology
- Understands complex queries
- Improves over time

---

## 💬 Step 5: Embed Chat Widget

### Option A: Simple Embed (2 Lines of Code)

Client adds to their website:

```html
<!DOCTYPE html>
<html>
<head>
  <title>Client's Website</title>
</head>
<body>
  <h1>Welcome to Our Store</h1>
  <p>Your content here...</p>

  <!-- Add Chat Widget -->
  <script src="https://your-domain.com/chat-widget.js"></script>
  <script>
    AIChatWidget.init({
      apiUrl: 'https://your-api-domain.com',
      apiKey: 'sk_live_xxxxx',  // Client's API key
      clientId: 'client-uuid',    // Client's ID
      companyName: 'Client Company Name'
    });
  </script>
</body>
</html>
```

### Option B: Advanced Embed (With Authentication Update)

For the **advanced chat interface** with visualizations:

```html
<!DOCTYPE html>
<html>
<head>
  <title>Client Dashboard</title>
  <script src="https://cdn.plot.ly/plotly-2.27.0.min.js"></script>
</head>
<body>
  <!-- Client's content -->
  <div id="client-content">
    <h1>Dashboard</h1>
  </div>

  <!-- Embed advanced chat -->
  <iframe
    src="https://your-domain.com/chat_interface_advanced.html?apiKey=sk_live_xxxxx"
    width="100%"
    height="800px"
    frameborder="0"
  ></iframe>
</body>
</html>
```

### Option C: Advanced Interface with API Key (✅ IMPLEMENTED)

The advanced interface now supports API key authentication via URL parameters:

```html
<!-- Embed with authentication -->
<iframe
    src="https://your-domain.com/chat_interface_advanced.html?apiKey=sk_live_xxxxx&clientId=uuid-here"
    width="100%"
    height="800px"
    frameborder="0"
></iframe>
```

**See [embed_advanced_example.html](web/embed_advanced_example.html) for a complete working example.**

**Key Features:**
- ✅ API key passed via URL parameters
- ✅ Automatic authentication header injection
- ✅ Data visualizations with Plotly
- ✅ Multiple chart types (bar, line, pie, scatter, area, table)
- ✅ Voice calling integration
- ✅ SQL query display

---

## 🔌 Step 6: API Integration from Client Website

### JavaScript Integration

```javascript
// Client's frontend code
class ChatAgentClient {
  constructor(apiKey, apiUrl) {
    this.apiKey = apiKey;
    this.apiUrl = apiUrl;
  }

  async query(question) {
    const response = await fetch(`${this.apiUrl}/chat`, {
      method: 'POST',
      headers: {
        'X-API-Key': this.apiKey,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        message: question,
        check_sql: true
      })
    });

    return response.json();
  }

  async train(examples) {
    const response = await fetch(`${this.apiUrl}/train`, {
      method: 'POST',
      headers: {
        'X-API-Key': this.apiKey,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ examples })
    });

    return response.json();
  }
}

// Usage
const chatAgent = new ChatAgentClient('sk_live_xxxxx', 'https://your-api.com');

// Query data
const result = await chatAgent.query('How many customers joined this month?');
console.log(result);

// Train with examples
await chatAgent.train([
  { question: 'Show sales', sql: 'SELECT * FROM sales' }
]);
```

### Python Integration (Client Backend)

```python
import requests

class ChatAgentClient:
    def __init__(self, api_key: str, api_url: str):
        self.api_key = api_key
        self.api_url = api_url
        self.headers = {
            'X-API-Key': api_key,
            'Content-Type': 'application/json'
        }

    def query(self, question: str):
        response = requests.post(
            f'{self.api_url}/chat',
            headers=self.headers,
            json={'message': question, 'check_sql': True}
        )
        return response.json()

    def train(self, examples: list):
        response = requests.post(
            f'{self.api_url}/train',
            headers=self.headers,
            json={'examples': examples}
        )
        return response.json()

# Usage
client = ChatAgentClient('sk_live_xxxxx', 'https://your-api.com')

# Query
result = client.query('How many orders today?')
print(result)
```

---

## 📖 Complete Client Onboarding Flow

### For You (Service Provider)

```powershell
# 1. Create client
$response = Invoke-RestMethod -Uri http://localhost:8000/clients `
  -Method Post -Headers @{"Content-Type"="application/json"} `
  -Body '{"name":"ABC Corp","contact_email":"admin@abc.com","industry":"retail"}'

$clientId = $response.id
$apiKey = $response.api_key
$schema = $response.schema_name

# 2. Send credentials to client
Write-Host "Client Credentials:"
Write-Host "API Key: $apiKey"
Write-Host "Client ID: $clientId"
Write-Host "Schema: $schema"
```

### For Client

**Step 1: Receive Credentials**
```
API Key: sk_live_xxxxx
Client ID: uuid
Schema: client_xxxxx
```

**Step 2: Create Tables**
```sql
-- Connect to Turso database
CREATE TABLE client_xxxxx.products (...);
CREATE TABLE client_xxxxx.orders (...);
-- Insert data
```

**Step 3: Refresh Schema**
```bash
curl -X POST https://your-api.com/refresh-schema \
  -H "X-API-Key: sk_live_xxxxx"
```

**Step 4: Train AI**
```bash
curl -X POST https://your-api.com/train \
  -H "X-API-Key: sk_live_xxxxx" \
  -H "Content-Type: application/json" \
  -d '{"examples":[...]}'
```

**Step 5: Embed Widget**
```html
<script src="chat-widget.js"></script>
<script>
  AIChatWidget.init({
    apiUrl: 'https://your-api.com',
    apiKey: 'sk_live_xxxxx',
    clientId: 'uuid'
  });
</script>
```

---

## 🔐 Security Best Practices

### For Clients

1. **API Key Protection**
   ```javascript
   // ❌ BAD - Exposing API key in frontend
   const apiKey = 'sk_live_xxxxx';

   // ✅ GOOD - Proxy through backend
   // Frontend calls your backend
   fetch('/api/chat-proxy', {
     body: JSON.stringify({ message: 'query' })
   });

   // Your backend proxies to chat agent
   app.post('/api/chat-proxy', async (req, res) => {
     const result = await fetch('https://your-api.com/chat', {
       headers: { 'X-API-Key': process.env.CHAT_AGENT_API_KEY }
     });
     res.json(result);
   });
   ```

2. **Rate Limiting**
   - Already configured: 100 queries/minute per client
   - 10,000 embeddings/day per client

3. **Data Isolation**
   - Each client has isolated schema
   - No cross-client data access
   - Separate vector namespace

---

## 📊 Example Use Cases

### E-Commerce Client

**Data Structure**:
```sql
CREATE TABLE client_ecom123.products (
  id INTEGER PRIMARY KEY,
  name TEXT,
  price REAL,
  stock INTEGER,
  category TEXT
);

CREATE TABLE client_ecom123.orders (
  id INTEGER PRIMARY KEY,
  customer_name TEXT,
  total_amount REAL,
  status TEXT,
  order_date TEXT
);
```

**Training Examples**:
```json
{
  "examples": [
    {
      "question": "Show low stock products",
      "sql": "SELECT * FROM products WHERE stock < 10"
    },
    {
      "question": "Today's sales",
      "sql": "SELECT SUM(total_amount) FROM orders WHERE order_date = date('now')"
    }
  ]
}
```

### SaaS Client

**Data Structure**:
```sql
CREATE TABLE client_saas456.users (
  id INTEGER PRIMARY KEY,
  email TEXT,
  plan TEXT,
  signup_date TEXT
);

CREATE TABLE client_saas456.usage (
  user_id INTEGER,
  feature TEXT,
  usage_count INTEGER,
  date TEXT
);
```

**Training Examples**:
```json
{
  "examples": [
    {
      "question": "Active premium users",
      "sql": "SELECT COUNT(*) FROM users WHERE plan = 'premium'"
    },
    {
      "question": "Top feature usage this week",
      "sql": "SELECT feature, SUM(usage_count) as total FROM usage WHERE date >= date('now', '-7 days') GROUP BY feature ORDER BY total DESC"
    }
  ]
}
```

---

## 🎯 Summary

### Client Integration Checklist

- [ ] Receive API key and client ID
- [ ] Create tables in assigned schema (client_xxxxx)
- [ ] Insert/sync data to tables
- [ ] Refresh schema via API
- [ ] Train with example questions
- [ ] Embed chat widget on website
- [ ] Test queries
- [ ] Monitor usage

### What Clients Can Query

- ✅ Count records
- ✅ Filter data
- ✅ Aggregate (SUM, AVG, COUNT)
- ✅ Join multiple tables
- ✅ Group by dimensions
- ✅ Time-based analysis
- ✅ Complex business queries

### Supported Features

- ✅ Natural language to SQL
- ✅ Data visualization (charts)
- ✅ Real-time queries
- ✅ RAG-powered accuracy
- ✅ Mobile responsive
- ✅ Embeddable widget
- ✅ API integration

---

**Your clients can now integrate their data and start querying immediately!** 🚀
