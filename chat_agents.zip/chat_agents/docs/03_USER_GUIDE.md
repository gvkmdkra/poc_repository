# Complete Guide - Running & Testing Your Chat Agent

Everything you need to know to run, test, and use your Enterprise Multi-Tenant Chat Agent.

---

## 🎯 Quick Start - 3 Steps

### Step 1: Start the Server (30 seconds)

Open PowerShell:
```powershell
cd c:\Users\Mani_Moon\reapdat\code_integration\reusable_agents\chat_agents
python run.py
```

**Expected Output**:
```
======================================================================
Starting Reusable Chat Agent Server
======================================================================
Server running on http://localhost:8000
```

### Step 2: Test the Server (10 seconds)

```powershell
.\test_simple.ps1
```

**You'll see**:
```
Test 1: Health Check ✓
Test 2: Get Demo Client Details ✓
Test 3: RAG Statistics ✓
All tests passed!
```

### Step 3: Use the Chat Widget (Right Now!)

Open in your browser:
```
c:\Users\Mani_Moon\reapdat\code_integration\reusable_agents\chat_agents\web\chat_widget.html
```

Click the purple chat button → Start chatting!

---

## 📊 What You Have

### 1. Enterprise API Server
- **URL**: http://localhost:8000
- **Status**: ✅ Running
- **Docs**: http://localhost:8000/docs

### 2. Demo Client
- **Name**: Demo Company
- **API Key**: `sk_live_5eba7c2f74be13485739063a59015bb5c6aa8021d22da4528a491b9a07f7d3a3`
- **Status**: ✅ Active & Tested

### 3. Chat Widget
- **Standalone**: [web/chat_widget.html](web/chat_widget.html)
- **Embeddable**: [web/chat-widget.js](web/chat-widget.js)
- **Example**: [web/embed_example.html](web/embed_example.html)

---

## 🚀 How to Run on Your Machine

### Method 1: Using PowerShell (Recommended)

```powershell
# 1. Navigate to project
cd c:\Users\Mani_Moon\reapdat\code_integration\reusable_agents\chat_agents

# 2. Start server
python run.py

# 3. In another PowerShell window, test it
.\test_simple.ps1
```

### Method 2: Using Windows Terminal

1. Press `Windows key`
2. Type "PowerShell"
3. Press Enter
4. Run:
   ```powershell
   cd c:\Users\Mani_Moon\reapdat\code_integration\reusable_agents\chat_agents
   python run.py
   ```

### Method 3: Using File Explorer

1. Open File Explorer
2. Navigate to: `c:\Users\Mani_Moon\reapdat\code_integration\reusable_agents\chat_agents`
3. In the address bar, type `cmd` and press Enter
4. Type: `python run.py`

---

## 💬 How to Test the Chat Widget

### Option 1: Standalone Demo (Easiest)

1. **Open File Explorer**
2. Navigate to: `c:\Users\Mani_Moon\reapdat\code_integration\reusable_agents\chat_agents\web`
3. **Double-click**: `chat_widget.html`
4. **Click** the purple chat button (bottom-right)
5. **Type** a message: "Show me my database tables"
6. **Watch** the AI respond!

### Option 2: Browser Direct

1. **Open your browser** (Chrome, Edge, Firefox)
2. **Press**: `Ctrl + O` (or File → Open File)
3. **Navigate** to: `c:\Users\Mani_Moon\reapdat\code_integration\reusable_agents\chat_agents\web`
4. **Select**: `chat_widget.html`
5. **Click** Open

### Option 3: Drag & Drop

1. **Open** your browser
2. **Open** File Explorer
3. **Navigate** to the `web` folder
4. **Drag** `chat_widget.html` into your browser window

---

## 🧪 Testing Options

### Quick Test (30 seconds)
```powershell
.\test_simple.ps1
```
Tests: Health check, client details, RAG stats

### Full Test (2 minutes)
```powershell
.\test_local.ps1
```
Tests: All endpoints, authentication, training, etc.

### Interactive API Test
Open browser: http://localhost:8000/docs
- Click any endpoint
- Click "Try it out"
- Click "Execute"
- See results!

### Chat Widget Test
Open: `web\chat_widget.html`
- Click chat button
- Type messages
- See AI responses
- Test quick actions

---

## 🎨 Using the Chat Widget

### Standalone Page
**File**: `web/chat_widget.html`

**How to use**:
1. Double-click the file
2. Opens in your browser
3. Click the chat button
4. Start chatting!

**Features**:
- Beautiful gradient design
- Feature showcase
- Fully functional chat
- Mobile responsive

### Embed in Any Website
**File**: `web/chat-widget.js`

**Add 2 lines to your HTML**:
```html
<script src="chat-widget.js"></script>
<script>
  AIChatWidget.init({
    apiUrl: 'http://localhost:8000',
    apiKey: 'sk_live_5eba7c2f74be13485739063a59015bb5c6aa8021d22da4528a491b9a07f7d3a3',
    clientId: '358c1b8d-8b30-4218-8c88-d70c5a1fb788'
  });
</script>
```

**That's it!** The widget appears automatically on your website.

### Customization
```javascript
AIChatWidget.init({
  // Required
  apiUrl: 'http://localhost:8000',
  apiKey: 'your-key',
  clientId: 'your-id',

  // Optional - Customize appearance
  primaryColor: '#667eea',           // Your brand color
  secondaryColor: '#764ba2',         // Gradient color
  position: 'bottom-right',          // or 'bottom-left'
  companyName: 'Your Company',       // Chat header name
  welcomeMessage: 'Hello! ...',      // First message

  // Optional - Quick actions
  quickActions: [
    { label: '📊 Sales', message: 'Show total sales' },
    { label: '👥 Users', message: 'How many users?' }
  ]
});
```

---

## 📖 Documentation Files

### Getting Started
1. **[HOWTO_TEST.md](HOWTO_TEST.md)** - Quick testing guide
2. **[LOCAL_TESTING_GUIDE.md](LOCAL_TESTING_GUIDE.md)** - Comprehensive testing
3. **[CHAT_WIDGET_GUIDE.md](CHAT_WIDGET_GUIDE.md)** - Chat widget usage

### Reference
4. **[DEMO_GUIDE.md](DEMO_GUIDE.md)** - Demo client guide
5. **[SYSTEM_READY.md](SYSTEM_READY.md)** - System status
6. **[DEMO_TEST_RESULTS.md](DEMO_TEST_RESULTS.md)** - Test results

### Technical
7. **[README.md](README.md)** - Complete technical docs
8. **[GETTING_STARTED.md](GETTING_STARTED.md)** - Setup guide

---

## 🎯 Common Tasks

### Start the Server
```powershell
cd c:\Users\Mani_Moon\reapdat\code_integration\reusable_agents\chat_agents
python run.py
```

### Stop the Server
Press `Ctrl + C` in the PowerShell window

### Test Everything
```powershell
.\test_simple.ps1
```

### View API Documentation
Open browser: http://localhost:8000/docs

### Check Server Health
```powershell
Invoke-RestMethod -Uri "http://localhost:8000/health"
```

### View Server Logs
Look at the PowerShell window where `python run.py` is running

### Create New Client
Open: http://localhost:8000/docs
- Find `POST /clients`
- Click "Try it out"
- Fill in details
- Click "Execute"

---

## 💡 What You Can Do

### With the API Server
- ✅ Create unlimited clients
- ✅ Generate SQL from natural language
- ✅ Query databases
- ✅ Train with examples
- ✅ Send SMS/Voice/WhatsApp
- ✅ Manage multiple tenants

### With the Chat Widget
- ✅ Add to any website
- ✅ Customize colors and branding
- ✅ Chat with AI in real-time
- ✅ Get database insights
- ✅ Generate SQL queries
- ✅ Use on mobile devices

### With Your Clients
- ✅ Give each client unique API key
- ✅ Complete data isolation
- ✅ Custom configurations per client
- ✅ Track usage and queries
- ✅ White-label solution

---

## 🔍 Troubleshooting

### Server Won't Start

**Problem**: Port 8000 already in use

**Solution**:
```powershell
# Find what's using port 8000
netstat -ano | findstr :8000

# Kill the process (replace PID with the actual process ID)
taskkill /PID <PID> /F

# Start server again
python run.py
```

### Chat Widget Not Working

**Problem**: Can't connect to server

**Check**:
1. Server is running: `http://localhost:8000/health`
2. No errors in browser console (F12)
3. API key is correct

**Solution**:
```javascript
// Check server connection
fetch('http://localhost:8000/health')
  .then(r => r.json())
  .then(d => console.log('Server OK:', d))
  .catch(e => console.error('Server not running:', e));
```

### PowerShell Script Won't Run

**Problem**: Execution policy blocks scripts

**Solution**:
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

---

## 🎓 Tutorials

### Tutorial 1: Basic Testing

```powershell
# 1. Start server
python run.py

# 2. Open new PowerShell window

# 3. Test health
Invoke-RestMethod http://localhost:8000/health

# 4. Test demo client
$headers = @{"X-API-Key" = "sk_live_5eba7c2f74be13485739063a59015bb5c6aa8021d22da4528a491b9a07f7d3a3"}
Invoke-RestMethod -Uri http://localhost:8000/clients/358c1b8d-8b30-4218-8c88-d70c5a1fb788 -Headers $headers
```

### Tutorial 2: Using the Chat Widget

```
1. Make sure server is running (python run.py)
2. Open: web\chat_widget.html
3. Click the purple chat button
4. Type: "What can you help me with?"
5. Press Enter
6. See AI response!
```

### Tutorial 3: Embedding the Widget

```html
<!-- Your website -->
<!DOCTYPE html>
<html>
<head>
  <title>My Website</title>
</head>
<body>
  <h1>Welcome!</h1>
  <p>Your content here...</p>

  <!-- Add these 2 lines -->
  <script src="chat-widget.js"></script>
  <script>
    AIChatWidget.init({
      apiUrl: 'http://localhost:8000',
      apiKey: 'your-demo-client-key',
      clientId: 'your-demo-client-id',
      companyName: 'My Company'
    });
  </script>
</body>
</html>
```

---

## 📞 Quick Reference Card

### Server
```
URL:        http://localhost:8000
Docs:       http://localhost:8000/docs
Health:     http://localhost:8000/health
```

### Demo Client
```
API Key:    sk_live_5eba7c2f74be13485739063a59015bb5c6aa8021d22da4528a491b9a07f7d3a3
Client ID:  358c1b8d-8b30-4218-8c88-d70c5a1fb788
```

### Files
```
Chat Widget:    web\chat_widget.html
Embed Script:   web\chat-widget.js
Test Script:    test_simple.ps1
```

### Commands
```powershell
# Start
python run.py

# Test
.\test_simple.ps1

# Stop
Ctrl + C
```

---

## 🎉 Success Checklist

After following this guide, you should have:

- [ ] ✅ Server running on http://localhost:8000
- [ ] ✅ Tests passing (test_simple.ps1)
- [ ] ✅ Chat widget working (web/chat_widget.html)
- [ ] ✅ API docs accessible (http://localhost:8000/docs)
- [ ] ✅ Demo client active and tested
- [ ] ✅ Understanding of how to embed widget
- [ ] ✅ Ability to create new clients
- [ ] ✅ Knowledge of customization options

**If all checked**: You're ready to use and deploy your chat agent! 🚀

---

## 🆘 Need Help?

1. Check the troubleshooting section above
2. Review the error messages in PowerShell
3. Test with `test_simple.ps1`
4. Check browser console (F12) for errors
5. Verify server is running with health check

---

## 🎊 You're All Set!

You now have a **fully functional enterprise-grade chat agent** with:

- ✅ OpenAI GPT-4 powered AI
- ✅ Multi-tenant architecture
- ✅ RAG pipeline with Pinecone
- ✅ Beautiful chat widget
- ✅ Easy embedding (2 lines of code)
- ✅ Complete customization
- ✅ Production-ready code

**Start using it now**:
1. Run: `python run.py`
2. Open: `web\chat_widget.html`
3. Chat with your AI!

Enjoy! 🚀
