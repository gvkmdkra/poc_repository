# Chat Widget Integration Guide

Complete guide to using the AI Chat Widget with your Enterprise Multi-Tenant Chat Agent.

---

## 🎯 What You Get

### 3 Ready-to-Use Options

1. **[chat_widget.html](web/chat_widget.html)** - Standalone demo page with widget
2. **[chat-widget.js](web/chat-widget.js)** - Embeddable widget for any website
3. **[embed_example.html](web/embed_example.html)** - Example of embedding the widget

---

## 🚀 Quick Start (30 Seconds)

### Option 1: Test the Standalone Demo

1. Make sure your server is running:
   ```powershell
   cd c:\Users\Mani_Moon\reapdat\code_integration\reusable_agents\chat_agents
   python run.py
   ```

2. Open in your browser:
   ```
   c:\Users\Mani_Moon\reapdat\code_integration\reusable_agents\chat_agents\web\chat_widget.html
   ```

3. Click the purple chat button in the bottom-right corner!

### Option 2: Embed in Your Website

Add these 2 lines before `</body>`:

```html
<script src="chat-widget.js"></script>
<script>
  AIChatWidget.init({
    apiUrl: 'http://localhost:8000',
    apiKey: 'sk_live_5eba7c2f74be13485739063a59015bb5c6aa8021d22da4528a491b9a07f7d3a3',
    clientId: '358c1b8d-8b30-4218-8c88-d70c5a1fb788'
  });
</script>
```

That's it! The widget appears automatically.

---

## 📖 How to Run Locally

### Step 1: Start Your Server

```powershell
# Navigate to your project
cd c:\Users\Mani_Moon\reapdat\code_integration\reusable_agents\chat_agents

# Start the server
python run.py
```

**Server will start on**: http://localhost:8000

### Step 2: Open the Widget

**Method 1: Double-click the HTML file**
```
web\chat_widget.html
```

**Method 2: Use File Explorer**
1. Navigate to: `c:\Users\Mani_Moon\reapdat\code_integration\reusable_agents\chat_agents\web`
2. Double-click `chat_widget.html`
3. Your browser opens automatically

**Method 3: From Browser**
- Open your browser
- Press `Ctrl + O` (File → Open)
- Navigate to the `web` folder
- Select `chat_widget.html`

### Step 3: Test the Chat

1. Click the purple chat button (bottom-right)
2. Type a message like "Show me my database tables"
3. Press Enter or click the send button
4. Watch the AI respond!

---

## 💡 Features

### Beautiful UI
- Smooth animations
- Typing indicators
- Message timestamps
- Avatar icons
- Gradient colors

### Smart Functionality
- Real-time chat with AI
- SQL query generation
- Database insights
- Quick action buttons
- Notification badges

### Fully Customizable
- Colors (primary, secondary)
- Position (left/right)
- Company name
- Welcome message
- Quick actions
- Placeholder text

---

## 🎨 Customization

### Basic Configuration

```javascript
AIChatWidget.init({
  // Required
  apiUrl: 'http://localhost:8000',          // Your API server
  apiKey: 'your-api-key-here',              // Your client API key
  clientId: 'your-client-id',               // Your client ID

  // Optional
  position: 'bottom-right',                 // 'bottom-left' or 'bottom-right'
  primaryColor: '#667eea',                  // Main widget color
  secondaryColor: '#764ba2',                // Gradient second color
  companyName: 'Your Company',              // Chat header name
  welcomeMessage: 'How can I help?',        // First message
  placeholder: 'Type your message...',      // Input placeholder

  // Quick actions (optional)
  quickActions: [
    {
      label: '📊 Tables',
      message: 'Show my database tables'
    },
    {
      label: '👥 Customers',
      message: 'How many customers?'
    },
    {
      label: '💰 Revenue',
      message: 'What is my total revenue?'
    }
  ]
});
```

### Color Schemes

```javascript
// Blue Theme
primaryColor: '#3b82f6'
secondaryColor: '#1d4ed8'

// Green Theme
primaryColor: '#10b981'
secondaryColor: '#059669'

// Purple Theme (default)
primaryColor: '#667eea'
secondaryColor: '#764ba2'

// Red Theme
primaryColor: '#ef4444'
secondaryColor: '#dc2626'

// Custom Brand Colors
primaryColor: '#yourcolor'
secondaryColor: '#yourcolor2'
```

---

## 📱 Responsive Design

The widget automatically adapts to:
- **Desktop**: Fixed 380px width
- **Tablet**: Responsive sizing
- **Mobile**: Full-screen chat (minus 40px margins)

Works perfectly on all devices!

---

## 🔧 Integration Examples

### Example 1: WordPress Site

Add to your theme's `footer.php`:

```php
<!-- AI Chat Widget -->
<script src="<?php echo get_template_directory_uri(); ?>/js/chat-widget.js"></script>
<script>
  AIChatWidget.init({
    apiUrl: 'https://your-api.com',
    apiKey: '<?php echo get_option('ai_chat_api_key'); ?>',
    clientId: '<?php echo get_option('ai_chat_client_id'); ?>',
    companyName: '<?php bloginfo('name'); ?>'
  });
</script>
```

### Example 2: React App

```jsx
import { useEffect } from 'react';

function App() {
  useEffect(() => {
    // Load widget script
    const script = document.createElement('script');
    script.src = '/chat-widget.js';
    script.onload = () => {
      window.AIChatWidget.init({
        apiUrl: process.env.REACT_APP_API_URL,
        apiKey: process.env.REACT_APP_API_KEY,
        clientId: process.env.REACT_APP_CLIENT_ID,
        companyName: 'My Company'
      });
    };
    document.body.appendChild(script);

    return () => document.body.removeChild(script);
  }, []);

  return <div>Your App Content</div>;
}
```

### Example 3: Static HTML Site

```html
<!DOCTYPE html>
<html>
<head>
  <title>My Website</title>
</head>
<body>
  <h1>Welcome to My Website</h1>
  <p>Your content here...</p>

  <!-- AI Chat Widget -->
  <script src="/js/chat-widget.js"></script>
  <script>
    AIChatWidget.init({
      apiUrl: 'http://localhost:8000',
      apiKey: 'your-api-key',
      clientId: 'your-client-id'
    });
  </script>
</body>
</html>
```

---

## 🎯 Real-World Use Cases

### E-Commerce Website
```javascript
quickActions: [
  { label: '🛍️ Orders', message: 'Show my recent orders' },
  { label: '📦 Inventory', message: 'Check inventory levels' },
  { label: '💰 Sales', message: 'What are my total sales?' }
]
```

### SaaS Dashboard
```javascript
quickActions: [
  { label: '📊 Metrics', message: 'Show key metrics' },
  { label: '👥 Users', message: 'How many active users?' },
  { label: '🔔 Alerts', message: 'Any system alerts?' }
]
```

### Support Portal
```javascript
quickActions: [
  { label: '🎫 Tickets', message: 'Show open tickets' },
  { label: '❓ FAQ', message: 'Common questions' },
  { label: '📞 Contact', message: 'How to reach support?' }
]
```

---

## 🐛 Troubleshooting

### Widget Not Appearing

**Check:**
1. Server is running on http://localhost:8000
2. JavaScript file is loaded (check browser console)
3. No JavaScript errors (F12 → Console)

**Solution:**
```javascript
// Add error handler
window.addEventListener('error', (e) => {
  console.error('Error loading widget:', e);
});
```

### API Connection Failed

**Check:**
1. API URL is correct
2. Server is accessible
3. CORS is enabled (already done in your API)

**Test:**
```javascript
fetch('http://localhost:8000/health')
  .then(r => r.json())
  .then(d => console.log('Server OK:', d))
  .catch(e => console.error('Server error:', e));
```

### Chat Not Sending Messages

**Check:**
1. API key is correct
2. Client ID is valid
3. Network tab shows API calls (F12 → Network)

**Debug:**
```javascript
// Enable verbose logging
AIChatWidget.debug = true;
```

---

## 📊 Analytics Integration

Track widget usage:

```javascript
AIChatWidget.init({
  apiUrl: 'http://localhost:8000',
  apiKey: 'your-key',
  clientId: 'your-id',

  // Add analytics
  onOpen: () => {
    gtag('event', 'chat_opened');
  },
  onMessage: (message) => {
    gtag('event', 'chat_message_sent', {
      message_length: message.length
    });
  },
  onResponse: (response) => {
    gtag('event', 'chat_response_received');
  }
});
```

---

## 🔒 Security Notes

### Production Deployment

1. **Use HTTPS**:
   ```javascript
   apiUrl: 'https://your-api.com'
   ```

2. **Secure API Keys**:
   - Store in environment variables
   - Never commit to git
   - Rotate regularly

3. **Rate Limiting**:
   - Already implemented in your API
   - 100 queries/minute per client

4. **CORS Configuration**:
   - Already configured in your API
   - Adjust for production domains

---

## 📦 Files Created

### In `web/` folder:

1. **chat_widget.html** (Main Demo)
   - Full standalone demo page
   - Beautiful gradient design
   - Feature showcase
   - Ready to use immediately

2. **chat-widget.js** (Embeddable Widget)
   - Self-contained JavaScript
   - Zero dependencies
   - Fully customizable
   - Production-ready

3. **embed_example.html** (Integration Example)
   - Shows how to embed widget
   - Code examples
   - Customization options

---

## 🎓 Next Steps

### For Development
1. Test the widget: Open `web/chat_widget.html`
2. Customize colors and messages
3. Add your branding
4. Test on different devices

### For Production
1. Host `chat-widget.js` on your CDN
2. Update `apiUrl` to production server
3. Configure SSL/HTTPS
4. Add analytics tracking
5. Test thoroughly

### For Your Clients
1. Give them the embed code
2. Provide their unique API key
3. Show them customization options
4. Help with integration

---

## 💪 What You Can Do Now

1. **Test Locally**: Open `web/chat_widget.html` in your browser
2. **Embed Anywhere**: Add 2 lines of code to any website
3. **Customize**: Change colors, messages, position
4. **Deploy**: Use on unlimited websites
5. **Scale**: Support multiple clients with different keys

---

## 📞 Quick Reference

### Your Demo Client

```
API URL:    http://localhost:8000
API Key:    sk_live_5eba7c2f74be13485739063a59015bb5c6aa8021d22da4528a491b9a07f7d3a3
Client ID:  358c1b8d-8b30-4218-8c88-d70c5a1fb788
```

### File Locations

```
web/
├── chat_widget.html       ← Open this to test
├── chat-widget.js         ← Embed this in websites
└── embed_example.html     ← See integration example
```

### Test URLs

- Demo: `web/chat_widget.html`
- Embed Example: `web/embed_example.html`
- Server: http://localhost:8000
- API Docs: http://localhost:8000/docs

---

## 🎉 Success!

You now have:
- ✅ Beautiful chat widget
- ✅ Easy embedding (2 lines of code)
- ✅ Full customization
- ✅ Production-ready code
- ✅ Mobile responsive
- ✅ Real-time AI chat

**Open `web/chat_widget.html` and start chatting!** 🚀
