# Local Testing Guide - Enterprise Multi-Tenant Chat Agent

**Your Machine**: Windows
**Server Status**: ✅ Running on http://localhost:8000
**Demo Client**: ✅ Active and ready to test

---

## 🎯 Quick Start - Test in 5 Minutes

### Method 1: Using Web Browser (Easiest)

**Step 1**: Open your web browser and go to:
```
http://localhost:8000/docs
```

**Step 2**: You'll see the interactive Swagger UI with all API endpoints

**Step 3**: Click on any endpoint (e.g., `GET /health`) → Click "Try it out" → Click "Execute"

**Step 4**: For authenticated endpoints:
- Click the "Authorize" button at the top right
- Enter your API key: `sk_live_5eba7c2f74be13485739063a59015bb5c6aa8021d22da4528a491b9a07f7d3a3`
- Click "Authorize"
- Now you can test all protected endpoints!

---

### Method 2: Using PowerShell (Recommended for Windows)

**Step 1**: Open PowerShell (Windows key + X → Windows PowerShell)

**Step 2**: Copy and paste these commands one by one:

#### Test 1: Health Check (No authentication needed)
```powershell
Invoke-RestMethod -Uri "http://localhost:8000/health" -Method Get | ConvertTo-Json -Depth 10
```

**Expected Result**:
```json
{
  "status": "healthy",
  "services": {
    "client_service": true,
    "db_connector": true,
    "sql_agent": true,
    "rag_pipeline": true,
    "twilio": true
  }
}
```

#### Test 2: Get Demo Client Details (Authenticated)
```powershell
$headers = @{
    "X-API-Key" = "sk_live_5eba7c2f74be13485739063a59015bb5c6aa8021d22da4528a491b9a07f7d3a3"
}
Invoke-RestMethod -Uri "http://localhost:8000/clients/358c1b8d-8b30-4218-8c88-d70c5a1fb788" -Method Get -Headers $headers | ConvertTo-Json -Depth 10
```

**Expected Result**: Full client details with configuration

#### Test 3: Train the Agent with Examples
```powershell
$headers = @{
    "X-API-Key" = "sk_live_5eba7c2f74be13485739063a59015bb5c6aa8021d22da4528a491b9a07f7d3a3"
    "Content-Type" = "application/json"
}
$body = @{
    examples = @(
        @{
            question = "How many customers do we have?"
            sql = "SELECT COUNT(*) as total FROM customers"
        },
        @{
            question = "Show me the latest orders"
            sql = "SELECT * FROM orders ORDER BY created_at DESC LIMIT 10"
        }
    )
} | ConvertTo-Json -Depth 10

Invoke-RestMethod -Uri "http://localhost:8000/train" -Method Post -Headers $headers -Body $body | ConvertTo-Json -Depth 10
```

**Expected Result**:
```json
{
  "success": true,
  "client_name": "Demo Company",
  "examples_trained": 2,
  "total_vectors": 3,
  "message": "Successfully trained 2 examples"
}
```

#### Test 4: Check Training Status
```powershell
$headers = @{
    "X-API-Key" = "sk_live_5eba7c2f74be13485739063a59015bb5c6aa8021d22da4528a491b9a07f7d3a3"
}
Invoke-RestMethod -Uri "http://localhost:8000/training/status" -Method Get -Headers $headers | ConvertTo-Json -Depth 10
```

**Expected Result**:
```json
{
  "client_name": "Demo Company",
  "is_trained": true,
  "total_vectors": 3,
  "namespace": "client-358c1b8d"
}
```

#### Test 5: Get RAG Statistics
```powershell
$headers = @{
    "X-API-Key" = "sk_live_5eba7c2f74be13485739063a59015bb5c6aa8021d22da4528a491b9a07f7d3a3"
}
Invoke-RestMethod -Uri "http://localhost:8000/rag/stats" -Method Get -Headers $headers | ConvertTo-Json -Depth 10
```

**Expected Result**: Statistics about vector store, embeddings, and RAG configuration

---

### Method 3: Using Postman (Good for repeated testing)

**Step 1**: Download Postman from https://www.postman.com/downloads/ (if not installed)

**Step 2**: Create a new request

**Step 3**: Import Collection:
- I'll create a Postman collection file for you below
- In Postman: File → Import → Drag the JSON file

**Step 4**: Set up environment variable:
- Click "Environments" → Create new environment
- Add variable: `api_key` = `sk_live_5eba7c2f74be13485739063a59015bb5c6aa8021d22da4528a491b9a07f7d3a3`
- Add variable: `base_url` = `http://localhost:8000`
- Add variable: `client_id` = `358c1b8d-8b30-4218-8c88-d70c5a1fb788`

**Step 5**: Run the collection and see all tests execute!

---

## 📝 Complete Test Script for PowerShell

Save this as `test_local.ps1` and run it:

```powershell
# ============================================================================
# Enterprise Multi-Tenant Chat Agent - Local Testing Script
# ============================================================================

Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host "Testing Enterprise Multi-Tenant Chat Agent" -ForegroundColor Cyan
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host ""

$baseUrl = "http://localhost:8000"
$apiKey = "sk_live_5eba7c2f74be13485739063a59015bb5c6aa8021d22da4528a491b9a07f7d3a3"
$clientId = "358c1b8d-8b30-4218-8c88-d70c5a1fb788"

$headers = @{
    "X-API-Key" = $apiKey
    "Content-Type" = "application/json"
}

# Test 1: Health Check
Write-Host "Test 1: Health Check" -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$baseUrl/health" -Method Get
    Write-Host "✓ PASSED" -ForegroundColor Green
    $response | ConvertTo-Json -Depth 10
} catch {
    Write-Host "✗ FAILED: $_" -ForegroundColor Red
}
Write-Host ""

# Test 2: Get Client Details
Write-Host "Test 2: Get Client Details (Authenticated)" -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$baseUrl/clients/$clientId" -Method Get -Headers $headers
    Write-Host "✓ PASSED" -ForegroundColor Green
    Write-Host "Client Name: $($response.name)" -ForegroundColor Cyan
    Write-Host "Industry: $($response.industry)" -ForegroundColor Cyan
    Write-Host "Status: $($response.is_active)" -ForegroundColor Cyan
} catch {
    Write-Host "✗ FAILED: $_" -ForegroundColor Red
}
Write-Host ""

# Test 3: Refresh Schema
Write-Host "Test 3: Refresh Database Schema" -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$baseUrl/refresh-schema" -Method Post -Headers $headers
    Write-Host "✓ PASSED" -ForegroundColor Green
    Write-Host "Table Count: $($response.table_count)" -ForegroundColor Cyan
} catch {
    Write-Host "✗ FAILED: $_" -ForegroundColor Red
}
Write-Host ""

# Test 4: Train with Examples
Write-Host "Test 4: Train with Examples" -ForegroundColor Yellow
try {
    $trainBody = @{
        examples = @(
            @{
                question = "How many total customers?"
                sql = "SELECT COUNT(*) as total_customers FROM customers"
            },
            @{
                question = "Show recent orders"
                sql = "SELECT * FROM orders ORDER BY created_at DESC LIMIT 5"
            },
            @{
                question = "What's the total revenue?"
                sql = "SELECT SUM(amount) as total_revenue FROM orders"
            }
        )
    } | ConvertTo-Json -Depth 10

    $response = Invoke-RestMethod -Uri "$baseUrl/train" -Method Post -Headers $headers -Body $trainBody
    Write-Host "✓ PASSED" -ForegroundColor Green
    Write-Host "Examples Trained: $($response.examples_trained)" -ForegroundColor Cyan
    Write-Host "Total Vectors: $($response.total_vectors)" -ForegroundColor Cyan
} catch {
    Write-Host "✗ FAILED: $_" -ForegroundColor Red
}
Write-Host ""

# Test 5: Check Training Status
Write-Host "Test 5: Check Training Status" -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$baseUrl/training/status" -Method Get -Headers $headers
    Write-Host "✓ PASSED" -ForegroundColor Green
    Write-Host "Is Trained: $($response.is_trained)" -ForegroundColor Cyan
    Write-Host "Total Vectors: $($response.total_vectors)" -ForegroundColor Cyan
    Write-Host "Namespace: $($response.namespace)" -ForegroundColor Cyan
} catch {
    Write-Host "✗ FAILED: $_" -ForegroundColor Red
}
Write-Host ""

# Test 6: Get RAG Statistics
Write-Host "Test 6: Get RAG Statistics" -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$baseUrl/rag/stats" -Method Get -Headers $headers
    Write-Host "✓ PASSED" -ForegroundColor Green
    Write-Host "Index Name: $($response.vector_store.index_name)" -ForegroundColor Cyan
    Write-Host "Total Vectors: $($response.vector_store.total_vectors)" -ForegroundColor Cyan
    Write-Host "Dimension: $($response.vector_store.dimension)" -ForegroundColor Cyan
    Write-Host "Embedding Model: $($response.embedding_model)" -ForegroundColor Cyan
} catch {
    Write-Host "✗ FAILED: $_" -ForegroundColor Red
}
Write-Host ""

# Test 7: List All Clients
Write-Host "Test 7: List All Clients" -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$baseUrl/clients" -Method Get -Headers $headers
    Write-Host "✓ PASSED" -ForegroundColor Green
    Write-Host "Total Clients: $($response.Count)" -ForegroundColor Cyan
    foreach ($client in $response) {
        Write-Host "  - $($client.name) ($($client.industry))" -ForegroundColor Cyan
    }
} catch {
    Write-Host "✗ FAILED: $_" -ForegroundColor Red
}
Write-Host ""

# Test 8: Create New Client
Write-Host "Test 8: Create New Client" -ForegroundColor Yellow
try {
    $newClientBody = @{
        name = "Test Company $(Get-Random -Maximum 1000)"
        contact_email = "test@testcompany.com"
        industry = "technology"
    } | ConvertTo-Json

    $response = Invoke-RestMethod -Uri "$baseUrl/clients" -Method Post -Headers @{"Content-Type" = "application/json"} -Body $newClientBody
    Write-Host "✓ PASSED" -ForegroundColor Green
    Write-Host "New Client ID: $($response.id)" -ForegroundColor Cyan
    Write-Host "New API Key: $($response.api_key)" -ForegroundColor Cyan
    Write-Host "Schema Name: $($response.schema_name)" -ForegroundColor Cyan
} catch {
    Write-Host "✗ FAILED: $_" -ForegroundColor Red
}
Write-Host ""

Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host "Testing Complete!" -ForegroundColor Cyan
Write-Host "======================================================================" -ForegroundColor Cyan
```

**To run this script**:
1. Save the above as `test_local.ps1` in your chat_agents folder
2. Open PowerShell
3. Navigate to the folder: `cd c:\Users\Mani_Moon\reapdat\code_integration\reusable_agents\chat_agents`
4. Run: `.\test_local.ps1`

---

## 🧪 Testing with Your Own Data

### Step 1: Create Tables in Turso

You'll need to create tables in your Turso database for the demo client's schema.

**Option A: Using Turso CLI**
```bash
# Install Turso CLI (if not installed)
# Download from: https://docs.turso.tech/cli/installation

# Connect to your database
turso db shell churnguard-manipyramidions

# Create tables in the client schema
CREATE TABLE client_358c1b8d8b3042188c88d70c5a1fb788.customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT,
    phone TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE client_358c1b8d8b3042188c88d70c5a1fb788.orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER,
    amount REAL,
    status TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id)
);

# Insert sample data
INSERT INTO client_358c1b8d8b3042188c88d70c5a1fb788.customers (name, email, phone)
VALUES ('John Doe', 'john@example.com', '+1234567890');

INSERT INTO client_358c1b8d8b3042188c88d70c5a1fb788.customers (name, email, phone)
VALUES ('Jane Smith', 'jane@example.com', '+0987654321');

INSERT INTO client_358c1b8d8b3042188c88d70c5a1fb788.orders (customer_id, amount, status)
VALUES (1, 99.99, 'completed');

INSERT INTO client_358c1b8d8b3042188c88d70c5a1fb788.orders (customer_id, amount, status)
VALUES (2, 149.99, 'pending');
```

**Option B: Using Turso Dashboard**
1. Go to https://app.turso.tech/
2. Select your database: `churnguard-manipyramidions`
3. Use the SQL editor to run the CREATE and INSERT statements above

### Step 2: Refresh Schema in Your App
```powershell
$headers = @{
    "X-API-Key" = "sk_live_5eba7c2f74be13485739063a59015bb5c6aa8021d22da4528a491b9a07f7d3a3"
}
Invoke-RestMethod -Uri "http://localhost:8000/refresh-schema" -Method Post -Headers $headers | ConvertTo-Json
```

### Step 3: Train with Real Examples
```powershell
$headers = @{
    "X-API-Key" = "sk_live_5eba7c2f74be13485739063a59015bb5c6aa8021d22da4528a491b9a07f7d3a3"
    "Content-Type" = "application/json"
}
$body = @{
    examples = @(
        @{
            question = "How many customers do we have?"
            sql = "SELECT COUNT(*) as total FROM customers"
        },
        @{
            question = "Show all customers"
            sql = "SELECT * FROM customers ORDER BY created_at DESC"
        },
        @{
            question = "What are the total sales?"
            sql = "SELECT SUM(amount) as total_sales FROM orders WHERE status = 'completed'"
        },
        @{
            question = "Show pending orders"
            sql = "SELECT o.*, c.name as customer_name FROM orders o JOIN customers c ON o.customer_id = c.id WHERE o.status = 'pending'"
        }
    )
} | ConvertTo-Json -Depth 10

Invoke-RestMethod -Uri "http://localhost:8000/train" -Method Post -Headers $headers -Body $body
```

### Step 4: Test SQL Generation
```powershell
$headers = @{
    "X-API-Key" = "sk_live_5eba7c2f74be13485739063a59015bb5c6aa8021d22da4528a491b9a07f7d3a3"
    "Content-Type" = "application/json"
}
$body = @{
    message = "Show me all customers"
    check_sql = $true
} | ConvertTo-Json

Invoke-RestMethod -Uri "http://localhost:8000/chat" -Method Post -Headers $headers -Body $body | ConvertTo-Json -Depth 10
```

---

## 🌐 Testing SMS/Voice Features (Optional)

If you have Twilio configured and want to test communication features:

### Send SMS
```powershell
$headers = @{
    "X-API-Key" = "sk_live_5eba7c2f74be13485739063a59015bb5c6aa8021d22da4528a491b9a07f7d3a3"
    "Content-Type" = "application/json"
}
$body = @{
    to = "+1234567890"  # Your phone number
    message = "Test message from Demo Company!"
} | ConvertTo-Json

Invoke-RestMethod -Uri "http://localhost:8000/sms/send" -Method Post -Headers $headers -Body $body
```

### Make Voice Call
```powershell
$headers = @{
    "X-API-Key" = "sk_live_5eba7c2f74be13485739063a59015bb5c6aa8021d22da4528a491b9a07f7d3a3"
    "Content-Type" = "application/json"
}
$body = @{
    to = "+1234567890"  # Your phone number
    message = "Hello! This is a test call from your AI assistant."
} | ConvertTo-Json

Invoke-RestMethod -Uri "http://localhost:8000/call/make" -Method Post -Headers $headers -Body $body
```

---

## 📊 Monitoring Your Tests

### Check Server Logs
The server is running in the background. To see real-time logs, look at the PowerShell window where you started the server.

### Check RAG Pipeline Performance
```powershell
$headers = @{"X-API-Key" = "sk_live_5eba..."}
Invoke-RestMethod -Uri "http://localhost:8000/rag/stats" -Headers $headers | ConvertTo-Json -Depth 10
```

### Check Client Usage
```powershell
$headers = @{"X-API-Key" = "sk_live_5eba..."}
Invoke-RestMethod -Uri "http://localhost:8000/clients/358c1b8d-8b30-4218-8c88-d70c5a1fb788" -Headers $headers | ConvertTo-Json -Depth 10
```

Look for:
- `total_queries`: Number of queries made
- `total_embeddings`: Number of embeddings generated
- `last_query_at`: Timestamp of last query

---

## 🐛 Troubleshooting

### Issue: "Connection refused"
**Solution**: Make sure the server is running
```powershell
# Check if port 8000 is in use
netstat -ano | findstr :8000

# If not running, start the server
cd c:\Users\Mani_Moon\reapdat\code_integration\reusable_agents\chat_agents
python run.py
```

### Issue: "401 Unauthorized"
**Solution**: Check your API key
- Make sure you're using the correct API key
- Check that you're including the `X-API-Key` header
- Verify the client is active

### Issue: "No tables found in schema"
**Solution**: Create tables in Turso first, then refresh schema
```powershell
# After creating tables in Turso
Invoke-RestMethod -Uri "http://localhost:8000/refresh-schema" -Method Post -Headers @{"X-API-Key" = "sk_live_5eba..."}
```

### Issue: PowerShell errors
**Solution**: Make sure execution policy allows scripts
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

---

## ✅ Success Checklist

After running all tests, you should see:

- [ ] ✅ Health check returns status "healthy"
- [ ] ✅ Can retrieve demo client details
- [ ] ✅ Schema refresh works
- [ ] ✅ Training examples store successfully
- [ ] ✅ Training status shows vectors stored
- [ ] ✅ RAG stats show correct vector count
- [ ] ✅ Can create new clients
- [ ] ✅ Can list all clients

**If all checked**: Your system is working perfectly! 🎉

---

## 📞 Quick Reference

### Your Demo Client
```
Client ID:  358c1b8d-8b30-4218-8c88-d70c5a1fb788
API Key:    sk_live_5eba7c2f74be13485739063a59015bb5c6aa8021d22da4528a491b9a07f7d3a3
Schema:     client_358c1b8d8b3042188c88d70c5a1fb788
Namespace:  client-358c1b8d
```

### URLs
```
Server:     http://localhost:8000
API Docs:   http://localhost:8000/docs
Health:     http://localhost:8000/health
```

### Files
- Test Results: [DEMO_TEST_RESULTS.md](DEMO_TEST_RESULTS.md)
- System Status: [SYSTEM_READY.md](SYSTEM_READY.md)
- User Guide: [DEMO_GUIDE.md](DEMO_GUIDE.md)
- Credentials: [DEMO_CLIENT_CREDENTIALS.json](DEMO_CLIENT_CREDENTIALS.json)

---

**Happy Testing!** 🚀
