# Reusable Chat Agent Module

End-to-end chat module with Twilio integration, Vanna AI for SQL queries, Turso DB, and FastAPI support.

## Features

- **Multi-channel Communication**: SMS and WhatsApp via Twilio
- **AI-Powered Responses**: Google Gemini integration
- **Natural Language to SQL**: Vanna AI for database queries
- **Cloud Database**: Turso DB (LibSQL) integration
- **FastAPI REST API**: Ready-to-deploy web service
- **Standalone Usage**: Use as a Python module without FastAPI
- **Conversation History**: Track all interactions
- **Custom Callbacks**: Hook into message processing
- **Training System**: Train the SQL agent with your schema

## Installation

```bash
pip install -r requirements.txt
```

## Configuration

Create a `.env` file with your credentials:

```env
GEMINI_API_KEY=your_gemini_api_key
TWILIO_ACCOUNT_SID=your_twilio_sid
TWILIO_AUTH_TOKEN=your_twilio_token
TWILIO_PHONE_NUMBER=your_twilio_number
TURSO_DB_AUTH_TOKEN=your_turso_token
TURSO_DB_URL=your_turso_db_url
```

## Quick Start

### 1. FastAPI Server

Start the API server:

```bash
python api.py
```

Or with uvicorn:

```bash
uvicorn api:app --reload --host 0.0.0.0 --port 8000
```

### 2. Standalone Usage

```python
import asyncio
from chat_agent import ChatAgent

async def main():
    agent = ChatAgent(enable_sql=True, enable_twilio=True)
    await agent.initialize(train_db=True)

    response = await agent.process_message("How many users do we have?")
    print(response['ai_response'])

    await agent.close()

asyncio.run(main())
```

## API Endpoints

### Chat
```bash
POST /chat
{
  "message": "How many users are in the database?",
  "check_sql": true
}
```

### Send SMS
```bash
POST /sms/send
{
  "to": "+1234567890",
  "message": "Hello from the chat agent!"
}
```

### Send WhatsApp
```bash
POST /whatsapp/send
{
  "to": "+1234567890",
  "message": "Hello via WhatsApp!"
}
```

### Twilio Webhook
```bash
POST /webhook/twilio
```
Configure this endpoint in your Twilio console for incoming messages.

### Conversation History
```bash
GET /history
DELETE /history
```

### Train SQL Agent
```bash
POST /train
{
  "ddl": "CREATE TABLE users (id INTEGER, name TEXT)",
  "question": "How many users?",
  "sql": "SELECT COUNT(*) FROM users"
}
```

### Health Check
```bash
GET /health
```

## Usage Examples

### Example 1: Basic Chat
```python
from chat_agent import ChatAgent

agent = ChatAgent(enable_sql=False, enable_twilio=False)
await agent.initialize()

response = await agent.process_message("Hello!")
print(response['ai_response'])
```

### Example 2: SQL Queries
```python
agent = ChatAgent(enable_sql=True)
await agent.initialize(train_db=True)

# Train with your schema
agent.vanna_agent.train_ddl("""
    CREATE TABLE products (
        id INTEGER PRIMARY KEY,
        name TEXT,
        price REAL
    )
""")

response = await agent.process_message("Show me all products")
print(response['sql_result'])
```

### Example 3: Handle Incoming SMS
```python
agent = ChatAgent(enable_sql=True, enable_twilio=True)
await agent.initialize()

response = await agent.handle_incoming_sms(
    from_number="+1234567890",
    message="What's my account balance?",
    auto_reply=True
)
```

### Example 4: Custom Callbacks
```python
def my_callback(message_data):
    print(f"Message logged: {message_data['user_message']}")

agent.add_message_callback(my_callback)
await agent.process_message("Test")
```

### Example 5: Direct Database Access
```python
from db_connector import TursoDBConnector

async with TursoDBConnector() as db:
    result = await db.fetch_all("SELECT * FROM users")
    print(result)
```

## Module Structure

```
chat_agents/
├── config.py              # Configuration management
├── db_connector.py        # Turso DB connector
├── vanna_integration.py   # Vanna AI SQL agent
├── twilio_handler.py      # Twilio SMS/WhatsApp
├── chat_agent.py          # Main chat agent
├── api.py                 # FastAPI application
├── standalone_usage.py    # Usage examples
├── requirements.txt       # Dependencies
├── .env                   # Environment variables
└── README.md             # This file
```

## Components

### ChatAgent
Main orchestrator that combines all components.

**Methods:**
- `initialize()` - Setup agent and connections
- `process_message()` - Process user messages
- `send_sms_response()` - Send SMS
- `send_whatsapp_response()` - Send WhatsApp
- `handle_incoming_sms()` - Handle incoming SMS
- `handle_incoming_whatsapp()` - Handle incoming WhatsApp
- `add_message_callback()` - Add custom callbacks
- `get_conversation_history()` - Get chat history
- `clear_history()` - Clear history
- `close()` - Cleanup resources

### VannaSQLAgent
Natural language to SQL conversion.

**Methods:**
- `train_ddl()` - Train with DDL statements
- `train_documentation()` - Train with docs
- `train_question_sql()` - Train with Q&A pairs
- `train_from_database()` - Auto-train from schema
- `generate_sql()` - Generate SQL from question
- `ask()` - Execute natural language query

### TwilioHandler
SMS and WhatsApp integration.

**Methods:**
- `send_sms()` - Send SMS
- `send_whatsapp()` - Send WhatsApp
- `create_twiml_response()` - Create TwiML response
- `validate_webhook()` - Validate Twilio signature

### TursoDBConnector
Database operations.

**Methods:**
- `connect()` - Connect to database
- `execute()` - Execute SQL
- `fetch_all()` - Fetch all results
- `fetch_one()` - Fetch single result
- `close()` - Close connection

## Twilio Setup

1. Configure webhook URL in Twilio Console:
   ```
   https://your-domain.com/webhook/twilio
   ```

2. Enable SMS and WhatsApp for your number

3. Set webhook to POST method

## Training the SQL Agent

```python
# Train with table schema
agent.vanna_agent.train_ddl("""
    CREATE TABLE orders (
        id INTEGER PRIMARY KEY,
        customer_id INTEGER,
        total REAL,
        created_at TIMESTAMP
    )
""")

# Train with examples
agent.vanna_agent.train_question_sql(
    "What are today's orders?",
    "SELECT * FROM orders WHERE DATE(created_at) = DATE('now')"
)

# Train with documentation
agent.vanna_agent.train_documentation("""
    The orders table contains all customer orders.
    Use created_at for date filtering.
""")
```

## Error Handling

All methods return structured responses:

```python
{
    "success": True/False,
    "user_message": "original message",
    "ai_response": "AI response text",
    "sql_result": {...},  # If SQL query was executed
    "error": "error message"  # If success is False
}
```

## Production Deployment

1. Set environment variables in production
2. Use proper ASGI server (gunicorn + uvicorn)
3. Enable HTTPS
4. Configure Twilio webhook with your domain
5. Set up database backups
6. Enable logging and monitoring

```bash
gunicorn api:app -w 4 -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000
```

## Testing

```bash
# Test the API
curl -X POST http://localhost:8000/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Hello!"}'

# Test SMS
curl -X POST http://localhost:8000/sms/send \
  -H "Content-Type: application/json" \
  -d '{"to": "+1234567890", "message": "Test"}'
```

## License

MIT License

## Support

For issues and questions, please create an issue in the repository.
