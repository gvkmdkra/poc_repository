# Website Integration Guide

## How to Test and Integrate Chat Agent in Your Website

---

## Option 1: Local Testing with HTML Interface

### 1. Start the Server

```bash
# Navigate to project directory
cd c:\Users\Mani_Moon\reapdat\code_integration\reusable_agents\chat_agents

# Start the FastAPI server
python api.py
```

**Server will run at:** `http://localhost:8000`

### 2. Open the Chat Interface

**Method A: Direct File**
```bash
# Open the HTML file in your browser
start chat_interface.html  # Windows
open chat_interface.html   # Mac
xdg-open chat_interface.html  # Linux
```

**Method B: Via URL** (if serving with a local server)
```
http://localhost:8000/chat_interface.html
```

### 3. Test the Interface

The interface provides:
- ✅ Real-time chat with AI
- ✅ SQL query capabilities
- ✅ Health status indicator
- ✅ Quick action buttons
- ✅ Technical details toggle
- ✅ Responsive design

**Try these test messages:**
1. "Hello!" - Basic conversation
2. "How many users are in the database?" - SQL query
3. "What can you help me with?" - Get capabilities
4. "Tell me a joke" - Fun interaction

---

## Option 2: JavaScript API Integration

### Simple Fetch API Example

```html
<!DOCTYPE html>
<html>
<head>
    <title>Chat Integration</title>
</head>
<body>
    <div id="chat">
        <div id="messages"></div>
        <input type="text" id="input" placeholder="Type message...">
        <button onclick="sendMessage()">Send</button>
    </div>

    <script>
        const API_URL = 'http://localhost:8000';

        async function sendMessage() {
            const input = document.getElementById('input');
            const message = input.value;

            if (!message) return;

            // Display user message
            addMessage(message, 'user');

            // Send to API
            try {
                const response = await fetch(`${API_URL}/chat`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        message: message,
                        check_sql: true
                    })
                });

                const data = await response.json();

                // Display AI response
                addMessage(data.ai_response, 'bot');

                // Clear input
                input.value = '';

            } catch (error) {
                console.error('Error:', error);
                addMessage('Error: Could not connect to server', 'error');
            }
        }

        function addMessage(text, type) {
            const messages = document.getElementById('messages');
            const div = document.createElement('div');
            div.className = type;
            div.textContent = text;
            messages.appendChild(div);
        }
    </script>
</body>
</html>
```

### Axios Example

```html
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script>
    const API_URL = 'http://localhost:8000';

    async function sendMessage() {
        try {
            const response = await axios.post(`${API_URL}/chat`, {
                message: document.getElementById('input').value,
                check_sql: true,
                context: {
                    user_id: 123,
                    session: 'abc'
                }
            });

            console.log(response.data);
            displayResponse(response.data);

        } catch (error) {
            console.error('Error:', error);
        }
    }

    function displayResponse(data) {
        document.getElementById('response').innerHTML = `
            <p><strong>You:</strong> ${data.user_message}</p>
            <p><strong>AI:</strong> ${data.ai_response}</p>
            ${data.sql_result ? `<p><strong>SQL:</strong> ${data.sql_result.sql}</p>` : ''}
        `;
    }
</script>
```

---

## Option 3: React Integration

### React Component Example

```jsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const API_URL = 'http://localhost:8000';

function ChatComponent() {
    const [messages, setMessages] = useState([]);
    const [input, setInput] = useState('');
    const [loading, setLoading] = useState(false);
    const [online, setOnline] = useState(false);

    // Check server health
    useEffect(() => {
        checkHealth();
    }, []);

    const checkHealth = async () => {
        try {
            const response = await axios.get(`${API_URL}/health`);
            setOnline(response.status === 200);
        } catch (error) {
            setOnline(false);
        }
    };

    const sendMessage = async () => {
        if (!input.trim()) return;

        // Add user message
        const userMessage = { text: input, type: 'user' };
        setMessages(prev => [...prev, userMessage]);

        setLoading(true);

        try {
            const response = await axios.post(`${API_URL}/chat`, {
                message: input,
                check_sql: true
            });

            // Add bot response
            const botMessage = {
                text: response.data.ai_response,
                type: 'bot',
                sqlResult: response.data.sql_result
            };

            setMessages(prev => [...prev, botMessage]);
            setInput('');

        } catch (error) {
            console.error('Error:', error);
            const errorMessage = {
                text: 'Error: Could not connect to server',
                type: 'error'
            };
            setMessages(prev => [...prev, errorMessage]);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="chat-container">
            <div className="chat-header">
                <h2>AI Chat Agent</h2>
                <span className={online ? 'online' : 'offline'}>
                    {online ? '● Online' : '● Offline'}
                </span>
            </div>

            <div className="chat-messages">
                {messages.map((msg, index) => (
                    <div key={index} className={`message ${msg.type}`}>
                        <p>{msg.text}</p>
                        {msg.sqlResult && msg.sqlResult.success && (
                            <div className="sql-result">
                                <code>{msg.sqlResult.sql}</code>
                            </div>
                        )}
                    </div>
                ))}
            </div>

            <div className="chat-input">
                <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                    placeholder="Type your message..."
                    disabled={loading}
                />
                <button onClick={sendMessage} disabled={loading}>
                    {loading ? 'Sending...' : 'Send'}
                </button>
            </div>
        </div>
    );
}

export default ChatComponent;
```

---

## Option 4: Vue.js Integration

```vue
<template>
  <div class="chat-container">
    <div class="chat-header">
      <h2>AI Chat Agent</h2>
      <span :class="online ? 'online' : 'offline'">
        {{ online ? '● Online' : '● Offline' }}
      </span>
    </div>

    <div class="chat-messages" ref="messages">
      <div v-for="(msg, index) in messages" :key="index" :class="`message ${msg.type}`">
        <p>{{ msg.text }}</p>
        <div v-if="msg.sqlResult" class="sql-result">
          <code>{{ msg.sqlResult.sql }}</code>
        </div>
      </div>
    </div>

    <div class="chat-input">
      <input
        v-model="input"
        @keyup.enter="sendMessage"
        placeholder="Type your message..."
        :disabled="loading"
      />
      <button @click="sendMessage" :disabled="loading">
        {{ loading ? 'Sending...' : 'Send' }}
      </button>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      API_URL: 'http://localhost:8000',
      messages: [],
      input: '',
      loading: false,
      online: false
    };
  },

  mounted() {
    this.checkHealth();
  },

  methods: {
    async checkHealth() {
      try {
        const response = await axios.get(`${this.API_URL}/health`);
        this.online = response.status === 200;
      } catch (error) {
        this.online = false;
      }
    },

    async sendMessage() {
      if (!this.input.trim()) return;

      this.messages.push({ text: this.input, type: 'user' });
      this.loading = true;

      try {
        const response = await axios.post(`${this.API_URL}/chat`, {
          message: this.input,
          check_sql: true
        });

        this.messages.push({
          text: response.data.ai_response,
          type: 'bot',
          sqlResult: response.data.sql_result
        });

        this.input = '';

      } catch (error) {
        console.error('Error:', error);
        this.messages.push({
          text: 'Error: Could not connect to server',
          type: 'error'
        });
      } finally {
        this.loading = false;
      }
    }
  }
};
</script>
```

---

## Option 5: WordPress Integration

### Using Custom HTML Block

```html
<!-- Add to WordPress page/post as HTML block -->
<div id="chat-widget"></div>

<script>
(function() {
    const API_URL = 'http://localhost:8000';

    // Create chat widget
    const widget = document.getElementById('chat-widget');
    widget.innerHTML = `
        <div style="border: 1px solid #ccc; border-radius: 10px; padding: 20px; max-width: 500px;">
            <h3>Chat with AI</h3>
            <div id="chat-messages" style="height: 300px; overflow-y: auto; border: 1px solid #eee; padding: 10px; margin: 10px 0;"></div>
            <input type="text" id="chat-input" style="width: 70%; padding: 10px;" placeholder="Type message...">
            <button id="chat-send" style="width: 25%; padding: 10px;">Send</button>
        </div>
    `;

    // Send message function
    async function sendMessage() {
        const input = document.getElementById('chat-input');
        const messages = document.getElementById('chat-messages');
        const message = input.value;

        if (!message) return;

        // Add user message
        messages.innerHTML += `<p><strong>You:</strong> ${message}</p>`;

        try {
            const response = await fetch(`${API_URL}/chat`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: message, check_sql: true })
            });

            const data = await response.json();

            // Add bot response
            messages.innerHTML += `<p><strong>AI:</strong> ${data.ai_response}</p>`;
            messages.scrollTop = messages.scrollHeight;

            input.value = '';

        } catch (error) {
            messages.innerHTML += `<p style="color: red;">Error: ${error.message}</p>`;
        }
    }

    // Event listeners
    document.getElementById('chat-send').addEventListener('click', sendMessage);
    document.getElementById('chat-input').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') sendMessage();
    });
})();
</script>
```

---

## CORS Configuration for Production

### Enable CORS in FastAPI

```python
# In api.py, add:
from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",  # React dev server
        "http://localhost:8080",  # Vue dev server
        "https://yourdomain.com", # Production domain
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

---

## Testing Checklist

### 1. Server Health Check

```bash
# Test if server is running
curl http://localhost:8000/health

# Expected response:
# {"status":"healthy","chat_agent":true,"sql_enabled":true,"twilio_enabled":true}
```

### 2. Basic Chat Test

```bash
curl -X POST http://localhost:8000/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Hello!", "check_sql": false}'
```

### 3. SQL Query Test

```bash
curl -X POST http://localhost:8000/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "How many users?", "check_sql": true}'
```

### 4. Browser Console Test

```javascript
// Open browser console (F12) and run:
fetch('http://localhost:8000/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message: 'Hello!', check_sql: false })
})
.then(res => res.json())
.then(data => console.log(data));
```

---

## Deployment for Production Website

### 1. Deploy API Server

```bash
# Using a cloud service (Heroku, Railway, Render, etc.)
# Set environment variables
# Deploy the FastAPI application
```

### 2. Update API URL in Frontend

```javascript
// Change from:
const API_URL = 'http://localhost:8000';

// To your production URL:
const API_URL = 'https://your-api-domain.com';
```

### 3. Enable HTTPS

```bash
# Use Let's Encrypt for free SSL
# Or use cloud provider's SSL certificate
```

---

## Screenshots and Visual Guide

### Chat Interface Preview:

```
┌─────────────────────────────────────────┐
│   🤖 AI Chat Agent                      │
│   ● Online                              │
├─────────────────────────────────────────┤
│                                         │
│  ┌──────────────────────────┐          │
│  │ 👋 Hello! I'm your AI    │          │
│  │ assistant...             │          │
│  └──────────────────────────┘          │
│                                         │
│              ┌──────────────┐           │
│              │ Hello!       │           │
│              └──────────────┘           │
│                                         │
│  ┌──────────────────────────┐          │
│  │ Hi there! How can I      │          │
│  │ help you today?          │          │
│  └──────────────────────────┘          │
│                                         │
├─────────────────────────────────────────┤
│  [👋 Hello] [📊 Count Users] [🗑️ Clear]│
│  ┌────────────────────────┬──────────┐ │
│  │ Type your message...   │   Send   │ │
│  └────────────────────────┴──────────┘ │
│  ☑ Enable SQL queries                  │
└─────────────────────────────────────────┘
```

---

## Common Integration Patterns

### Pattern 1: Chatbot Widget

```html
<!-- Floating chat button -->
<div id="chat-widget" style="position: fixed; bottom: 20px; right: 20px;">
    <button id="chat-toggle" style="width: 60px; height: 60px; border-radius: 50%; background: #667eea; color: white; border: none; cursor: pointer; font-size: 24px;">
        💬
    </button>
    <div id="chat-window" style="display: none; width: 350px; height: 500px; background: white; border-radius: 10px; box-shadow: 0 0 20px rgba(0,0,0,0.2);">
        <!-- Chat interface here -->
    </div>
</div>

<script>
    document.getElementById('chat-toggle').addEventListener('click', () => {
        const window = document.getElementById('chat-window');
        window.style.display = window.style.display === 'none' ? 'block' : 'none';
    });
</script>
```

### Pattern 2: Embedded Chat

```html
<!-- Full-page chat -->
<div style="width: 100%; height: 100vh;">
    <iframe src="chat_interface.html" style="width: 100%; height: 100%; border: none;"></iframe>
</div>
```

### Pattern 3: Modal Chat

```html
<!-- Chat opens in modal/dialog -->
<button onclick="openChatModal()">Chat with AI</button>

<dialog id="chatModal" style="width: 80%; max-width: 600px; height: 80vh;">
    <!-- Chat interface here -->
</dialog>

<script>
    function openChatModal() {
        document.getElementById('chatModal').showModal();
    }
</script>
```

---

## Next Steps

1. ✅ Start the server: `python api.py`
2. ✅ Open `chat_interface.html` in browser
3. ✅ Test with sample messages
4. ✅ Integrate into your website using one of the patterns above
5. ✅ Deploy to production when ready

**Need help?** Check the [DOCUMENTATION.md](DOCUMENTATION.md) for more details!
