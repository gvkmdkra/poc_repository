# 🧪 Testing Instructions - Chat Widgets

## ⚠️ Important: File Protocol Issue

**The issue you encountered** is that opening HTML files directly from the file system (`file://` protocol) causes CORS errors when trying to fetch from `http://localhost:8000`. Browsers block cross-origin requests from `file://` for security reasons.

**Solution**: Use the HTTP server to serve the web files properly.

---

## ✅ Correct Way to Test

### Step 1: Start the API Server (if not already running)

```powershell
cd c:\Users\Mani_Moon\reapdat\code_integration\reusable_agents\chat_agents
python run.py
```

**Expected**: Server running on http://localhost:8000

### Step 2: Start the Web Server

Open a **new PowerShell window**:

```powershell
cd c:\Users\Mani_Moon\reapdat\code_integration\reusable_agents\chat_agents
python serve_web.py
```

**Expected Output**:
```
======================================================================
Starting Web Server for Chat Widgets
======================================================================

Server running on http://localhost:8080

Available pages:
  • Chat Widget:           http://localhost:8080/chat_widget.html
  • Advanced Interface:    http://localhost:8080/chat_interface_advanced.html
  • Embed Example:         http://localhost:8080/embed_example.html
  • Advanced Embed:        http://localhost:8080/embed_advanced_example.html

To stop: Press CTRL+C
======================================================================
```

### Step 3: Open in Browser

Open your browser and navigate to:

**Option A: Simple Chat Widget**
```
http://localhost:8080/chat_widget.html
```

**Option B: Advanced Interface (with authentication)**
```
http://localhost:8080/chat_interface_advanced.html?apiKey=sk_live_5eba7c2f74be13485739063a59015bb5c6aa8021d22da4528a491b9a07f7d3a3&clientId=358c1b8d-8b30-4218-8c88-d70c5a1fb788
```

**Option C: Embed Example**
```
http://localhost:8080/embed_example.html
```

**Option D: Advanced Embed Example**
```
http://localhost:8080/embed_advanced_example.html
```

---

## 🎯 What Should Work Now

### Chat Functionality:
- ✅ Type messages and get AI responses
- ✅ Quick action buttons work
- ✅ SQL queries generated
- ✅ Status indicator shows "Online"
- ✅ API authentication working

### What Won't Work (Expected):
- ❌ **"Call Agent" button** - Requires Twilio phone configuration
  - Error message: "Call failed: Failed to fetch"
  - This is a voice calling feature, not the chat feature
  - Optional feature, not required for chat functionality

---

## 🐛 Troubleshooting

### Problem: Still getting "Failed to fetch" errors

**Check these:**

1. **API Server Running?**
   ```powershell
   curl http://localhost:8000/health
   ```
   Should return: `{"status":"healthy",...}`

2. **Web Server Running?**
   ```powershell
   netstat -ano | findstr :8080
   ```
   Should show: `TCP    0.0.0.0:8080 ... LISTENING`

3. **Using HTTP, not File?**
   - ✅ Correct: `http://localhost:8080/chat_widget.html`
   - ❌ Wrong: `file:///C:/Users/.../chat_widget.html`

### Problem: Port 8080 already in use

**Solution:**
```powershell
# Find what's using port 8080
netstat -ano | findstr :8080

# Kill the process (replace <PID> with actual process ID)
taskkill /PID <PID> /F

# Start server again
python serve_web.py
```

**Or edit serve_web.py and change PORT to 8081:**
```python
PORT = 8081  # Change this line
```

---

## 📋 Test Checklist

After starting both servers, test these:

- [ ] Open http://localhost:8080/chat_widget.html
- [ ] Status shows "● Online" (green)
- [ ] Click "👋 Hello" quick action button
- [ ] See AI response appear
- [ ] Type a custom message: "What can you help with?"
- [ ] Press Enter or click Send
- [ ] See AI response
- [ ] Try "📊 Count Users" button
- [ ] Verify SQL is displayed

**All checked?** ✅ Your chat widgets are working perfectly!

---

## 🎨 Different Interfaces

### 1. Simple Chat Widget
**URL**: http://localhost:8080/chat_widget.html
**Best for**: Testing, demos, simple integration
**Features**:
- Beautiful gradient UI
- Quick actions
- Real-time chat
- SQL display
- Mobile responsive

### 2. Advanced Interface
**URL**: http://localhost:8080/chat_interface_advanced.html?apiKey=YOUR_KEY
**Best for**: Analytics dashboards, data visualization
**Features**:
- Everything from simple widget
- Data visualizations (Plotly charts)
- Multiple chart types (bar, line, pie, scatter, area, table)
- Voice calling integration (optional)
- SQL details toggle

### 3. Embed Examples
**URL**: http://localhost:8080/embed_example.html
**Shows**: How to embed widgets in your website
**Includes**: Code examples, integration instructions

---

## 🚀 Quick Test Command

Test the API directly:

```powershell
curl -X POST http://localhost:8000/chat `
  -H "Content-Type: application/json" `
  -H "X-API-Key: sk_live_5eba7c2f74be13485739063a59015bb5c6aa8021d22da4528a491b9a07f7d3a3" `
  -d '{\"message\":\"Hello\",\"check_sql\":true}'
```

**Expected**: JSON response with `response`, `sql`, and `results` fields.

---

## 📞 Two Servers Running

You need **both** servers running simultaneously:

| Server | Port | Purpose | URL |
|--------|------|---------|-----|
| **API Server** | 8000 | Backend API, AI processing | http://localhost:8000 |
| **Web Server** | 8080 | Serves HTML files | http://localhost:8080 |

**Why both?**
- **API Server (8000)**: Processes chat messages, generates SQL, queries database
- **Web Server (8080)**: Serves HTML files via HTTP (not `file://`)

---

## 🎉 Success Indicators

When everything is working correctly, you'll see:

1. **In Advanced Interface:**
   - Status: "● Online" (green dot)
   - No "Failed to fetch" errors when sending messages
   - AI responses appear after sending messages
   - SQL queries displayed (if enabled)

2. **In Browser Console (F12):**
   - No CORS errors
   - Successful API calls to `http://localhost:8000/chat`
   - 200 OK responses

3. **In API Server Logs:**
   ```
   INFO: 127.0.0.1:xxxxx - "POST /chat HTTP/1.1" 200 OK
   ```

---

## 💡 Remember

**Don't open HTML files directly!**
- ❌ Right-click → Open with Chrome
- ❌ Double-click HTML file
- ❌ file:// protocol

**Always use the web server:**
- ✅ python serve_web.py
- ✅ http://localhost:8080/...
- ✅ http:// protocol

---

## 🆘 Still Having Issues?

1. Check browser console (F12) for errors
2. Check API server logs for errors
3. Verify both servers are running
4. Try the curl test command above
5. Clear browser cache (Ctrl+Shift+Delete)
6. Try a different browser

---

**Your chat widgets are now properly configured and ready to test!** 🚀
