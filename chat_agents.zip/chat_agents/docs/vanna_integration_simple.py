from typing import Optional, List, Dict, Any
from config import settings
from db_connector import TursoDBConnector
import google.generativeai as genai


class VannaSQLAgent:
    def __init__(self, api_key: Optional[str] = None, model_name: str = "gemini-2.0-flash-exp"):
        self.api_key = api_key or settings.GEMINI_API_KEY
        self.model_name = model_name
        genai.configure(api_key=self.api_key)
        self.model = genai.GenerativeModel(self.model_name)
        self.db_connector = None
        self.training_data = {"ddl": [], "documentation": [], "questions": []}

    async def setup_db(self, db_connector: Optional[TursoDBConnector] = None):
        if db_connector:
            self.db_connector = db_connector
        else:
            self.db_connector = TursoDBConnector()
            await self.db_connector.connect()

    def train_ddl(self, ddl: str):
        if ddl not in self.training_data["ddl"]:
            self.training_data["ddl"].append(ddl)

    def train_documentation(self, documentation: str):
        if documentation not in self.training_data["documentation"]:
            self.training_data["documentation"].append(documentation)

    def train_question_sql(self, question: str, sql: str):
        self.training_data["questions"].append({"question": question, "sql": sql})

    async def train_from_database(self):
        if not self.db_connector:
            await self.setup_db()
        schema_query = "SELECT sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
        tables = await self.db_connector.fetch_all(schema_query)
        for table in tables:
            sql_content = table.get('sql') if isinstance(table, dict) else getattr(table, 'sql', None)
            if sql_content:
                self.train_ddl(sql_content)

    def generate_sql(self, question: str) -> str:
        context = self._build_context()
        prompt = f"You are an expert SQL generator.\n{context}\nQuestion: {question}\nReturn ONLY the SQL query."
        try:
            response = self.model.generate_content(prompt)
            sql = response.text.strip().replace("```sql", "").replace("```", "").strip()
            return sql
        except Exception as e:
            raise Exception(f"Error generating SQL: {str(e)}")

    def _build_context(self) -> str:
        parts = []
        if self.training_data["ddl"]:
            parts.append("Schema: " + ", ".join(self.training_data["ddl"]))
        if self.training_data["documentation"]:
            parts.append("Docs: " + ", ".join(self.training_data["documentation"]))
        if self.training_data["questions"]:
            examples = [f"Q: {q['question']} SQL: {q['sql']}" for q in self.training_data["questions"]]
            parts.append("Examples: " + ", ".join(examples))
        return " | ".join(parts) if parts else "No schema info."

    async def ask(self, question: str) -> Dict[str, Any]:
        sql_var = None
        try:
            sql_var = self.generate_sql(question)
            if not self.db_connector:
                await self.setup_db()
            results = await self.db_connector.fetch_all(sql_var)
            return {"success": True, "question": question, "sql": sql_var, "results": results, "row_count": len(results)}
        except Exception as e:
            return {"success": False, "question": question, "error": str(e), "sql": sql_var}

    def generate_plotly_code(self, question: str, sql: str, df_name: str = "df") -> str:
        prompt = f"Generate Plotly code for SQL: {sql}, Question: {question}, DataFrame: {df_name}"
        try:
            response = self.model.generate_content(prompt)
            return response.text.strip()
        except Exception as e:
            return f"# Error: {str(e)}"

    def get_training_data(self) -> List[Dict[str, Any]]:
        all_data = []
        for ddl in self.training_data["ddl"]:
            all_data.append({"type": "ddl", "content": ddl})
        for doc in self.training_data["documentation"]:
            all_data.append({"type": "documentation", "content": doc})
        for qa in self.training_data["questions"]:
            all_data.append({"type": "question_sql", "question": qa["question"], "sql": qa["sql"]})
        return all_data

    async def close(self):
        if self.db_connector:
            await self.db_connector.close()
