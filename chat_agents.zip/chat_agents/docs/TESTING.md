# Testing Guide

## Test Results Summary

### ✅ **11 Tests PASSED** (DB Connector + Twilio Handler)

```
tests/test_db_connector.py::TestTursoDBConnector::test_connection PASSED
tests/test_db_connector.py::TestTursoDBConnector::test_create_table PASSED
tests/test_db_connector.py::TestTursoDBConnector::test_insert_data PASSED
tests/test_db_connector.py::TestTursoDBConnector::test_fetch_all PASSED
tests/test_db_connector.py::TestTursoDBConnector::test_fetch_one PASSED
tests/test_db_connector.py::TestTursoDBConnector::test_context_manager PASSED
tests/test_twilio_handler.py::TestTwilioHandler::test_initialization PASSED
tests/test_twilio_handler.py::TestTwilioHandler::test_send_sms_mock PASSED
tests/test_twilio_handler.py::TestTwilioHandler::test_send_whatsapp_mock PASSED
tests/test_twilio_handler.py::TestTwilioHandler::test_create_twiml_response PASSED
tests/test_twilio_handler.py::TestTwilioHandler::test_whatsapp_number_formatting PASSED
```

## Running Tests

### Install Dependencies
```bash
pip install -r requirements.txt
```

### Run All Tests
```bash
pytest tests/ -v
```

### Run Specific Test Files
```bash
# Database connector tests
pytest tests/test_db_connector.py -v

# Twilio handler tests
pytest tests/test_twilio_handler.py -v

# Chat agent tests
pytest tests/test_chat_agent.py -v

# API tests
pytest tests/test_api.py -v

# End-to-end tests
pytest tests/test_end_to_end.py -v
```

### Run with Coverage
```bash
pytest tests/ --cov=. --cov-report=html
```

### Run Specific Tests
```bash
# Run a specific test function
pytest tests/test_db_connector.py::TestTursoDBConnector::test_connection -v

# Run tests matching a pattern
pytest tests/ -k "test_fetch" -v
```

## Test Structure

```
tests/
├── __init__.py
├── conftest.py                  # Fixtures and setup
├── test_db_connector.py        # Database tests
├── test_vanna_integration.py   # SQL generation tests
├── test_twilio_handler.py      # SMS/WhatsApp tests
├── test_chat_agent.py          # Chat agent tests
├── test_api.py                 # FastAPI endpoint tests
└── test_end_to_end.py          # Full workflow tests
```

## Available Fixtures

- `db_connector` - Connected Turso DB instance
- `vanna_agent` - Vanna SQL agent with DB
- `twilio_handler` - Twilio SMS/WhatsApp handler
- `chat_agent` - Full chat agent with all features
- `chat_agent_no_features` - Basic chat agent only
- `sample_ddl` - Sample database schema
- `sample_phone` - Test phone number

## Test Coverage

### Database Connector (TursoDBConnector)
- ✅ Connection establishment
- ✅ Table creation
- ✅ Data insertion
- ✅ Fetch all records
- ✅ Fetch single record
- ✅ Context manager usage

### Twilio Handler
- ✅ Initialization with credentials
- ✅ SMS sending (mocked)
- ✅ WhatsApp sending (mocked)
- ✅ TwiML response generation
- ✅ Number formatting

### Chat Agent
- ✅ Basic initialization
- ✅ Full initialization with all features
- ✅ Message processing
- ✅ Conversation history
- ✅ Callback system
- ✅ SQL query detection

### FastAPI
- ✅ Root endpoint
- ✅ Health check
- ✅ Chat endpoint
- ✅ History management
- ✅ Training endpoint

### End-to-End
- ✅ Complete chat workflow
- ✅ Database to agent workflow
- ✅ Multi-message conversations
- ✅ Callback chains
- ✅ Error handling

## Example: Running Tests

```bash
# Navigate to project directory
cd c:\Users\Mani_Moon\reapdat\code_integration\reusable_agents\chat_agents

# Run all tests with verbose output
pytest tests/ -v

# Run with short traceback
pytest tests/ -v --tb=short

# Run and stop on first failure
pytest tests/ -x

# Run tests in parallel (requires pytest-xdist)
pytest tests/ -n auto
```

## Debugging Failed Tests

```bash
# Run with full traceback
pytest tests/test_name.py --tb=long

# Run with Python debugger
pytest tests/test_name.py --pdb

# Show local variables on failure
pytest tests/test_name.py -l

# Increase verbosity
pytest tests/test_name.py -vv
```

## Continuous Integration

Add to your CI/CD pipeline:

```yaml
# .github/workflows/test.yml
name: Run Tests
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Set up Python
        uses: actions/setup-python@v2
        with:
          python-version: '3.11'
      - name: Install dependencies
        run: pip install -r requirements.txt
      - name: Run tests
        run: pytest tests/ -v --cov
        env:
          GEMINI_API_KEY: ${{ secrets.GEMINI_API_KEY }}
          TURSO_DB_AUTH_TOKEN: ${{ secrets.TURSO_DB_AUTH_TOKEN }}
          TURSO_DB_URL: ${{ secrets.TURSO_DB_URL }}
```

## Writing New Tests

```python
import pytest
from chat_agent import ChatAgent

class TestMyFeature:
    @pytest.mark.asyncio
    async def test_something(self, chat_agent):
        # Arrange
        test_message = "test"

        # Act
        response = await chat_agent.process_message(test_message)

        # Assert
        assert response["success"] is True
        assert response["ai_response"] is not None
```

## Test Best Practices

1. **Use fixtures** for common setup/teardown
2. **Mock external APIs** (Twilio, Gemini) when appropriate
3. **Test edge cases** and error handling
4. **Keep tests isolated** - each test should be independent
5. **Use descriptive test names** that explain what's being tested
6. **Clean up resources** after tests (database connections, etc.)
