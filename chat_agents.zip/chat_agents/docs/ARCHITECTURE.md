# Technical Architecture Guide

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                         CLIENT LAYER                            │
├─────────────────────────────────────────────────────────────────┤
│  Web Interface (HTML/JS)  │  External Apps  │  MCP Clients      │
│  - chat_interface.html    │  - React/Vue    │  - Claude Desktop │
│  - Direct browser access  │  - Mobile apps  │  - VS Code        │
└──────────────┬────────────┴─────────────────┴───────────────────┘
               │
               ▼ HTTP/HTTPS Requests
┌─────────────────────────────────────────────────────────────────┐
│                      API LAYER (FastAPI)                        │
├─────────────────────────────────────────────────────────────────┤
│  src/api.py - RESTful Endpoints                                 │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │ /chat          - Process chat messages                    │  │
│  │ /sms/send      - Send SMS                                 │  │
│  │ /whatsapp/send - Send WhatsApp                            │  │
│  │ /webhook/twilio- Receive Twilio webhooks                  │  │
│  │ /health        - Health check                             │  │
│  │ /history       - Conversation history                     │  │
│  │ /train         - Train SQL agent                          │  │
│  └───────────────────────────────────────────────────────────┘  │
└──────────────┬──────────────────────────────────────────────────┘
               │
               ▼ Internal Calls
┌─────────────────────────────────────────────────────────────────┐
│                   ORCHESTRATION LAYER                           │
├─────────────────────────────────────────────────────────────────┤
│  src/chat_agent.py - Main Orchestrator                          │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │ • Coordinates all components                              │  │
│  │ • Message routing & processing                            │  │
│  │ • SQL query detection                                     │  │
│  │ • Conversation history management                         │  │
│  │ • Callback execution                                      │  │
│  │ • Error handling & recovery                               │  │
│  └───────────────────────────────────────────────────────────┘  │
└──┬────────────┬────────────────────┬───────────────────────────┘
   │            │                    │
   ▼            ▼                    ▼
┌──────────┐ ┌──────────────────┐ ┌────────────────────┐
│   AI     │ │   SQL Agent      │ │  Messaging         │
│  Engine  │ │  (Vanna AI)      │ │  (Twilio)          │
└──────────┘ └──────────────────┘ └────────────────────┘
     │              │                      │
     ▼              ▼                      ▼
┌──────────┐ ┌──────────────────┐ ┌────────────────────┐
│ Google   │ │   Database       │ │  Twilio API        │
│ Gemini   │ │   (Turso DB)     │ │  - SMS Gateway     │
│   API    │ │   - LibSQL       │ │  - WhatsApp        │
└──────────┘ └──────────────────┘ └────────────────────┘
```

## Component Architecture

### 1. API Layer (src/api.py)
**Technology:** FastAPI with async/await
**Responsibilities:**
- HTTP request handling
- Request validation (Pydantic models)
- Response formatting
- CORS handling
- Webhook processing
- OpenAPI documentation

**Key Features:**
- Lifespan context manager for startup/shutdown
- Automatic API documentation at `/docs`
- Type-safe request/response models
- Error handling middleware

### 2. Orchestration Layer (src/chat_agent.py)
**Technology:** Async Python with Google Gemini
**Responsibilities:**
- Coordinate all components
- Message flow control
- SQL query detection heuristics
- Conversation state management
- Callback pattern implementation

**Key Features:**
- Modular component initialization
- Pluggable callback system
- Async operation throughout
- Graceful error handling

### 3. AI Engine (Google Gemini)
**Technology:** google.generativeai SDK
**Model:** gemini-2.0-flash-exp
**Responsibilities:**
- Natural language understanding
- Chat responses
- Context-aware conversations
- Result explanation

**Integration Points:**
- src/chat_agent.py - Main chat responses
- src/vanna_integration.py - SQL generation

### 4. SQL Agent (src/vanna_integration.py)
**Technology:** Custom Gemini-based implementation
**Responsibilities:**
- Natural language to SQL conversion
- Schema understanding
- Query optimization
- Training data management

**Key Features:**
- DDL training
- Documentation training
- Question-SQL pair training
- Auto-training from database schema

### 5. Database Layer (src/db_connector.py)
**Technology:** Turso DB (LibSQL)
**Responsibilities:**
- Database connection management
- Query execution
- Result set handling
- Connection pooling

**Key Features:**
- Async operations
- Context manager support
- Automatic reconnection
- ResultSet compatibility handling

### 6. Messaging Layer (src/twilio_handler.py)
**Technology:** Twilio SDK
**Responsibilities:**
- SMS sending
- WhatsApp messaging
- TwiML response generation
- Webhook validation

**Key Features:**
- Multi-channel support (SMS + WhatsApp)
- Number formatting
- Webhook security validation
- Error handling

### 7. Configuration (src/config.py)
**Technology:** Pydantic Settings
**Responsibilities:**
- Environment variable management
- Configuration validation
- Settings centralization

**Key Features:**
- Type-safe configuration
- .env file support
- Default values
- Validation on startup

## Data Flow

### Standard Chat Flow
```
1. User sends message via web interface
2. POST /chat → API receives request
3. API → ChatAgent.process_message()
4. ChatAgent checks if SQL query needed

   NO SQL:
   5a. ChatAgent → Gemini API
   6a. Gemini generates response
   7a. Return to user

   SQL DETECTED:
   5b. ChatAgent → VannaSQLAgent.ask()
   6b. VannaSQLAgent → Gemini (generate SQL)
   7b. VannaSQLAgent → TursoDBConnector.execute()
   8b. Database returns results
   9b. ChatAgent → Gemini (explain results)
   10b. Return formatted response to user
```

### SMS/WhatsApp Flow
```
1. User sends SMS/WhatsApp to Twilio number
2. Twilio → POST /webhook/twilio
3. API → ChatAgent.handle_incoming_sms/whatsapp()
4. ChatAgent processes message (same as chat flow)
5. ChatAgent → TwilioHandler.send_sms/whatsapp()
6. TwilioHandler → Twilio API
7. Twilio delivers message to user
```

## Technical Components Involved

### Core Technologies
1. **Python 3.11+** - Primary language
2. **FastAPI** - Modern async web framework
3. **Uvicorn** - ASGI server
4. **Pydantic** - Data validation
5. **Google Gemini API** - AI/LLM capabilities
6. **Turso DB (LibSQL)** - Serverless SQLite database
7. **Twilio API** - SMS/WhatsApp messaging

### Libraries & Dependencies
```
fastapi==0.104.1        # Web framework
uvicorn==0.24.0         # ASGI server
pydantic==2.5.0         # Data validation
pydantic-settings==2.1.0 # Settings management
google-generativeai     # Gemini AI
libsql-client          # Turso DB client
twilio                 # SMS/WhatsApp
pytest==7.4.3          # Testing framework
pytest-asyncio==0.21.1 # Async test support
```

### External Services
1. **Google Gemini API** - AI responses & SQL generation
2. **Turso DB** - Cloud SQLite database
3. **Twilio** - SMS/WhatsApp gateway

## FastAPI vs MCP Comparison

### Current Implementation: FastAPI

**Advantages:**
✅ **Universal Access** - Any HTTP client can use it
✅ **Web Integration** - Easy to embed in websites
✅ **Platform Independent** - Works everywhere
✅ **Auto Documentation** - Built-in Swagger/OpenAPI docs
✅ **Mature Ecosystem** - Lots of tools and libraries
✅ **Scalable** - Easy to deploy on any cloud platform
✅ **RESTful** - Standard HTTP methods everyone knows
✅ **Language Agnostic** - Clients can be any language

**Use Cases:**
- Embedding in websites (React, Vue, WordPress)
- Mobile app backends
- Third-party integrations
- Microservices architecture
- Public APIs
- Multi-language environments

### Alternative: MCP (Model Context Protocol)

**Advantages:**
✅ **Native Claude Integration** - Designed for Claude
✅ **Context Sharing** - Better context management
✅ **Streaming Support** - Real-time responses
✅ **Resource Management** - Built-in resource handling
✅ **Tool Calling** - Native tool/function support
✅ **IDE Integration** - Works in VS Code, Claude Desktop

**Limitations:**
❌ **Claude-Specific** - Only works with Claude/Anthropic ecosystem
❌ **Limited Adoption** - Fewer clients support it
❌ **Less Mature** - Newer protocol, less tooling
❌ **No Web Integration** - Can't easily embed in websites
❌ **Server Required** - Must run MCP server

**Use Cases:**
- Claude Desktop integration
- VS Code extensions
- Developer tools
- Internal Claude-based workflows
- AI-first applications

## Recommendation: **Use Both!**

The best approach is to support both:

### Hybrid Architecture
```
┌─────────────────────────────────────────┐
│         Your Chat Agent Core            │
│    (chat_agent.py - business logic)     │
└────────────┬────────────┬───────────────┘
             │            │
    ┌────────┴──┐    ┌────┴─────┐
    │  FastAPI  │    │   MCP    │
    │  Wrapper  │    │ Wrapper  │
    └────┬──────┘    └────┬─────┘
         │                │
    HTTP Clients    Claude Clients
```

### Implementation Strategy

**Keep FastAPI for:**
- Web interface (current chat_interface.html)
- Website integrations
- Mobile apps
- Public API access
- Third-party integrations

**Add MCP for:**
- Claude Desktop integration
- VS Code extension
- Developer workflows
- AI-native tools

### Creating MCP Wrapper (Future Enhancement)

```python
# src/mcp_server.py
from mcp import Server
from src.chat_agent import ChatAgent

class ChatAgentMCPServer(Server):
    def __init__(self):
        super().__init__("chat-agent")
        self.agent = ChatAgent(enable_sql=True, enable_twilio=True)

    @self.tool()
    async def chat(self, message: str, check_sql: bool = True):
        """Process a chat message"""
        return await self.agent.process_message(message, check_sql=check_sql)

    @self.tool()
    async def send_sms(self, to: str, message: str):
        """Send SMS via Twilio"""
        return await self.agent.send_sms_response(to, message)
```

## Deployment Architecture

### Option 1: Single Server (Current)
```
FastAPI Server (port 8000)
├── Static file serving (web/chat_interface.html)
├── REST API endpoints
└── Background workers
```

### Option 2: Microservices
```
┌─────────────┐  ┌──────────────┐  ┌─────────────┐
│   FastAPI   │  │  MCP Server  │  │   Worker    │
│   (API)     │  │  (Claude)    │  │   Queue     │
└─────────────┘  └──────────────┘  └─────────────┘
      ▲                 ▲                  ▲
      └─────────────────┴──────────────────┘
                   Load Balancer
```

### Option 3: Serverless
```
┌────────────────────────────────────┐
│  Cloud Function / Lambda           │
│  ├── /chat endpoint                │
│  ├── /sms endpoint                 │
│  └── /webhook endpoint             │
└────────────────────────────────────┘
         ▲
         │ Trigger on HTTP request
         │
    API Gateway
```

## Security Architecture

### Current Security Measures
1. **Environment Variables** - Sensitive credentials in .env
2. **Input Validation** - Pydantic models
3. **Webhook Validation** - Twilio signature verification
4. **Error Handling** - No sensitive data in errors

### Recommended Additions
1. **API Key Authentication** - Protect endpoints
2. **Rate Limiting** - Prevent abuse
3. **HTTPS Only** - Encrypted transport
4. **CORS Configuration** - Control origins
5. **Request Size Limits** - Prevent DoS
6. **Logging & Monitoring** - Audit trail

## Performance Considerations

### Current Performance
- **Async Throughout** - Non-blocking I/O
- **Connection Pooling** - Database connections
- **Stateless API** - Horizontal scaling ready

### Optimization Opportunities
1. **Caching** - Cache frequent SQL results
2. **CDN** - Serve static files from CDN
3. **Load Balancing** - Multiple instances
4. **Database Indexing** - Optimize queries
5. **Response Compression** - Reduce bandwidth

## Testing Architecture

### Test Layers
```
┌─────────────────────────────────────┐
│   End-to-End Tests                  │
│   (test_end_to_end.py)              │
├─────────────────────────────────────┤
│   Integration Tests                 │
│   (test_api.py, test_chat_agent.py) │
├─────────────────────────────────────┤
│   Unit Tests                        │
│   (test_db_connector.py, etc.)      │
└─────────────────────────────────────┘
```

### Testing Tools
- **pytest** - Test framework
- **pytest-asyncio** - Async test support
- **unittest.mock** - Mocking external APIs
- **pytest-cov** - Code coverage

## Monitoring & Observability

### Recommended Setup
1. **Logging** - Structured JSON logs
2. **Metrics** - Request count, latency, errors
3. **Tracing** - Request flow tracking
4. **Alerting** - Error rate thresholds

### Tools
- **Prometheus** - Metrics collection
- **Grafana** - Visualization
- **Sentry** - Error tracking
- **ELK Stack** - Log aggregation

## Summary

Your chat agent has a **clean, modular architecture** with:

- **FastAPI** for universal HTTP access
- **Async Python** for performance
- **Pluggable components** for flexibility
- **Clear separation of concerns**
- **Production-ready error handling**

**Answer to Your Question:**
- **Use FastAPI** if you need web integration, public APIs, or language-agnostic access
- **Add MCP** if you want Claude Desktop or VS Code integration
- **Use Both** for maximum flexibility (recommended)

The current FastAPI implementation is perfect for web-based use cases. Add MCP only if you specifically need Claude ecosystem integration.
