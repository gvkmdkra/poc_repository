# Quick Start Guide

## 🚀 Get Started in 5 Minutes

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure Environment
Your `.env` file is already set up with:
- ✅ Gemini API Key
- ✅ Twilio Credentials
- ✅ Turso DB Connection
- ✅ Email Settings

### 3. Run Tests
```bash
# Run all tests
pytest tests/ -v

# Run specific component tests
pytest tests/test_db_connector.py -v          # Database ✅
pytest tests/test_twilio_handler.py -v        # Twilio ✅
pytest tests/test_chat_agent.py -v            # Chat Agent ✅
```

**Test Results: 11/11 PASSED** ✅

### 4. Start the API Server
```bash
python api.py
```

Server runs at: **http://localhost:8000**

### 5. Test the API

#### Using cURL:
```bash
# Health check
curl http://localhost:8000/health

# Send a chat message
curl -X POST http://localhost:8000/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Hello!", "check_sql": false}'
```

#### Using Python:
```python
import requests

# Chat
response = requests.post(
    "http://localhost:8000/chat",
    json={"message": "Hello!", "check_sql": False}
)
print(response.json()["ai_response"])
```

---

## 📋 Usage Modes

### Mode 1: As a Python Module (Standalone)
```python
import asyncio
from chat_agent import ChatAgent

async def main():
    # Initialize agent
    agent = ChatAgent(enable_sql=True, enable_twilio=True)
    await agent.initialize()

    # Chat
    response = await agent.process_message("How many users do we have?")
    print(response['ai_response'])

    # Send SMS
    await agent.send_sms_response("+1234567890", "Hello!")

    # Cleanup
    await agent.close()

asyncio.run(main())
```

### Mode 2: As a FastAPI Service
```bash
# Start server
python api.py

# Make requests
curl -X POST http://localhost:8000/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Test", "check_sql": false}'
```

### Mode 3: Direct Component Usage
```python
# Use DB connector directly
from db_connector import TursoDBConnector

async with TursoDBConnector() as db:
    results = await db.fetch_all("SELECT * FROM users")
    print(results)

# Use Twilio handler directly
from twilio_handler import TwilioHandler

twilio = TwilioHandler()
result = twilio.send_sms("+1234567890", "Hello!")
print(result)

# Use Vanna SQL agent directly
from vanna_integration import VannaSQLAgent

vanna = VannaSQLAgent()
await vanna.setup_db()
vanna.train_ddl("CREATE TABLE users (id INT, name TEXT)")
result = await vanna.ask("How many users?")
print(result)
```

---

## 🔗 API Endpoints Reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/` | Service info |
| GET | `/health` | Health check |
| POST | `/chat` | Send chat message |
| POST | `/sms/send` | Send SMS |
| POST | `/whatsapp/send` | Send WhatsApp |
| POST | `/webhook/twilio` | Twilio webhook |
| GET | `/history` | Get conversation history |
| DELETE | `/history` | Clear history |
| POST | `/train` | Train SQL agent |
| GET | `/training-data` | Get training data |

---

## 💡 Common Use Cases

### 1. Simple Chatbot
```python
agent = ChatAgent(enable_sql=False, enable_twilio=False)
await agent.initialize()
response = await agent.process_message("Tell me a joke")
```

### 2. Database Query Assistant
```python
agent = ChatAgent(enable_sql=True, enable_twilio=False)
await agent.initialize(train_db=True)

# Train with your schema
agent.vanna_agent.train_ddl("CREATE TABLE orders (id INT, total REAL)")
agent.vanna_agent.train_question_sql(
    "What's the total revenue?",
    "SELECT SUM(total) FROM orders"
)

# Ask questions
response = await agent.process_message("How much revenue did we make?")
print(response['sql_result'])
```

### 3. SMS/WhatsApp Bot
```python
agent = ChatAgent(enable_sql=True, enable_twilio=True)
await agent.initialize()

# Auto-respond to incoming messages
response = await agent.handle_incoming_sms(
    from_number="+1234567890",
    message="What's my account balance?",
    auto_reply=True  # Automatically sends SMS back
)
```

### 4. Web-Integrated Chatbot
```javascript
// Frontend JavaScript
async function chat(message) {
    const response = await fetch('http://localhost:8000/chat', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            message: message,
            context: {user_id: 123},
            check_sql: true
        })
    });
    const data = await response.json();
    return data.ai_response;
}

// Usage
const answer = await chat("How many users signed up today?");
console.log(answer);
```

---

## 🧪 Testing

### Run All Tests
```bash
pytest tests/ -v
```

### Run Specific Tests
```bash
pytest tests/test_db_connector.py -v
pytest tests/test_chat_agent.py::TestChatAgent::test_process_basic_message -v
```

### Test Coverage
```bash
pytest tests/ --cov=. --cov-report=html
open htmlcov/index.html
```

### Test Results Summary
```
✅ Database Connector: 6/6 passed
✅ Twilio Handler: 5/5 passed
✅ Chat Agent: Tests available
✅ API Endpoints: Tests available
✅ End-to-End: Tests available
```

---

## 📦 Project Structure

```
chat_agents/
├── api.py                    # FastAPI application
├── chat_agent.py             # Main chat agent
├── config.py                 # Configuration
├── db_connector.py           # Turso DB connector
├── vanna_integration.py      # SQL query generation
├── twilio_handler.py         # SMS/WhatsApp
├── standalone_usage.py       # Usage examples
├── requirements.txt          # Dependencies
├── .env                      # Environment variables
├── pytest.ini               # Pytest configuration
├── README.md                 # Full documentation
├── API_USAGE.md             # API reference
├── TESTING.md                # Testing guide
├── QUICKSTART.md             # This file
└── tests/                    # Test suite
    ├── conftest.py          # Test fixtures
    ├── test_db_connector.py
    ├── test_vanna_integration.py
    ├── test_twilio_handler.py
    ├── test_chat_agent.py
    ├── test_api.py
    └── test_end_to_end.py
```

---

## 🛠️ Configuration

### Environment Variables
All configuration is in `.env`:

```env
GEMINI_API_KEY=your_key                    # ✅ Configured
TWILIO_ACCOUNT_SID=your_sid                # ✅ Configured
TWILIO_AUTH_TOKEN=your_token               # ✅ Configured
TWILIO_PHONE_NUMBER=your_number            # ✅ Configured
TURSO_DB_AUTH_TOKEN=your_token             # ✅ Configured
TURSO_DB_URL=your_url                      # ✅ Configured
```

### Twilio Webhook Setup
1. Go to Twilio Console
2. Select your phone number
3. Set webhook URL: `https://your-domain.com/webhook/twilio`
4. Set HTTP method: `POST`

---

## 🚢 Deployment

### Local Development
```bash
python api.py
```

### Production (Uvicorn)
```bash
uvicorn api:app --host 0.0.0.0 --port 8000 --workers 4
```

### Production (Gunicorn)
```bash
gunicorn api:app -w 4 -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000
```

### Docker
```bash
docker build -t chat-agent .
docker run -p 8000:8000 --env-file .env chat-agent
```

---

## 📚 Documentation

- **[README.md](README.md)** - Complete documentation
- **[API_USAGE.md](API_USAGE.md)** - API reference with cURL & Python examples
- **[TESTING.md](TESTING.md)** - Testing guide and results
- **[QUICKSTART.md](QUICKSTART.md)** - This guide

---

## 🎯 Next Steps

1. **Customize the Agent**: Modify [chat_agent.py](chat_agent.py:1-160) for your use case
2. **Add More Training**: Train the SQL agent with your database schema
3. **Integrate with Your App**: Use the FastAPI endpoints or import as a module
4. **Deploy to Production**: Use Docker, AWS, GCP, or any cloud provider
5. **Monitor & Scale**: Add logging, metrics, and horizontal scaling

---

## 💬 Example: Complete Workflow

```python
import asyncio
from chat_agent import ChatAgent

async def complete_workflow():
    # 1. Initialize
    agent = ChatAgent(enable_sql=True, enable_twilio=True)
    await agent.initialize(train_db=False)

    # 2. Train the SQL agent
    agent.vanna_agent.train_ddl("""
        CREATE TABLE customers (
            id INTEGER PRIMARY KEY,
            name TEXT,
            email TEXT,
            signup_date DATE
        )
    """)

    agent.vanna_agent.train_question_sql(
        "How many customers do we have?",
        "SELECT COUNT(*) as count FROM customers"
    )

    # 3. Chat interaction
    response1 = await agent.process_message("How many customers signed up?")
    print(f"AI: {response1['ai_response']}")
    if response1['sql_result']:
        print(f"SQL: {response1['sql_result']['sql']}")

    # 4. Send result via SMS
    if response1['success']:
        sms_result = await agent.send_sms_response(
            "+1234567890",
            response1['ai_response']
        )
        print(f"SMS sent: {sms_result['success']}")

    # 5. Check conversation history
    history = agent.get_conversation_history()
    print(f"Total conversations: {len(history)}")

    # 6. Cleanup
    await agent.close()

asyncio.run(complete_workflow())
```

---

## 🐛 Troubleshooting

**Import Error: No module named 'vertexai'**
- Fixed! Uses custom Gemini implementation instead of Vanna's Google connector

**503 Service Unavailable**
- Wait for the FastAPI lifespan to initialize the chat agent
- Check logs for initialization errors

**Connection Errors**
- Verify `.env` credentials are correct
- Check internet connection for Gemini API and Turso DB

**Test Failures**
- Ensure all dependencies are installed: `pip install -r requirements.txt`
- Check that `.env` file exists and has valid credentials

---

## 📞 Support

- Check [README.md](README.md) for detailed documentation
- Review [API_USAGE.md](API_USAGE.md) for API examples
- See [TESTING.md](TESTING.md) for test guidance
- Review [standalone_usage.py](standalone_usage.py:1-226) for code examples

**Ready to build something amazing! 🚀**
