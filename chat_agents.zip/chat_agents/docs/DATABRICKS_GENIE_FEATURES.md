# 🎨 Databricks Genie-Style Features - Quick Reference

## Overview

The Advanced Chat Interface now includes Databricks Genie-inspired features for data visualization and voice calling.

---

## 🚀 Quick Start

### Open the Advanced Interface

**Method 1 - File Explorer (Recommended):**
1. Navigate to: `c:\Users\Mani_Moon\reapdat\code_integration\reusable_agents\chat_agents\web`
2. Double-click `chat_interface_advanced.html`

**Method 2 - Direct URL:**
```
file:///c:/Users/Mani_Moon/reapdat/code_integration/reusable_agents/chat_agents/web/chat_interface_advanced.html
```

---

## 📊 Visualization Features

### Available Chart Types

1. **📊 Bar Chart** - Compare categories side-by-side
2. **📈 Line Chart** - Show trends and changes over time
3. **🥧 Pie Chart** - Display proportions and percentages
4. **🔵 Scatter Plot** - Identify correlations and patterns
5. **📉 Area Chart** - Visualize cumulative data
6. **📋 Table View** - Inspect raw data

### How to Use

**Step 1: Enable SQL Queries**
- Toggle "Check SQL" switch to ON (green)

**Step 2: Ask a Data Question**
```
Examples:
- "Show me 10 records from kfc_churn_data_src_tbl"
- "What are the top 5 customers by revenue?"
- "Display churn rates by month"
- "Show me sentiment scores distribution"
```

**Step 3: Visualize Results**
- After query results appear, click "Visualize" button
- Visualization panel opens on the right side

**Step 4: Switch Chart Types**
- Click any chart type button at the top
- Chart re-renders instantly with new type

**Step 5: Auto-Visualize (Optional)**
- Toggle "Auto-visualize" ON
- All SQL results automatically show charts

---

## 📞 Voice Calling Features

### Outbound Calls

**From Chat Interface:**

1. Click "📞 Call Agent" button in header
2. Enter your phone number (format: +1234567890)
3. Click OK
4. Wait for call modal to show status
5. Answer your phone
6. Have a conversation with the AI

**From API:**

```powershell
curl -X POST http://localhost:8000/call/make `
  -H "Content-Type: application/json" `
  -d '{
    "to": "+1234567890",
    "message": "Hello! This is your AI calling."
  }'
```

**From Python:**

```python
import requests

response = requests.post(
    'http://localhost:8000/call/make',
    json={
        'to': '+1234567890',
        'message': 'Hello! Custom message here.'
    }
)

print(response.json())
# {'success': True, 'call_sid': 'CA123...', 'status': 'queued'}
```

### Voice Conversation Flow

1. **AI Greets You:**
   ```
   "Hello! Thank you for calling the AI Agent.
    How can I help you today?"
   ```

2. **You Speak Your Question:**
   - Wait for the beep
   - Speak clearly: "How many customers churned?"

3. **AI Processes:**
   - Converts speech to text
   - Queries database if needed
   - Generates response

4. **AI Responds:**
   ```
   "According to the database, 42 customers churned last month."
   ```

5. **Continue or End:**
   - Say another question, or
   - Hang up to end call

### Call Modal Features

**Status Indicators:**
- "Calling AI Agent..." - Call being initiated
- "Call initiated!" - Call sent successfully
- "Connected" - Call in progress
- "Error: ..." - Call failed

**Controls:**
- 🎤 Mute/Unmute button
- 📞 End call button
- ❌ Close modal

---

## 🎯 Usage Examples

### Example 1: Sales Dashboard

```
Step 1: Ask question
"Show me top 10 products by sales"

Step 2: View results
SQL executes, shows table with product data

Step 3: Visualize
Click "Visualize" → Bar chart appears

Step 4: Explore
- Switch to Pie chart for proportions
- Switch to Table for detailed view
- Hover over bars for exact values
```

### Example 2: Churn Analysis

```
Step 1: Query
"Show me churn rate by month for last 6 months"

Step 2: Visualize
Results appear → Auto-visualize creates Line chart

Step 3: Analyze
- See trend over time
- Identify peak churn months
- Export insights
```

### Example 3: Voice Query

```
Step 1: Click "Call Agent"
Enter phone number → +1234567890

Step 2: Answer call
AI: "Hello! How can I help?"

Step 3: Ask
You: "What's our total revenue this quarter?"

Step 4: Get answer
AI: "Total revenue is $1.2 million"

Step 5: Follow up
You: "How does that compare to last quarter?"
AI: "That's a 15% increase from last quarter"
```

---

## 🎨 Interface Layout

```
┌─────────────────────────────────────────────────────────────┐
│  Advanced Chat Agent                [📞] [👁] [🗑] [❤]       │
│  ● Online                                                    │
├──────────────────────────────┬──────────────────────────────┤
│                              │                              │
│  Chat Messages               │  Visualization Panel         │
│                              │                              │
│  👤 User: Show me data       │  [📊][📈][🥧][🔵][📉][📋]     │
│                              │                              │
│  🤖 Bot: Here are results    │  ┌────────────────────────┐  │
│      [SQL Query shown]       │  │                        │  │
│      [Table with data]       │  │   Interactive Chart    │  │
│      [Visualize button]      │  │                        │  │
│                              │  └────────────────────────┘  │
│  👤 User: Next question      │                              │
│                              │  □ Auto-visualize            │
│                              │                              │
├──────────────────────────────┴──────────────────────────────┤
│  Type your message...                          [Send] [⚙]   │
│  □ Check SQL                                                 │
└─────────────────────────────────────────────────────────────┘
```

---

## 🔧 Configuration

### Environment Variables

```env
# Required for all features
GEMINI_API_KEY=your_gemini_key
TURSO_DB_URL=libsql://your-db.turso.io
TURSO_DB_AUTH_TOKEN=your_token

# Required for voice calling
TWILIO_ACCOUNT_SID=AC...
TWILIO_AUTH_TOKEN=your_auth_token
TWILIO_PHONE_NUMBER=+16205538384

# Optional for webhooks
BASE_URL=https://your-ngrok-url.ngrok.io
```

### Twilio Voice Setup

1. **Log into Twilio Console**
   - https://console.twilio.com

2. **Configure Phone Number**
   - Go to Phone Numbers > Manage > Active Numbers
   - Click your phone number
   - Scroll to "Voice & Fax"

3. **Set Webhook URL**
   - A CALL COMES IN: Webhook
   - URL: `https://your-ngrok-url.ngrok.io/webhook/voice`
   - HTTP: POST
   - Save

4. **Test with ngrok (for local development)**
   ```powershell
   # Install ngrok
   choco install ngrok

   # Start tunnel
   ngrok http 8000

   # Copy HTTPS URL and update Twilio webhook
   ```

---

## 💡 Pro Tips

### For Best Visualizations

1. **Ask Specific Questions**
   - ❌ Bad: "Show me data"
   - ✅ Good: "Show me top 10 customers by revenue"

2. **Choose Right Chart Type**
   - Bar: Comparing 2-20 categories
   - Line: Time series, trends
   - Pie: 2-8 categories, proportions
   - Scatter: Finding correlations
   - Area: Cumulative totals
   - Table: Detailed inspection

3. **Use Auto-Visualize**
   - Enable for automatic charts
   - Disable for just data tables

### For Voice Calls

1. **Phone Number Format**
   - Include country code: +1234567890
   - No spaces or dashes
   - Use verified numbers (Twilio requirement)

2. **Speaking Tips**
   - Wait for beep before speaking
   - Speak clearly and slowly
   - Keep questions concise
   - Wait for full AI response

3. **Testing Locally**
   - Use ngrok for webhooks
   - Test with verified numbers first
   - Check Twilio debugger for issues

---

## 🐛 Common Issues

### Visualization Problems

**Problem: Charts not showing**
```
Solution:
1. Check browser console (F12)
2. Verify SQL query returned data
3. Try refreshing page
4. Try different chart type
```

**Problem: Visualization panel won't open**
```
Solution:
1. Click "Toggle Visualization" button
2. Make sure SQL is enabled
3. Run a query first
4. Check if results exist
```

**Problem: Chart looks wrong**
```
Solution:
1. Try different chart type
2. Check data has numeric values
3. Verify column names are appropriate
4. Use Table view to inspect raw data
```

### Voice Call Problems

**Problem: Call button does nothing**
```
Solution:
1. Check server is running
2. Verify Twilio credentials in .env
3. Check browser console for errors
4. Ensure phone number format is correct
```

**Problem: Call fails immediately**
```
Solution:
1. Verify Twilio account balance
2. Check phone number is verified
3. Review Twilio debugger logs
4. Check server logs for errors
```

**Problem: Can't hear AI response**
```
Solution:
1. Verify webhook URL is accessible
2. Check ngrok tunnel is running
3. Review Twilio webhook logs
4. Test webhook with curl
```

**Problem: Speech not recognized**
```
Solution:
1. Speak louder and clearer
2. Wait for beep before speaking
3. Try shorter, simpler questions
4. Check Twilio speech logs
```

---

## 📚 API Reference

### Make Voice Call

**Endpoint:** `POST /call/make`

**Request:**
```json
{
  "to": "+1234567890",
  "message": "Optional custom greeting"
}
```

**Response:**
```json
{
  "success": true,
  "call_sid": "CA1234567890abcdef",
  "status": "queued",
  "to": "+1234567890",
  "from": "+16205538384"
}
```

**Status Values:**
- `queued` - Call initiated, waiting to connect
- `ringing` - Phone is ringing
- `in-progress` - Call connected
- `completed` - Call ended normally
- `failed` - Call failed
- `busy` - Number was busy
- `no-answer` - No one answered

### Voice Webhook

**Endpoint:** `POST /webhook/voice`

Receives incoming call from Twilio

**Returns:** TwiML XML with voice instructions

### Voice Response Webhook

**Endpoint:** `POST /webhook/voice/response`

Processes speech input and generates AI response

**Form Data:**
- `SpeechResult` - User's spoken text
- `From` - Caller's phone number
- `CallSid` - Call identifier

**Returns:** TwiML XML with AI response

---

## ✅ Testing Checklist

### Visualization Testing

- [ ] Open advanced interface
- [ ] Server shows "Online" status
- [ ] Enable SQL toggle
- [ ] Ask database question
- [ ] Results appear correctly
- [ ] Click "Visualize" button
- [ ] Chart panel opens
- [ ] Chart renders correctly
- [ ] Switch to Bar chart
- [ ] Switch to Line chart
- [ ] Switch to Pie chart
- [ ] Switch to Scatter chart
- [ ] Switch to Area chart
- [ ] Switch to Table view
- [ ] Enable Auto-visualize
- [ ] New query auto-shows chart

### Voice Calling Testing

- [ ] Server running with Twilio configured
- [ ] Click "Call Agent" button
- [ ] Enter valid phone number
- [ ] Call modal appears
- [ ] Status shows "Initiating call..."
- [ ] Receive call on phone
- [ ] Hear AI greeting
- [ ] Speak a question
- [ ] Hear AI response
- [ ] Continue conversation
- [ ] Hang up or end call
- [ ] Modal closes correctly

### API Testing

- [ ] Test `/call/make` endpoint
- [ ] Verify call initiated
- [ ] Check call status
- [ ] Review Twilio debugger
- [ ] Test with invalid number
- [ ] Verify error handling
- [ ] Check server logs

---

## 🎓 Learning Resources

### Databricks Genie Comparison

**What We Implemented:**
- ✅ Multiple chart types
- ✅ Natural language to SQL
- ✅ Interactive visualizations
- ✅ Side-by-side layout
- ✅ Auto-visualization option

**Databricks Genie Features:**
- Similar chart type switching
- Similar natural language queries
- Similar dual-panel layout
- Additional: Chart customization
- Additional: Dashboard creation

### Plotly.js Documentation

- Official Docs: https://plotly.com/javascript/
- Chart Types: https://plotly.com/javascript/basic-charts/
- Customization: https://plotly.com/javascript/reference/

### Twilio Voice Documentation

- Voice API: https://www.twilio.com/docs/voice
- TwiML: https://www.twilio.com/docs/voice/twiml
- Speech Recognition: https://www.twilio.com/docs/voice/twiml/gather

---

## 🚀 Next Steps

After mastering the basics:

1. **Customize Chart Styles**
   - Modify colors in chart rendering code
   - Add custom titles and labels
   - Adjust chart dimensions

2. **Add Chart Export**
   - Implement PNG/SVG export
   - Add print functionality
   - Create shareable links

3. **Enhance Voice Features**
   - Add call recording
   - Implement call transcripts
   - Create voice commands

4. **Build Dashboards**
   - Save favorite visualizations
   - Create multi-chart dashboards
   - Share with team members

---

## 📞 Support

If you encounter issues:

1. Check [docs/IMPROVEMENTS.md](./IMPROVEMENTS.md) for detailed troubleshooting
2. Review server logs in PowerShell terminal
3. Check Twilio debugger for call issues
4. Verify all environment variables are set
5. Ensure server is running and healthy

---

**Happy visualizing and calling!** 🎉
