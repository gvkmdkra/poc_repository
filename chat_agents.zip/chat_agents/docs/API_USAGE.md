# API Usage Guide

## Table of Contents
- [Starting the Server](#starting-the-server)
- [API Endpoints](#api-endpoints)
- [cURL Examples](#curl-examples)
- [Python Examples](#python-examples)
- [Postman Collection](#postman-collection)
- [Error Handling](#error-handling)

## Starting the Server

### Method 1: Direct Python
```bash
python api.py
```

### Method 2: Uvicorn
```bash
uvicorn api:app --reload --host 0.0.0.0 --port 8000
```

### Method 3: With Workers (Production)
```bash
gunicorn api:app -w 4 -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000
```

Server will start at: **http://localhost:8000**

---

## API Endpoints

### 1. Root Endpoint
**GET** `/`

Get service information and available endpoints.

### 2. Health Check
**GET** `/health`

Check if the service is running and components are initialized.

### 3. Chat
**POST** `/chat`

Send a message to the chat agent.

### 4. Send SMS
**POST** `/sms/send`

Send an SMS message via Twilio.

### 5. Send WhatsApp
**POST** `/whatsapp/send`

Send a WhatsApp message via Twilio.

###  6. Twilio Webhook
**POST** `/webhook/twilio`

Webhook endpoint for incoming Twilio messages.

### 7. Get Conversation History
**GET** `/history`

Retrieve all conversation history.

### 8. Clear History
**DELETE** `/history`

Clear all conversation history.

### 9. Train SQL Agent
**POST** `/train`

Train the Vanna SQL agent with schema, documentation, or examples.

### 10. Get Training Data
**GET** `/training-data`

Retrieve all training data for the SQL agent.

---

## cURL Examples

### 1. Check Service Status
```bash
curl -X GET http://localhost:8000/
```

**Response:**
```json
{
  "service": "Reusable Chat Agent API",
  "status": "running",
  "endpoints": {
    "chat": "/chat",
    "sms": "/sms/send",
    "whatsapp": "/whatsapp/send",
    "twilio_webhook": "/webhook/twilio",
    "history": "/history",
    "train": "/train"
  }
}
```

### 2. Health Check
```bash
curl -X GET http://localhost:8000/health
```

**Response:**
```json
{
  "status": "healthy",
  "chat_agent": true,
  "sql_enabled": true,
  "twilio_enabled": true
}
```

### 3. Send Chat Message (Basic)
```bash
curl -X POST http://localhost:8000/chat \
  -H "Content-Type: application/json" \
  -d '{
    "message": "Hello! How are you?",
    "check_sql": false
  }'
```

**Response:**
```json
{
  "user_message": "Hello! How are you?",
  "context": null,
  "sql_result": null,
  "ai_response": "Hello! I'm doing well, thank you for asking! How can I help you today?",
  "success": true
}
```

### 4. Send Chat Message with SQL Query
```bash
curl -X POST http://localhost:8000/chat \
  -H "Content-Type: application/json" \
  -d '{
    "message": "How many users are in the database?",
    "check_sql": true
  }'
```

**Response:**
```json
{
  "user_message": "How many users are in the database?",
  "context": null,
  "sql_result": {
    "success": true,
    "question": "How many users are in the database?",
    "sql": "SELECT COUNT(*) as count FROM users",
    "results": [{"count": 42}],
    "row_count": 1
  },
  "ai_response": "Based on the database query, there are currently 42 users in the system.",
  "success": true
}
```

### 5. Send Chat with Context
```bash
curl -X POST http://localhost:8000/chat \
  -H "Content-Type: application/json" \
  -d '{
    "message": "What is my account status?",
    "context": {
      "user_id": 123,
      "session_id": "abc-def-ghi"
    },
    "check_sql": true
  }'
```

### 6. Send SMS
```bash
curl -X POST http://localhost:8000/sms/send \
  -H "Content-Type: application/json" \
  -d '{
    "to": "+1234567890",
    "message": "Hello from the Chat Agent API!"
  }'
```

**Response:**
```json
{
  "success": true,
  "sid": "SM1234567890abcdef",
  "status": "queued",
  "to": "+1234567890"
}
```

### 7. Send WhatsApp Message
```bash
curl -X POST http://localhost:8000/whatsapp/send \
  -H "Content-Type: application/json" \
  -d '{
    "to": "+1234567890",
    "message": "Hello via WhatsApp!"
  }'
```

### 8. Get Conversation History
```bash
curl -X GET http://localhost:8000/history
```

**Response:**
```json
{
  "history": [
    {
      "user_message": "Hello!",
      "ai_response": "Hi there!",
      "context": null,
      "sql_result": null,
      "success": true
    }
  ],
  "count": 1
}
```

### 9. Clear History
```bash
curl -X DELETE http://localhost:8000/history
```

**Response:**
```json
{
  "message": "History cleared successfully"
}
```

### 10. Train SQL Agent with Schema
```bash
curl -X POST http://localhost:8000/train \
  -H "Content-Type: application/json" \
  -d '{
    "ddl": "CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT, email TEXT, created_at TIMESTAMP)"
  }'
```

### 11. Train SQL Agent with Q&A Examples
```bash
curl -X POST http://localhost:8000/train \
  -H "Content-Type: application/json" \
  -d '{
    "question": "How many users signed up today?",
    "sql": "SELECT COUNT(*) FROM users WHERE DATE(created_at) = DATE(\"now\")"
  }'
```

### 12. Train with Documentation
```bash
curl -X POST http://localhost:8000/train \
  -H "Content-Type: application/json" \
  -d '{
    "documentation": "The users table contains all registered users. Use created_at for date filtering."
  }'
```

### 13. Get Training Data
```bash
curl -X GET http://localhost:8000/training-data
```

**Response:**
```json
{
  "training_data": [
    {
      "type": "ddl",
      "content": "CREATE TABLE users (...)"
    },
    {
      "type": "question_sql",
      "question": "How many users?",
      "sql": "SELECT COUNT(*) FROM users"
    }
  ]
}
```

---

## Python Examples

### Basic Chat Client
```python
import requests

BASE_URL = "http://localhost:8000"

# Send a chat message
response = requests.post(
    f"{BASE_URL}/chat",
    json={
        "message": "What's the weather like?",
        "check_sql": False
    }
)

print(response.json()["ai_response"])
```

### SQL Query Example
```python
import requests

BASE_URL = "http://localhost:8000"

# Train the SQL agent first
requests.post(
    f"{BASE_URL}/train",
    json={
        "ddl": "CREATE TABLE products (id INT, name TEXT, price REAL)",
        "question": "Show all products",
        "sql": "SELECT * FROM products"
    }
)

# Ask a question
response = requests.post(
    f"{BASE_URL}/chat",
    json={
        "message": "How many products cost more than $100?",
        "check_sql": True
    }
)

result = response.json()
if result["success"] and result["sql_result"]:
    print(f"SQL: {result['sql_result']['sql']}")
    print(f"Results: {result['sql_result']['results']}")
    print(f"Answer: {result['ai_response']}")
```

### Send SMS with Conversation
```python
import requests

BASE_URL = "http://localhost:8000"

# Chat with the agent
chat_response = requests.post(
    f"{BASE_URL}/chat",
    json={"message": "What's our total revenue?", "check_sql": True}
)

ai_answer = chat_response.json()["ai_response"]

# Send the answer via SMS
sms_response = requests.post(
    f"{BASE_URL}/sms/send",
    json={
        "to": "+1234567890",
        "message": f"Revenue Report: {ai_answer}"
    }
)

print(f"SMS sent: {sms_response.json()['success']}")
```

### Complete Workflow
```python
import requests
import json

BASE_URL = "http://localhost:8000"

class ChatClient:
    def __init__(self, base_url=BASE_URL):
        self.base_url = base_url

    def chat(self, message, context=None, check_sql=True):
        response = requests.post(
            f"{self.base_url}/chat",
            json={
                "message": message,
                "context": context,
                "check_sql": check_sql
            }
        )
        return response.json()

    def send_sms(self, to, message):
        response = requests.post(
            f"{self.base_url}/sms/send",
            json={"to": to, "message": message}
        )
        return response.json()

    def get_history(self):
        response = requests.get(f"{self.base_url}/history")
        return response.json()

    def train(self, ddl=None, question=None, sql=None, docs=None):
        payload = {}
        if ddl:
            payload["ddl"] = ddl
        if question and sql:
            payload["question"] = question
            payload["sql"] = sql
        if docs:
            payload["documentation"] = docs

        response = requests.post(
            f"{self.base_url}/train",
            json=payload
        )
        return response.json()

# Usage
client = ChatClient()

# Train the agent
client.train(ddl="CREATE TABLE orders (id INT, total REAL, customer_id INT)")

# Chat
result = client.chat("What's the total revenue?")
print(f"AI: {result['ai_response']}")

# Get history
history = client.get_history()
print(f"Total conversations: {history['count']}")
```

---

## Postman Collection

Import this JSON into Postman:

```json
{
  "info": {
    "name": "Chat Agent API",
    "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
  },
  "item": [
    {
      "name": "Chat",
      "request": {
        "method": "POST",
        "header": [{"key": "Content-Type", "value": "application/json"}],
        "body": {
          "mode": "raw",
          "raw": "{\"message\": \"Hello!\", \"check_sql\": false}"
        },
        "url": {
          "raw": "http://localhost:8000/chat",
          "protocol": "http",
          "host": ["localhost"],
          "port": "8000",
          "path": ["chat"]
        }
      }
    }
  ]
}
```

---

## Error Handling

### Common Error Responses

**503 Service Unavailable**
```json
{
  "detail": "Chat agent not initialized"
}
```

**422 Validation Error**
```json
{
  "detail": [
    {
      "type": "missing",
      "loc": ["body", "message"],
      "msg": "Field required"
    }
  ]
}
```

**500 Internal Server Error**
```json
{
  "detail": "Error processing request: <error details>"
}
```

### Handling Errors in Python
```python
import requests

try:
    response = requests.post(
        "http://localhost:8000/chat",
        json={"message": "test"},
        timeout=30
    )
    response.raise_for_status()
    data = response.json()

    if not data.get("success"):
        print(f"Error: {data.get('error')}")
    else:
        print(f"Response: {data['ai_response']}")

except requests.exceptions.Timeout:
    print("Request timed out")
except requests.exceptions.ConnectionError:
    print("Could not connect to server")
except requests.exceptions.HTTPError as e:
    print(f"HTTP error: {e}")
```

---

## Environment Variables

Make sure these are set in your `.env` file:

```env
GEMINI_API_KEY=your_gemini_key
TWILIO_ACCOUNT_SID=your_twilio_sid
TWILIO_AUTH_TOKEN=your_twilio_token
TWILIO_PHONE_NUMBER=your_twilio_number
TURSO_DB_AUTH_TOKEN=your_turso_token
TURSO_DB_URL=your_turso_url
```

---

## Production Deployment

### Docker
```dockerfile
FROM python:3.11-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

CMD ["uvicorn", "api:app", "--host", "0.0.0.0", "--port", "8000"]
```

### Docker Compose
```yaml
version: '3.8'
services:
  chat-agent:
    build: .
    ports:
      - "8000:8000"
    env_file:
      - .env
    restart: unless-stopped
```

---

## Rate Limiting

Consider adding rate limiting in production:

```python
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address

limiter = Limiter(key_func=get_remote_address)
app.state.limiter = limiter

@app.post("/chat")
@limiter.limit("10/minute")
async def chat(request: Request, message: ChatMessage):
    # ... existing code
```

---

For more information, see [README.md](README.md) and [TESTING.md](TESTING.md).
