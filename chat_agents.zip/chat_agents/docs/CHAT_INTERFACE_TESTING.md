# Chat Interface Testing Guide

## Quick Start Testing

### Step 1: Start the Server
```bash
cd c:\Users\Mani_Moon\reapdat\code_integration\reusable_agents\chat_agents
python run.py
```

**Expected Output:**
```
======================================================================
Starting Reusable Chat Agent Server
======================================================================

Server Information:
   URL:      http://localhost:8000
   API Docs: http://localhost:8000/docs
   Health:   http://localhost:8000/health
...
INFO:     Uvicorn running on http://0.0.0.0:8000 (Press CTRL+C to quit)
```

### Step 2: Open Chat Interface
1. Open Windows Explorer
2. Navigate to: `c:\Users\Mani_Moon\reapdat\code_integration\reusable_agents\chat_agents\web`
3. Double-click `chat_interface.html`
4. Your default browser will open with the chat interface

### Step 3: Verify Connection
- Look at the top right corner
- Status should show: **"Online"** (green)
- If it shows "Offline" (red), click "Check Health" button or refresh (F5)

## Complete Functional Testing Checklist

### ✅ Test 1: Basic Chat Functionality

**Test Case:** Send a simple message
1. Type in message box: `Hello! How are you?`
2. Click "Send" or press Enter
3. **Expected:** Bot responds with greeting

**Pass Criteria:**
- ✅ Message appears in chat window
- ✅ Bot response appears within 3-5 seconds
- ✅ Response is coherent and relevant
- ✅ Timestamp is displayed
- ✅ User/Bot messages are visually distinct

---

### ✅ Test 2: SQL Query Detection (Disabled)

**Test Case:** Ask a question without SQL enabled
1. Ensure "Check SQL" toggle is **OFF** (unchecked)
2. Type: `How many users are in the database?`
3. Click "Send"
4. **Expected:** Bot treats it as normal conversation

**Pass Criteria:**
- ✅ Bot responds with conversational answer
- ✅ No SQL query is executed
- ✅ No database results shown

---

### ✅ Test 3: SQL Query Detection (Enabled)

**Test Case:** Ask a database question with SQL enabled
1. Click "Check SQL" toggle **ON** (checked)
2. Type: `How many records are in the database?`
3. Click "Send"
4. **Expected:** Bot generates and executes SQL query

**Pass Criteria:**
- ✅ SQL query is displayed in response
- ✅ Database results are shown
- ✅ Bot explains the results
- ✅ Response format includes SQL + Results + Explanation

**Sample Response Format:**
```
SQL: SELECT COUNT(*) FROM table_name
Results: [{"count": 42}]
Explanation: There are 42 records in the database.
```

---

### ✅ Test 4: Conversation History

**Test Case:** Multi-turn conversation
1. Send message: `My name is John`
2. Wait for response
3. Send message: `What is my name?`
4. **Expected:** Bot remembers from previous message

**Pass Criteria:**
- ✅ Bot recalls information from earlier in conversation
- ✅ All messages remain visible in chat window
- ✅ Scroll works properly for long conversations

---

### ✅ Test 5: Quick Action Buttons

**Test Case 5a:** Check Status
1. Click "Check Status" quick action button
2. **Expected:** Bot provides current status

**Test Case 5b:** Get Help
1. Click "Get Help" quick action button
2. **Expected:** Bot provides help information

**Pass Criteria:**
- ✅ Quick actions send messages automatically
- ✅ Responses are relevant to the action
- ✅ Button clicks don't require typing

---

### ✅ Test 6: Health Check

**Test Case:** Verify server health
1. Click "Check Health" button (top right)
2. **Expected:** Green "Online" status appears

**Pass Criteria:**
- ✅ Status indicator updates
- ✅ Green = healthy, Red = offline
- ✅ Works even if temporarily offline

---

### ✅ Test 7: Clear History

**Test Case:** Clear conversation
1. Send several messages
2. Click "Clear History" button (top right)
3. **Expected:** Chat window clears

**Pass Criteria:**
- ✅ All messages disappear
- ✅ Welcome message reappears
- ✅ New messages start fresh conversation
- ✅ Server history is also cleared (not just UI)

---

### ✅ Test 8: Empty Message Handling

**Test Case:** Try to send empty message
1. Leave message box empty
2. Click "Send"
3. **Expected:** Nothing happens or shows error

**Pass Criteria:**
- ✅ Empty messages are not sent
- ✅ No error appears in console
- ✅ Interface remains stable

---

### ✅ Test 9: Long Message Handling

**Test Case:** Send very long message
1. Type a message with 500+ characters
2. Click "Send"
3. **Expected:** Message is sent and displayed properly

**Pass Criteria:**
- ✅ Long messages display correctly
- ✅ Text wraps properly
- ✅ No layout breaking
- ✅ Response is still relevant

---

### ✅ Test 10: Special Characters

**Test Case:** Send message with special characters
1. Type: `Test: <html> & "quotes" 'apostrophe' $symbols$`
2. Click "Send"
3. **Expected:** All characters display correctly

**Pass Criteria:**
- ✅ No HTML injection occurs
- ✅ Special characters are escaped
- ✅ Message displays as typed

---

### ✅ Test 11: Rapid Fire Messages

**Test Case:** Send multiple messages quickly
1. Send message: `Hello`
2. Immediately send: `How are you?`
3. Immediately send: `What time is it?`
4. **Expected:** All messages are processed in order

**Pass Criteria:**
- ✅ All messages appear in correct order
- ✅ All responses are received
- ✅ No messages are lost
- ✅ No race conditions occur

---

### ✅ Test 12: Network Error Handling

**Test Case:** Simulate server offline
1. Stop the server (Ctrl+C in terminal)
2. Try to send a message in the chat interface
3. **Expected:** Error message or offline indicator

**Pass Criteria:**
- ✅ User is notified of connection issue
- ✅ Interface doesn't crash
- ✅ When server restarts, connection recovers

---

### ✅ Test 13: Response Time

**Test Case:** Measure response speed
1. Send simple message: `Hello`
2. Note the time until response appears
3. **Expected:** Response within 5 seconds

**Pass Criteria:**
- ✅ Simple messages: < 5 seconds
- ✅ SQL queries: < 10 seconds
- ✅ Loading indicator appears during wait

---

### ✅ Test 14: Mobile Responsiveness (if applicable)

**Test Case:** Resize browser window
1. Make window narrow (mobile width)
2. Try sending messages
3. **Expected:** Interface adapts

**Pass Criteria:**
- ✅ Layout remains usable
- ✅ Buttons are clickable
- ✅ Text is readable
- ✅ No horizontal scrolling

---

### ✅ Test 15: Multiple Browser Tabs

**Test Case:** Open interface in multiple tabs
1. Open chat_interface.html in Tab 1
2. Open chat_interface.html in Tab 2
3. Send messages in both tabs
4. **Expected:** Each tab has independent session

**Pass Criteria:**
- ✅ Both tabs work independently
- ✅ Messages don't cross-contaminate
- ✅ No conflicts occur

---

## Testing SQL Features

### Setup: Create Test Database

First, train the SQL agent with test schema:

**Using API Docs (http://localhost:8000/docs):**
1. Go to POST /train endpoint
2. Click "Try it out"
3. Enter:
```json
{
  "ddl": "CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT, email TEXT, created_at TIMESTAMP)"
}
```
4. Execute

**Or using curl:**
```bash
curl -X POST http://localhost:8000/train \
  -H "Content-Type: application/json" \
  -d "{\"ddl\":\"CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT, email TEXT)\"}"
```

### SQL Test Cases

**Test SQL 1:** Count query
- Message: `How many users are there?`
- Expected SQL: `SELECT COUNT(*) FROM users`

**Test SQL 2:** List query
- Message: `Show me all users`
- Expected SQL: `SELECT * FROM users`

**Test SQL 3:** Filter query
- Message: `Find users created today`
- Expected SQL: `SELECT * FROM users WHERE DATE(created_at) = DATE('now')`

**Test SQL 4:** Aggregate query
- Message: `What's the average age of users?`
- Expected SQL: `SELECT AVG(age) FROM users`

---

## API Testing (Alternative to Chat Interface)

### Using Browser Developer Tools

**Test POST /chat endpoint:**
```javascript
// Open browser console (F12)
fetch('http://localhost:8000/chat', {
  method: 'POST',
  headers: {'Content-Type': 'application/json'},
  body: JSON.stringify({
    message: 'Hello!',
    check_sql: false
  })
})
.then(r => r.json())
.then(data => console.log(data));
```

### Using curl

**Test basic chat:**
```bash
curl -X POST http://localhost:8000/chat \
  -H "Content-Type: application/json" \
  -d "{\"message\":\"Hello!\",\"check_sql\":false}"
```

**Test SQL chat:**
```bash
curl -X POST http://localhost:8000/chat \
  -H "Content-Type: application/json" \
  -d "{\"message\":\"How many users?\",\"check_sql\":true}"
```

**Test health:**
```bash
curl http://localhost:8000/health
```

**Test history:**
```bash
curl http://localhost:8000/history
```

**Clear history:**
```bash
curl -X DELETE http://localhost:8000/history
```

---

## Performance Testing

### Load Test with curl
```bash
# Send 10 messages rapidly
for i in {1..10}; do
  curl -X POST http://localhost:8000/chat \
    -H "Content-Type: application/json" \
    -d "{\"message\":\"Test $i\",\"check_sql\":false}" &
done
wait
```

### Expected Results
- ✅ All requests complete successfully
- ✅ No timeouts
- ✅ Responses remain fast
- ✅ No server crashes

---

## Troubleshooting Common Issues

### Issue 1: Chat Interface Shows "Offline"
**Solution:**
1. Check server is running (`python run.py`)
2. Verify URL is `http://localhost:8000`
3. Check firewall isn't blocking port 8000
4. Click "Check Health" button
5. Refresh browser (F5)

### Issue 2: No Response from Bot
**Solution:**
1. Check browser console (F12) for errors
2. Verify GEMINI_API_KEY in .env file
3. Check server logs for errors
4. Test with curl to isolate issue

### Issue 3: SQL Queries Not Working
**Solution:**
1. Ensure "Check SQL" toggle is ON
2. Train the agent with schema first
3. Check TURSO_DB credentials in .env
4. Verify database connection with health check

### Issue 4: Server Won't Start
**Solution:**
1. Check port 8000 is not already in use
2. Kill existing processes: `taskkill //F //PID <pid>`
3. Verify all dependencies installed: `pip install -r requirements.txt`
4. Check .env file exists and is valid

---

## Automated Testing

### Run pytest tests
```bash
# All tests
pytest tests/ -v

# Just integration tests
pytest tests/test_api.py -v

# With coverage
pytest tests/ --cov=src --cov-report=html
```

---

## Summary Checklist

Before deploying to production, verify:

- [ ] All 15 functional tests pass
- [ ] SQL queries work correctly
- [ ] Error handling works properly
- [ ] Performance is acceptable (< 5s responses)
- [ ] Mobile responsive (if needed)
- [ ] Security measures in place
- [ ] API documentation accessible
- [ ] Logs are being generated
- [ ] Health check endpoint works
- [ ] Environment variables are secure

---

## Demo Script for Clients

**5-Minute Demo Flow:**

1. **Introduction** (30s)
   - "This is our AI-powered chat agent with database integration"

2. **Basic Chat** (1m)
   - Send: `Hello! What can you do?`
   - Show natural conversation

3. **SQL Feature** (2m)
   - Enable "Check SQL" toggle
   - Send: `How many records are in the database?`
   - Show SQL generation and execution

4. **Quick Actions** (1m)
   - Click quick action buttons
   - Show preset queries

5. **API Integration** (30s)
   - Open http://localhost:8000/docs
   - Show API endpoints

6. **Q&A** (remaining time)

---

## Next Steps

After testing locally:

1. **Deploy to staging environment**
2. **Load testing with real traffic**
3. **Security audit**
4. **Client acceptance testing**
5. **Production deployment**

For deployment guides, see:
- docs/DEPLOYMENT.md (if exists)
- docs/DOCUMENTATION.md
