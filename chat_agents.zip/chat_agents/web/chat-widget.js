/**
 * AI Chat Widget - Embeddable Chat Interface
 *
 * Usage:
 * <script src="chat-widget.js"></script>
 * <script>
 *   AIChatWidget.init({
 *     apiUrl: 'http://localhost:8000',
 *     apiKey: 'your-api-key-here',
 *     clientId: 'your-client-id',
 *     position: 'bottom-right', // bottom-left, bottom-right
 *     primaryColor: '#667eea',
 *     companyName: 'Your Company'
 *   });
 * </script>
 */

(function() {
    'use strict';

    const AIChatWidget = {
        config: {
            apiUrl: 'http://localhost:8000',
            apiKey: '',
            clientId: '',
            position: 'bottom-right',
            primaryColor: '#667eea',
            secondaryColor: '#764ba2',
            companyName: 'AI Assistant',
            welcomeMessage: 'Hello! How can I help you today?',
            placeholder: 'Type your message...',
            quickActions: [
                { label: '📋 Show tables', message: 'Show me all tables in my database' },
                { label: '👥 Count customers', message: 'How many customers do I have?' },
                { label: '🛍️ Recent orders', message: 'What are my recent orders?' }
            ]
        },

        init: function(options) {
            // Merge config
            this.config = { ...this.config, ...options };

            // Inject styles
            this.injectStyles();

            // Inject HTML
            this.injectHTML();

            // Setup event listeners
            this.setupEventListeners();

            // Initialize
            this.isOpen = false;
            this.messageCount = 0;
        },

        injectStyles: function() {
            const style = document.createElement('style');
            style.textContent = `
                #ai-chat-widget-container {
                    position: fixed;
                    ${this.config.position.includes('right') ? 'right: 20px;' : 'left: 20px;'}
                    bottom: 20px;
                    z-index: 999999;
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                }

                #ai-chat-button {
                    width: 60px;
                    height: 60px;
                    border-radius: 50%;
                    background: linear-gradient(135deg, ${this.config.primaryColor} 0%, ${this.config.secondaryColor} 100%);
                    border: none;
                    cursor: pointer;
                    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    transition: all 0.3s ease;
                    position: relative;
                }

                #ai-chat-button:hover {
                    transform: scale(1.1);
                    box-shadow: 0 6px 20px rgba(0,0,0,0.3);
                }

                #ai-chat-button svg {
                    width: 30px;
                    height: 30px;
                    fill: white;
                }

                .ai-notification-badge {
                    position: absolute;
                    top: -5px;
                    right: -5px;
                    background: #ff4444;
                    color: white;
                    border-radius: 50%;
                    width: 24px;
                    height: 24px;
                    display: none;
                    align-items: center;
                    justify-content: center;
                    font-size: 12px;
                    font-weight: bold;
                }

                #ai-chat-window {
                    position: fixed;
                    bottom: 90px;
                    ${this.config.position.includes('right') ? 'right: 20px;' : 'left: 20px;'}
                    width: 380px;
                    height: 600px;
                    background: white;
                    border-radius: 20px;
                    box-shadow: 0 10px 40px rgba(0,0,0,0.3);
                    display: none;
                    flex-direction: column;
                    overflow: hidden;
                }

                #ai-chat-window.active {
                    display: flex;
                    animation: slideUp 0.3s ease;
                }

                @keyframes slideUp {
                    from { opacity: 0; transform: translateY(20px); }
                    to { opacity: 1; transform: translateY(0); }
                }

                .ai-chat-header {
                    background: linear-gradient(135deg, ${this.config.primaryColor} 0%, ${this.config.secondaryColor} 100%);
                    color: white;
                    padding: 20px;
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                }

                .ai-chat-header-info {
                    display: flex;
                    align-items: center;
                    gap: 12px;
                }

                .ai-chat-avatar {
                    width: 40px;
                    height: 40px;
                    border-radius: 50%;
                    background: white;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    font-weight: bold;
                    color: ${this.config.primaryColor};
                }

                .ai-chat-messages {
                    flex: 1;
                    overflow-y: auto;
                    padding: 20px;
                    background: #f8f9fa;
                }

                .ai-message {
                    display: flex;
                    margin-bottom: 16px;
                    animation: fadeIn 0.3s ease;
                }

                @keyframes fadeIn {
                    from { opacity: 0; transform: translateY(10px); }
                    to { opacity: 1; transform: translateY(0); }
                }

                .ai-message.bot {
                    justify-content: flex-start;
                }

                .ai-message.user {
                    justify-content: flex-end;
                }

                .ai-message-avatar {
                    width: 32px;
                    height: 32px;
                    border-radius: 50%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    font-weight: bold;
                    font-size: 14px;
                    flex-shrink: 0;
                }

                .ai-message.bot .ai-message-avatar {
                    background: linear-gradient(135deg, ${this.config.primaryColor} 0%, ${this.config.secondaryColor} 100%);
                    color: white;
                    margin-right: 10px;
                }

                .ai-message.user .ai-message-avatar {
                    background: #e5e7eb;
                    color: ${this.config.primaryColor};
                    margin-left: 10px;
                }

                .ai-message-content {
                    max-width: 70%;
                    padding: 12px 16px;
                    border-radius: 18px;
                    word-wrap: break-word;
                }

                .ai-message.bot .ai-message-content {
                    background: white;
                    color: #333;
                    border-bottom-left-radius: 4px;
                    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                }

                .ai-message.user .ai-message-content {
                    background: linear-gradient(135deg, ${this.config.primaryColor} 0%, ${this.config.secondaryColor} 100%);
                    color: white;
                    border-bottom-right-radius: 4px;
                }

                .ai-typing-indicator {
                    display: none;
                }

                .ai-typing-indicator.active {
                    display: block;
                }

                .ai-typing-dots {
                    display: flex;
                    gap: 4px;
                }

                .ai-typing-dot {
                    width: 8px;
                    height: 8px;
                    border-radius: 50%;
                    background: #999;
                    animation: typing 1.4s infinite;
                }

                .ai-typing-dot:nth-child(2) { animation-delay: 0.2s; }
                .ai-typing-dot:nth-child(3) { animation-delay: 0.4s; }

                @keyframes typing {
                    0%, 60%, 100% { transform: translateY(0); }
                    30% { transform: translateY(-10px); }
                }

                .ai-chat-input-container {
                    padding: 20px;
                    background: white;
                    border-top: 1px solid #e5e7eb;
                }

                .ai-chat-input-wrapper {
                    display: flex;
                    gap: 10px;
                }

                #ai-chat-input {
                    flex: 1;
                    padding: 12px 16px;
                    border: 2px solid #e5e7eb;
                    border-radius: 24px;
                    font-size: 14px;
                    outline: none;
                }

                #ai-chat-input:focus {
                    border-color: ${this.config.primaryColor};
                }

                #ai-chat-send {
                    width: 44px;
                    height: 44px;
                    border-radius: 50%;
                    background: linear-gradient(135deg, ${this.config.primaryColor} 0%, ${this.config.secondaryColor} 100%);
                    border: none;
                    cursor: pointer;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                }

                #ai-chat-send svg {
                    width: 20px;
                    height: 20px;
                    fill: white;
                }

                .ai-quick-actions {
                    display: flex;
                    gap: 8px;
                    margin-top: 12px;
                    flex-wrap: wrap;
                }

                .ai-quick-action {
                    padding: 8px 14px;
                    background: #f3f4f6;
                    border: 1px solid #e5e7eb;
                    border-radius: 16px;
                    font-size: 13px;
                    cursor: pointer;
                    color: ${this.config.primaryColor};
                }

                .ai-quick-action:hover {
                    background: ${this.config.primaryColor};
                    color: white;
                }

                @media (max-width: 768px) {
                    #ai-chat-window {
                        width: calc(100vw - 40px);
                        height: calc(100vh - 100px);
                    }
                }
            `;
            document.head.appendChild(style);
        },

        injectHTML: function() {
            const container = document.createElement('div');
            container.id = 'ai-chat-widget-container';
            container.innerHTML = `
                <button id="ai-chat-button">
                    <svg viewBox="0 0 24 24">
                        <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H6l-2 2V4h16v12z"/>
                    </svg>
                    <span class="ai-notification-badge">1</span>
                </button>

                <div id="ai-chat-window">
                    <div class="ai-chat-header">
                        <div class="ai-chat-header-info">
                            <div class="ai-chat-avatar">AI</div>
                            <div>
                                <h3 style="font-size: 16px; margin: 0 0 2px 0;">${this.config.companyName}</h3>
                                <div style="font-size: 12px; opacity: 0.9;">
                                    <span style="width: 8px; height: 8px; background: #4ade80; border-radius: 50%; display: inline-block; margin-right: 5px;"></span>Online
                                </div>
                            </div>
                        </div>
                        <button id="ai-chat-close" style="background: none; border: none; color: white; font-size: 24px; cursor: pointer;">×</button>
                    </div>

                    <div class="ai-chat-messages" id="ai-chat-messages">
                        <div class="ai-message bot">
                            <div class="ai-message-avatar">AI</div>
                            <div>
                                <div class="ai-message-content">${this.config.welcomeMessage}</div>
                            </div>
                        </div>

                        <div class="ai-message bot ai-typing-indicator" id="ai-typing-indicator">
                            <div class="ai-message-avatar">AI</div>
                            <div class="ai-typing-dots">
                                <div class="ai-typing-dot"></div>
                                <div class="ai-typing-dot"></div>
                                <div class="ai-typing-dot"></div>
                            </div>
                        </div>
                    </div>

                    <div class="ai-chat-input-container">
                        <div class="ai-chat-input-wrapper">
                            <input type="text" id="ai-chat-input" placeholder="${this.config.placeholder}">
                            <button id="ai-chat-send">
                                <svg viewBox="0 0 24 24">
                                    <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
                                </svg>
                            </button>
                        </div>
                        <div class="ai-quick-actions">
                            ${this.config.quickActions.map(action =>
                                `<button class="ai-quick-action" data-message="${action.message}">${action.label}</button>`
                            ).join('')}
                        </div>
                    </div>
                </div>
            `;
            document.body.appendChild(container);
        },

        setupEventListeners: function() {
            const button = document.getElementById('ai-chat-button');
            const close = document.getElementById('ai-chat-close');
            const send = document.getElementById('ai-chat-send');
            const input = document.getElementById('ai-chat-input');
            const quickActions = document.querySelectorAll('.ai-quick-action');

            button.addEventListener('click', () => this.toggleChat());
            close.addEventListener('click', () => this.toggleChat());
            send.addEventListener('click', () => this.sendMessage());
            input.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') this.sendMessage();
            });

            quickActions.forEach(btn => {
                btn.addEventListener('click', () => {
                    input.value = btn.dataset.message;
                    this.sendMessage();
                });
            });

            // Show notification after 3 seconds
            setTimeout(() => {
                if (!this.isOpen) {
                    document.querySelector('.ai-notification-badge').style.display = 'flex';
                }
            }, 3000);
        },

        toggleChat: function() {
            this.isOpen = !this.isOpen;
            const window = document.getElementById('ai-chat-window');
            window.classList.toggle('active');

            if (this.isOpen) {
                document.querySelector('.ai-notification-badge').style.display = 'none';
                document.getElementById('ai-chat-input').focus();
            }
        },

        async sendMessage() {
            const input = document.getElementById('ai-chat-input');
            const message = input.value.trim();
            if (!message) return;

            input.value = '';
            this.addMessage(message, 'user');

            const typing = document.getElementById('ai-typing-indicator');
            typing.classList.add('active');
            this.scrollToBottom();

            try {
                const response = await fetch(`${this.config.apiUrl}/chat`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-API-Key': this.config.apiKey
                    },
                    body: JSON.stringify({
                        message: message,
                        check_sql: true
                    })
                });

                const data = await response.json();
                typing.classList.remove('active');

                if (response.ok) {
                    let botMessage = data.response || 'I received your message!';

                    if (data.sql) {
                        botMessage += `\n\n📝 SQL: ${data.sql}`;
                    }

                    if (data.results && data.results.length > 0) {
                        botMessage += `\n\n✅ Found ${data.results.length} result(s)`;
                    }

                    this.addMessage(botMessage, 'bot');
                } else {
                    this.addMessage(`Error: ${data.detail || 'Unknown error'}`, 'bot');
                }
            } catch (error) {
                typing.classList.remove('active');
                this.addMessage('Could not connect to server. Please check if the server is running.', 'bot');
            }

            this.scrollToBottom();
        },

        addMessage: function(text, sender) {
            const messages = document.getElementById('ai-chat-messages');
            const typing = document.getElementById('ai-typing-indicator');

            const messageDiv = document.createElement('div');
            messageDiv.className = `ai-message ${sender}`;
            messageDiv.innerHTML = `
                <div class="ai-message-avatar">${sender === 'bot' ? 'AI' : 'U'}</div>
                <div>
                    <div class="ai-message-content">${text.replace(/\n/g, '<br>')}</div>
                </div>
            `;

            messages.insertBefore(messageDiv, typing);
            this.scrollToBottom();
        },

        scrollToBottom: function() {
            const messages = document.getElementById('ai-chat-messages');
            messages.scrollTop = messages.scrollHeight;
        }
    };

    // Export to window
    window.AIChatWidget = AIChatWidget;
})();
