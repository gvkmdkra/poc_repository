import pytest
from twilio_handler import TwilioHandler
from unittest.mock import Mock, patch


class TestTwilioHandler:

    def test_initialization(self, twilio_handler):
        assert twilio_handler.account_sid is not None
        assert twilio_handler.auth_token is not None
        assert twilio_handler.phone_number is not None
        assert twilio_handler.client is not None

    @patch('twilio_handler.Client')
    def test_send_sms_mock(self, mock_client):
        mock_message = Mock()
        mock_message.sid = "SM123456"
        mock_message.status = "queued"

        mock_client.return_value.messages.create.return_value = mock_message

        handler = TwilioHandler()
        result = handler.send_sms("+1234567890", "Test message")

        assert result is not None
        assert isinstance(result, dict)

    @patch('twilio_handler.Client')
    def test_send_whatsapp_mock(self, mock_client):
        mock_message = Mock()
        mock_message.sid = "SM123456"
        mock_message.status = "queued"

        mock_client.return_value.messages.create.return_value = mock_message

        handler = TwilioHandler()
        result = handler.send_whatsapp("+1234567890", "Test WhatsApp message")

        assert result is not None
        assert isinstance(result, dict)

    def test_create_twiml_response(self, twilio_handler):
        response = twilio_handler.create_twiml_response("Hello from Twilio!")

        assert response is not None
        assert isinstance(response, str)
        assert "Hello from Twilio!" in response
        assert "<?xml" in response

    def test_whatsapp_number_formatting(self, twilio_handler):
        test_number = "+1234567890"
        whatsapp_number = f"whatsapp:{test_number}"

        assert whatsapp_number.startswith("whatsapp:")
        assert test_number in whatsapp_number
