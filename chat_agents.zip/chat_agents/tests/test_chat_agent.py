import pytest
from chat_agent import ChatAgent


class TestChatAgent:

    @pytest.mark.asyncio
    async def test_initialization_basic(self, chat_agent_no_features):
        assert chat_agent_no_features.model is not None
        assert chat_agent_no_features.chat_session is not None
        assert chat_agent_no_features.enable_sql is False
        assert chat_agent_no_features.enable_twilio is False

    @pytest.mark.asyncio
    async def test_initialization_full(self, chat_agent):
        assert chat_agent.model is not None
        assert chat_agent.chat_session is not None
        assert chat_agent.enable_sql is True
        assert chat_agent.enable_twilio is True
        assert chat_agent.vanna_agent is not None
        assert chat_agent.twilio_handler is not None

    @pytest.mark.asyncio
    async def test_process_basic_message(self, chat_agent_no_features):
        response = await chat_agent_no_features.process_message("Hello, how are you?")

        assert response is not None
        assert "user_message" in response
        assert "ai_response" in response
        assert response["user_message"] == "Hello, how are you?"
        assert response["ai_response"] is not None
        assert len(response["ai_response"]) > 0

    @pytest.mark.asyncio
    async def test_conversation_history(self, chat_agent_no_features):
        await chat_agent_no_features.process_message("First message")
        await chat_agent_no_features.process_message("Second message")

        history = chat_agent_no_features.get_conversation_history()
        assert len(history) == 2
        assert history[0]["user_message"] == "First message"
        assert history[1]["user_message"] == "Second message"

    @pytest.mark.asyncio
    async def test_clear_history(self, chat_agent_no_features):
        await chat_agent_no_features.process_message("Test message")
        assert len(chat_agent_no_features.get_conversation_history()) == 1

        chat_agent_no_features.clear_history()
        assert len(chat_agent_no_features.get_conversation_history()) == 0

    @pytest.mark.asyncio
    async def test_message_callbacks(self, chat_agent_no_features):
        callback_data = []

        def test_callback(message_data):
            callback_data.append(message_data)

        chat_agent_no_features.add_message_callback(test_callback)
        await chat_agent_no_features.process_message("Callback test")

        assert len(callback_data) == 1
        assert callback_data[0]["user_message"] == "Callback test"

    @pytest.mark.asyncio
    async def test_async_callback(self, chat_agent_no_features):
        callback_data = []

        async def async_callback(message_data):
            callback_data.append(message_data)

        chat_agent_no_features.add_message_callback(async_callback)
        await chat_agent_no_features.process_message("Async callback test")

        assert len(callback_data) == 1

    @pytest.mark.asyncio
    async def test_is_sql_query(self, chat_agent):
        assert chat_agent._is_sql_query("How many users are there?")
        assert chat_agent._is_sql_query("Show me all products")
        assert chat_agent._is_sql_query("What is the total revenue?")
        assert chat_agent._is_sql_query("List all customers")
        assert not chat_agent._is_sql_query("Hello, how are you?")

    @pytest.mark.asyncio
    async def test_process_with_context(self, chat_agent_no_features):
        context = {"user_id": 123, "session": "abc"}
        response = await chat_agent_no_features.process_message(
            "Test with context",
            context=context
        )

        assert response["context"] == context

    @pytest.mark.asyncio
    async def test_sql_query_processing(self, chat_agent, sample_ddl):
        await chat_agent.db_connector.execute(sample_ddl)

        await chat_agent.db_connector.execute(
            "INSERT INTO test_users (name, email, age) VALUES (?, ?, ?)",
            ["Alice", "alice@test.com", 25]
        )

        chat_agent.vanna_agent.train_ddl(sample_ddl)
        chat_agent.vanna_agent.train_question_sql(
            "How many users?",
            "SELECT COUNT(*) as count FROM test_users"
        )

        response = await chat_agent.process_message("How many users do we have?")

        assert response is not None
        assert "ai_response" in response
