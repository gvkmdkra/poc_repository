import pytest
from fastapi.testclient import TestClient
from api import app
import asyncio


@pytest.fixture
def client():
    return TestClient(app)


class TestAPI:

    def test_root_endpoint(self, client):
        response = client.get("/")
        assert response.status_code == 200
        data = response.json()
        assert "service" in data
        assert "status" in data
        assert data["status"] == "running"

    def test_health_endpoint(self, client):
        response = client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert "status" in data
        assert data["status"] == "healthy"

    def test_chat_endpoint(self, client):
        payload = {
            "message": "Hello, test message",
            "check_sql": False
        }
        response = client.post("/chat", json=payload)
        assert response.status_code == 200
        data = response.json()
        assert "user_message" in data
        assert "ai_response" in data
        assert data["user_message"] == "Hello, test message"

    def test_chat_with_context(self, client):
        payload = {
            "message": "Test with context",
            "context": {"user_id": 123},
            "check_sql": False
        }
        response = client.post("/chat", json=payload)
        assert response.status_code == 200
        data = response.json()
        assert data["context"]["user_id"] == 123

    def test_history_endpoint(self, client):
        client.post("/chat", json={"message": "First message", "check_sql": False})
        client.post("/chat", json={"message": "Second message", "check_sql": False})

        response = client.get("/history")
        assert response.status_code == 200
        data = response.json()
        assert "history" in data
        assert "count" in data
        assert data["count"] >= 2

    def test_clear_history_endpoint(self, client):
        client.post("/chat", json={"message": "Test message", "check_sql": False})

        response = client.delete("/history")
        assert response.status_code == 200

        history_response = client.get("/history")
        assert history_response.json()["count"] == 0

    def test_train_endpoint(self, client):
        payload = {
            "ddl": "CREATE TABLE test (id INTEGER PRIMARY KEY)",
            "question": "How many records?",
            "sql": "SELECT COUNT(*) FROM test"
        }
        response = client.post("/train", json=payload)
        assert response.status_code == 200
        data = response.json()
        assert "message" in data

    def test_training_data_endpoint(self, client):
        response = client.get("/training-data")
        assert response.status_code == 200
        data = response.json()
        assert "training_data" in data

    def test_invalid_endpoint(self, client):
        response = client.get("/invalid-endpoint")
        assert response.status_code == 404

    def test_chat_invalid_payload(self, client):
        response = client.post("/chat", json={})
        assert response.status_code == 422
