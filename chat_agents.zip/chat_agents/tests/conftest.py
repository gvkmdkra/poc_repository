import pytest
import asyncio
from chat_agent import ChatAgent
from db_connector import TursoDBConnector
from vanna_integration import VannaSQLAgent
from twilio_handler import TwilioHandler
from config import settings


@pytest.fixture(scope="session")
def event_loop():
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest.fixture
async def db_connector():
    connector = TursoDBConnector()
    await connector.connect()
    yield connector
    await connector.close()


@pytest.fixture
async def vanna_agent():
    agent = VannaSQLAgent()
    await agent.setup_db()
    yield agent
    await agent.close()


@pytest.fixture
def twilio_handler():
    return TwilioHandler()


@pytest.fixture
async def chat_agent():
    agent = ChatAgent(enable_sql=True, enable_twilio=True)
    await agent.initialize(train_db=False)
    yield agent
    await agent.close()


@pytest.fixture
async def chat_agent_no_features():
    agent = ChatAgent(enable_sql=False, enable_twilio=False)
    await agent.initialize()
    yield agent
    await agent.close()


@pytest.fixture
def sample_ddl():
    return """
    CREATE TABLE IF NOT EXISTS test_users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE,
        age INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """


@pytest.fixture
def sample_phone():
    return "+1234567890"
