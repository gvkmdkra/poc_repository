import pytest
from vanna_integration import VannaSQLAgent


class TestVannaSQLAgent:

    @pytest.mark.asyncio
    async def test_initialization(self, vanna_agent):
        assert vanna_agent.vn is not None
        assert vanna_agent.api_key is not None

    @pytest.mark.asyncio
    async def test_train_ddl(self, vanna_agent, sample_ddl):
        vanna_agent.train_ddl(sample_ddl)
        assert True

    @pytest.mark.asyncio
    async def test_train_documentation(self, vanna_agent):
        doc = "The users table contains user information including name, email, and age."
        vanna_agent.train_documentation(doc)
        assert True

    @pytest.mark.asyncio
    async def test_train_question_sql(self, vanna_agent):
        vanna_agent.train_question_sql(
            "How many users are there?",
            "SELECT COUNT(*) as total FROM test_users"
        )
        assert True

    @pytest.mark.asyncio
    async def test_generate_sql(self, vanna_agent, sample_ddl):
        vanna_agent.train_ddl(sample_ddl)
        vanna_agent.train_question_sql(
            "Get all users",
            "SELECT * FROM test_users"
        )

        sql = vanna_agent.generate_sql("Show me all users")
        assert sql is not None
        assert isinstance(sql, str)
        assert len(sql) > 0

    @pytest.mark.asyncio
    async def test_ask_with_table(self, vanna_agent, sample_ddl):
        await vanna_agent.db_connector.execute(sample_ddl)

        await vanna_agent.db_connector.execute(
            "INSERT INTO test_users (name, email, age) VALUES (?, ?, ?)",
            ["John Doe", "john@example.com", 30]
        )

        vanna_agent.train_ddl(sample_ddl)
        vanna_agent.train_question_sql(
            "How many users?",
            "SELECT COUNT(*) as count FROM test_users"
        )

        result = await vanna_agent.ask("How many users are there?")

        assert result is not None
        assert "question" in result
        assert "sql" in result

    @pytest.mark.asyncio
    async def test_get_training_data(self, vanna_agent, sample_ddl):
        vanna_agent.train_ddl(sample_ddl)
        training_data = vanna_agent.get_training_data()
        assert isinstance(training_data, list)
