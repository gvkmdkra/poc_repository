import pytest
from db_connector import TursoDBConnector


class TestTursoDBConnector:

    @pytest.mark.asyncio
    async def test_connection(self, db_connector):
        assert db_connector.client is not None
        assert db_connector.url is not None
        assert db_connector.auth_token is not None

    @pytest.mark.asyncio
    async def test_create_table(self, db_connector):
        result = await db_connector.execute("""
            CREATE TABLE IF NOT EXISTS test_products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                price REAL NOT NULL
            )
        """)
        assert result is not None

    @pytest.mark.asyncio
    async def test_insert_data(self, db_connector):
        await db_connector.execute("""
            CREATE TABLE IF NOT EXISTS test_products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                price REAL NOT NULL
            )
        """)

        result = await db_connector.execute(
            "INSERT INTO test_products (name, price) VALUES (?, ?)",
            ["Test Product", 99.99]
        )
        assert result is not None

    @pytest.mark.asyncio
    async def test_fetch_all(self, db_connector):
        await db_connector.execute("""
            CREATE TABLE IF NOT EXISTS test_products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                price REAL NOT NULL
            )
        """)

        await db_connector.execute(
            "INSERT INTO test_products (name, price) VALUES (?, ?)",
            ["Product A", 10.00]
        )
        await db_connector.execute(
            "INSERT INTO test_products (name, price) VALUES (?, ?)",
            ["Product B", 20.00]
        )

        results = await db_connector.fetch_all("SELECT * FROM test_products")
        assert len(results) >= 2

    @pytest.mark.asyncio
    async def test_fetch_one(self, db_connector):
        await db_connector.execute("""
            CREATE TABLE IF NOT EXISTS test_products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                price REAL NOT NULL
            )
        """)

        await db_connector.execute(
            "INSERT INTO test_products (name, price) VALUES (?, ?)",
            ["Single Product", 50.00]
        )

        result = await db_connector.fetch_one("SELECT * FROM test_products LIMIT 1")
        assert result is not None

    @pytest.mark.asyncio
    async def test_context_manager(self):
        async with TursoDBConnector() as db:
            assert db.client is not None
            result = await db.execute("SELECT 1")
            assert result is not None
