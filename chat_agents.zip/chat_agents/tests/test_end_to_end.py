import pytest
from chat_agent import ChatAgent
from db_connector import TursoDBConnector


class TestEndToEnd:

    @pytest.mark.asyncio
    async def test_complete_chat_workflow(self):
        """Test complete workflow: initialize, chat, history, cleanup"""
        agent = ChatAgent(enable_sql=False, enable_twilio=False)
        await agent.initialize()

        response1 = await agent.process_message("What is 2+2?")
        assert response1["success"] is True
        assert response1["ai_response"] is not None

        response2 = await agent.process_message("Tell me a joke")
        assert response2["success"] is True

        history = agent.get_conversation_history()
        assert len(history) == 2

        agent.clear_history()
        assert len(agent.get_conversation_history()) == 0

        await agent.close()

    @pytest.mark.asyncio
    async def test_database_to_agent_workflow(self):
        """Test workflow: create DB, insert data, query via agent"""
        async with TursoDBConnector() as db:
            await db.execute("""
                CREATE TABLE IF NOT EXISTS test_orders (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    product TEXT NOT NULL,
                    quantity INTEGER,
                    total REAL
                )
            """)

            await db.execute(
                "INSERT INTO test_orders (product, quantity, total) VALUES (?, ?, ?)",
                ["Widget A", 5, 50.00]
            )
            await db.execute(
                "INSERT INTO test_orders (product, quantity, total) VALUES (?, ?, ?)",
                ["Widget B", 3, 30.00]
            )

            results = await db.fetch_all("SELECT * FROM test_orders")
            assert len(results) >= 2

        agent = ChatAgent(enable_sql=True, enable_twilio=False)
        await agent.initialize()

        agent.vanna_agent.train_ddl("""
            CREATE TABLE test_orders (
                id INTEGER PRIMARY KEY,
                product TEXT,
                quantity INTEGER,
                total REAL
            )
        """)

        agent.vanna_agent.train_question_sql(
            "How many orders?",
            "SELECT COUNT(*) FROM test_orders"
        )

        await agent.close()

    @pytest.mark.asyncio
    async def test_multi_message_conversation(self):
        """Test multi-turn conversation"""
        agent = ChatAgent(enable_sql=False, enable_twilio=False)
        await agent.initialize()

        messages = [
            "Hello!",
            "What's the weather like?",
            "Tell me about Python",
            "What is machine learning?"
        ]

        for msg in messages:
            response = await agent.process_message(msg)
            assert response["success"] is True
            assert len(response["ai_response"]) > 0

        history = agent.get_conversation_history()
        assert len(history) == len(messages)

        await agent.close()

    @pytest.mark.asyncio
    async def test_callback_chain(self):
        """Test multiple callbacks in sequence"""
        agent = ChatAgent(enable_sql=False, enable_twilio=False)
        await agent.initialize()

        callback_log = []

        def callback1(data):
            callback_log.append("callback1")

        def callback2(data):
            callback_log.append("callback2")

        async def callback3(data):
            callback_log.append("callback3")

        agent.add_message_callback(callback1)
        agent.add_message_callback(callback2)
        agent.add_message_callback(callback3)

        await agent.process_message("Test message")

        assert len(callback_log) == 3
        assert callback_log == ["callback1", "callback2", "callback3"]

        await agent.close()

    @pytest.mark.asyncio
    async def test_error_handling(self):
        """Test error handling in various scenarios"""
        agent = ChatAgent(enable_sql=False, enable_twilio=False)
        await agent.initialize()

        response = await agent.process_message("")
        assert response is not None

        await agent.close()

    @pytest.mark.asyncio
    async def test_sql_detection(self):
        """Test SQL query detection"""
        agent = ChatAgent(enable_sql=True, enable_twilio=False)
        await agent.initialize()

        sql_queries = [
            "How many users are there?",
            "Show me all products",
            "What is the total revenue?",
            "Count the orders",
            "List customers"
        ]

        non_sql_queries = [
            "Hello",
            "How are you?",
            "Tell me a joke"
        ]

        for query in sql_queries:
            assert agent._is_sql_query(query) is True

        for query in non_sql_queries:
            assert agent._is_sql_query(query) is False

        await agent.close()
