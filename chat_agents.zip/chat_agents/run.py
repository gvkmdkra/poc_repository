#!/usr/bin/env python
"""
Quick start script to run the Chat Agent API server.

Usage:
    python run.py
"""

if __name__ == "__main__":
    import sys
    import os

    # Add src to path
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

    # Import and run the API
    from src.api import app
    import uvicorn

    print("=" * 70)
    print("Starting Reusable Chat Agent Server")
    print("=" * 70)
    print("\nServer Information:")
    print("   URL:      http://localhost:8000")
    print("   API Docs: http://localhost:8000/docs")
    print("   Health:   http://localhost:8000/health")
    print("\nTo test:")
    print("   1. Open: web/chat_interface.html in your browser")
    print("   2. Or visit: http://localhost:8000/docs")
    print("\nTo stop: Press CTRL+C")
    print("=" * 70)
    print()

    uvicorn.run(
        "src.api:app",
        host="0.0.0.0",
        port=8000,
        reload=False,
        log_level="info"
    )
